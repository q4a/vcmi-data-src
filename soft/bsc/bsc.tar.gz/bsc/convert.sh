pnmtopng xneg.pgm >> xneg.png
pnmtopng xpos.pgm >> xpos.png
pnmtopng yneg.pgm >> yneg.png
pnmtopng ypos.pgm >> ypos.png
pnmtopng zneg.pgm >> zneg.png
pnmtopng zpos.pgm >> zpos.png
