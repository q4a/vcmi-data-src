﻿namespace WormsNET.Image
{
    using System;
    using System.IO;

    /// <summary>
    /// This class contains methods to decompress data which is compressed using Team17's internal
    /// compression algorithm for graphic file formats.
    /// Most of this code has been written by acme_pjz with further optimizations made by Pisto.
    /// S. http://worms2d.info/Team17_compression.
    /// </summary>
    internal static class Team17Compression
    {
        #region ---- METHODS (INTERNAL) -------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Decompresses the data read from the BinaryReader and stores it in the specified stream.
        /// </summary>
        /// <param name="reader">The reader to read the bytes from.</param>
        /// <param name="stream">The stream to write the decompressed data to.</param>
        /// <returns>True, if the data was decompressed successfully.</returns>
        internal static bool Decompress(BinaryReader reader, ref byte[] stream)
        {
            int cmd;
            // Offset of next write
            int output = 0;
            while ((cmd = reader.ReadByte()) != -1)
            {
                // Read a byte
                if ((cmd & 0x80) == 0)
                {
                    // Command: 1 byte (color)
                    stream[output++] = (byte)cmd;
                }
                else
                {
                    // Arg1 = bits 2-5
                    int arg1 = (cmd >> 3) & 0xF;
                    int arg2 = reader.ReadByte();
                    if (arg2 == -1)
                    {
                        return false;
                    }
                    // Arg2 = bits 6-16
                    arg2 = ((cmd << 8) | arg2) & 0x7FF;
                    if (arg1 == 0)
                    {
                        // Command: 0x80 0x00
                        if (arg2 == 0)
                        {
                            return false;
                        }
                        int arg3 = reader.ReadByte();
                        if (arg3 == -1)
                        {
                            return false;
                        }
                        // Command: 3 bytes
                        output = CopyData(output, arg2, arg3 + 18, ref stream);
                    }
                    else
                    {
                        // Command: 2 bytes
                        output = CopyData(output, arg2 + 1, arg1 + 2, ref stream);
                    }
                }
            }
            return true;
        }

        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        private static int CopyData(int dataOffset, int compressedOffset, int count,
            ref byte[] stream)
        {
            for (; count > 0; count--)
            {
                stream[dataOffset] = stream[dataOffset++ - compressedOffset];
            }
            return dataOffset;
        }
    }
}
