﻿namespace WormsNET.Image
{
    using System.Drawing;
    using System.Drawing.Imaging;
    using System.IO;
    using System.Linq;
    using System.Runtime.InteropServices;
    using WormsNET.Common;

    /// <summary>
    /// Represents an IMG file usually storing colored, paletted and optionally compressed images,
    /// mostly used for the missions in-game levels.
    /// S. http://worms2d.info/Image_file.
    /// </summary>
    public class Image
    {
        #region ---- CONSTANTS ----------------------------------------------------------------------------
        #endregion

        private static byte[] _defaultHeader = new byte[] { 0x49, 0x4D, 0x47, 0x1A };

        #region ---- MEMBERS ------------------------------------------------------------------------------
        #endregion

        private string _description;
        private bool   _compressed;
        private Bitmap _bitmap;

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="Image"/> class from the specified file.
        /// </summary>
        /// <param name="fileName">The name of the file.</param>
        public Image(string fileName)
            : this(new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Image"/> class from the specified stream.
        /// </summary>
        /// <param name="stream">The stream to read from.</param>
        public Image(Stream stream)
        {
            using (BinaryReader reader = new BinaryReader(stream))
            {
                // Check header
                byte[] header = reader.ReadBytes(4);
                if (!header.SequenceEqual(_defaultHeader))
                {
                    throw new InvalidDataException("Invalid header.");
                }

                // File length
                int fileLength = reader.ReadInt32();

                // Bits per pixel or optional description (some Worms 2 images)
                byte bitsPerPixel = reader.ReadByte();
                if (bitsPerPixel > 0x20)
                {
                    // Description available
                    string descriptionRest = reader.ReadString(BinaryStringFormat.ZeroTerminated);
                    _description = (char)bitsPerPixel + descriptionRest;
                    bitsPerPixel = reader.ReadByte();
                }

                // Flags
                byte flags = reader.ReadByte();
                _compressed = flags.GetBit(6);
                bool palettized = flags.GetBit(7);

                // Color palette
                Color[] colors = null;
                if (palettized)
                {
                    // Number of colors
                    short colorNumber = reader.ReadInt16();
                    colors = new Color[colorNumber + 1];

                    // Colors: First color is always black, others are read from file
                    colors[0] = Color.Black;
                    for (int i = 1; i <= colorNumber; i++)
                    {
                        // Color is in RGB format
                        colors[i] = Color.FromArgb(reader.ReadByte(), reader.ReadByte(),
                            reader.ReadByte());
                    }
                }

                // Size
                short width = reader.ReadInt16();
                short height = reader.ReadInt16();

                // Create bitmap
                if (bitsPerPixel == 8)
                {
                    // 8bpp-Images are always indexed and thus require a palette
                    if (colors == null)
                    {
                        throw new InvalidDataException("Image is palettized, but does not specify "
                            + "a palette.");
                    }

                    _bitmap = new Bitmap(width, height, PixelFormat.Format8bppIndexed);
                    
                    // Generate palette
                    ColorPalette palette = _bitmap.Palette;
                    for (int i = 0; i < colors.Length; i++)
                    {
                        palette.Entries[i] = colors[i];
                    }
                    _bitmap.Palette = palette;
                }
                // TODO: Handle other BPP values

                // Image data
                byte[] imageData;
                if (_compressed)
                {
                    imageData = new byte[width * height];
                    Team17Compression.Decompress(reader, ref imageData);
                }
                else
                {
                    imageData = reader.ReadBytes(width * height);
                }

                // Draw image
                BitmapData bitmapData = _bitmap.LockBits(new Rectangle(Point.Empty, _bitmap.Size),
                    ImageLockMode.WriteOnly, _bitmap.PixelFormat);
                // Copy the image data bytes image
                Marshal.Copy(imageData, 0, bitmapData.Scan0, imageData.Length);
                _bitmap.UnlockBits(bitmapData);
            }
        }

        #region ---- PROPERTIES ---------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Gets or sets the optional image description.
        /// </summary>
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the image was compressed or should be stored
        /// compressed.
        /// </summary>
        public bool Compressed
        {
            get { return _compressed; }
            set { _compressed = value; }
        }

        /// <summary>
        /// Gets or sets the visual representation of this image.
        /// </summary>
        public Bitmap Bitmap
        {
            get { return _bitmap; }
            set { _bitmap = value; }
        }
    }
}
