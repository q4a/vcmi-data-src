﻿namespace WormsNET.Common
{
    /// <summary>
    /// Extension class for System.Byte.
    /// </summary>
    internal static class ByteEx
    {
        #region ---- METHODS (PUBLIC) ---------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Returns true if the bit at the specified place (in least-significant order from the
        /// right, starting with 0) is set.
        /// </summary>
        /// <param name="b">The extended Byte.</param>
        /// <param name="bitNumber">The place of the bit which should be checked.</param>
        /// <returns>True, if the bit is set.</returns>
        internal static bool GetBit(this byte b, int bitNumber)
        {
            return (b & (1 << bitNumber)) != 0;
        }

        /// <summary>
        /// Sets the bit at the specified place (in least-significant order from the right,
        /// starting with 0) and returns the resulting byte.
        /// </summary>
        /// <param name="b">The extended Byte.</param>
        /// <param name="bitNumber">The place of the bit which should be set.</param>
        /// <param name="set">Determines whether the byte should be set or not.</param>
        /// <returns>The resulting byte.</returns>
        internal static byte SetBit(this byte b, int bitNumber, bool set)
        {
            if (set)
            {
                return b = (byte)(b | (byte)(1 << bitNumber));
            }
            else
            {
                return b = (byte)(b & (byte)~(1 << bitNumber));
            }
        }
    }
}
