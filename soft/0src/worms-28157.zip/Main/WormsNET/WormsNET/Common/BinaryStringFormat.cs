﻿namespace WormsNET.Common
{
    /// <summary>
    /// Possible binary formats of strings.
    /// </summary>
    internal enum BinaryStringFormat
    {
        /// <summary>
        /// The string has a prefix of variable length determining the length of the string and no
        /// postfix (.NET Framework default).
        /// </summary>
        VariableLengthPrefix,

        /// <summary>
        /// The string has a prefix of 4 bytes determining the length of the string and no postfix.
        /// </summary>
        WordLengthPrefix,

        /// <summary>
        /// The string has no prefix and is terminated with a byte of the value 0.
        /// </summary>
        ZeroTerminated,

        /// <summary>
        /// The string has neither prefix nor postfix. This format is only valid for writing
        /// strings. For reading strings, the length has to be specified manually.
        /// </summary>
        NoPrefixOrTermination
    }
}
