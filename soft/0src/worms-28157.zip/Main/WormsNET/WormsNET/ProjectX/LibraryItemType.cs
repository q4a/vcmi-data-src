﻿namespace WormsNET.ProjectX
{
    using System;

    internal enum LibraryItemType : int
    {
        File = 0x02,
        Script = 0x04,
        Weapon = 0x08
    }
}
