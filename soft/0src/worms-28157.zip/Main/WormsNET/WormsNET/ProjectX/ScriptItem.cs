﻿namespace WormsNET.ProjectX
{
    using System.IO;
    using WormsNET.Common;

    /// <summary>
    /// Represents an EAX script entry in a ProjectX scheme or library.
    /// </summary>
    internal class ScriptItem : ItemBase
    {
        #region ---- MEMBERS ------------------------------------------------------------------------------
        #endregion

        private string _code;

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="ScriptItem"/> class from the specified
        /// stream.
        /// </summary>
        /// <param name="stream">The stream to read the script text from.</param>
        internal ScriptItem(Stream stream)
            : base(stream)
        {
            using (BinaryReader reader = new BinaryReader(stream))
            {
                _code = reader.ReadString(BinaryStringFormat.WordLengthPrefix);
            }
        }

        #region ---- PROPERTIES ---------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Gets or sets the scripts textual code.
        /// </summary>
        internal string Code
        {
            get { return _code; }
            set { _code = value; }
        }
    }
}
