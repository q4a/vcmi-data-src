﻿namespace WormsNET.ProjectX
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Represents a weapon, script or file in a ProjectX scheme or library.
    /// </summary>
    internal class ItemBase
    {
        internal ItemBase(Stream stream)
        {
        }
    }
}
