﻿namespace WormsNET.ProjectX
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Represents a weapon block entry in a ProjectX scheme or library.
    /// </summary>
    internal class WeaponItem : ItemBase
    {
        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="WeaponItem"/> class from the specified
        /// stream.
        /// </summary>
        /// <param name="stream">The stream to read the weapon block from.</param>
        internal WeaponItem(Stream stream)
            : base(stream)
        {

        }
    }
}
