﻿namespace WormsNET.ProjectX
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using WormsNET.Common;

    /// <summary>
    /// Represents a ProjectX library containing weapons, scripts and miscellaneous files.
    /// S. http://worms2d.info/Project_X/Library_file.
    /// </summary>
    public class Library
    {
        #region ---- CONSTANTS ----------------------------------------------------------------------------
        #endregion

        private static byte[] _defaultHeader = new byte[] { 0x02, 0x01, 0xCD, 0x1B };
        private const  byte   _supportedVersion = 0;

        #region ---- MEMBERS ------------------------------------------------------------------------------
        #endregion

        private Dictionary<string, ItemBase> _items;
        
        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="Library"/> class from the specified file.
        /// </summary>
        /// <param name="fileName">The name of the file.</param>
        public Library(string fileName)
            : this(new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Library"/> class from the specified
        /// stream.
        /// </summary>
        /// <param name="stream">The stream to read from.</param>
        public Library(Stream stream)
        {
            using (BinaryReader reader = new BinaryReader(stream))
            {
                // Check header
                byte[] header = reader.ReadBytes(4);
                if (!header.SequenceEqual(_defaultHeader))
                {
                    throw new InvalidDataException("Invalid header.");
                }

                // Check version
                byte version = reader.ReadByte();
                if (version != _supportedVersion)
                {
                    throw new InvalidDataException("Unsupported version.");
                }

                // Item count
                int itemCount = reader.ReadInt32();
                _items = new Dictionary<string, ItemBase>(itemCount);

                // Read in all items
                for (int i = 0; i < itemCount; i++)
                {
                    LibraryItemType itemType = (LibraryItemType)reader.ReadByte();
                    string itemName = reader.ReadString(BinaryStringFormat.WordLengthPrefix);

                    switch (itemType)
                    {
                        case LibraryItemType.File:
                            _items[itemName] = new FileItem(reader.BaseStream);
                            break;
                        case LibraryItemType.Script:
                            _items[itemName] = new ScriptItem(reader.BaseStream);
                            break;
                        case LibraryItemType.Weapon:
                            _items[itemName] = new WeaponItem(reader.BaseStream);
                            break;
                    }
                }
            }
        }

    }
}
