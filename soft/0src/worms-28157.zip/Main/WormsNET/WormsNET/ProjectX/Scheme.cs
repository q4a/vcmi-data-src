﻿namespace WormsNET.ProjectX
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Represents a ProjectX scheme with weapon tables, scripts, attached files and scheme
    /// settings.
    /// S. http://worms2d.info/Project_X/Scheme_file.
    /// </summary>
    public class Scheme
    {
    }
}
