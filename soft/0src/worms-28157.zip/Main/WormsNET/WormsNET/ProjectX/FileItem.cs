﻿namespace WormsNET.ProjectX
{
    using System.IO;

    /// <summary>
    /// Represents a file attachment entry in a ProjectX scheme or library.
    /// </summary>
    internal class FileItem : ItemBase
    {
        #region ---- MEMBERS ------------------------------------------------------------------------------
        #endregion

        private byte[] _data;

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="FileItem"/> class from the specified
        /// stream.
        /// </summary>
        /// <param name="stream">The stream to read the file data from.</param>
        internal FileItem(Stream stream)
            : base(stream)
        {
            int length = stream.ReadByte();
            stream.Read(_data, 0, length);
        }

        #region ---- PROPERTIES ---------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Gets or sets the bytes making up the file data.
        /// </summary>
        internal byte[] Data
        {
            get { return _data; }
            set { _data = value; }
        }
    }
}
