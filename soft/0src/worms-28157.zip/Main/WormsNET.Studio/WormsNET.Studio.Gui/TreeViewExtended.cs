﻿using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Windows.Forms;
using WormsNET.Studio.Gui.Native;

namespace WormsNET.Studio.Gui
{
    /// <summary>
    /// Extended System.Windows.Forms.TreeView.
    /// </summary>
    [ToolboxBitmap(typeof(TreeView))]
    public class TreeViewExtended : TreeView
    {
        #region ---- ENUMERATIONS -------------------------------------------------------------------------
        #endregion

        private enum PrintFlags : uint
        {
            Client = 0x00000004
        }

        private enum WindowsMessage : uint
        {
            PrintClient = 0x00000318
        }

        #region ---- FIELDS -------------------------------------------------------------------------------
        #endregion

        private bool _multiSelect;

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="TreeViewExtended" /> class.
        /// </summary>
        public TreeViewExtended()
        {
            // Flimmern verhindern durch Doppelpufferung
            SetStyle(ControlStyles.AllPaintingInWmPaint
                | ControlStyles.OptimizedDoubleBuffer
                | ControlStyles.UserPaint, true);

            // Neue Standardwerte für Eigenschaften setzen
            HideSelection = false;
            HotTracking = true;
            ShowLines = false;
        }

        #region ---- METHODS (PROTECTED) ------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Raises the HandleCreated event.
        /// </summary>
        /// <param name="e">The EventArgs.</param>
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);

            // Apply visual styles
            NativeMethods.ApplyVisualStyles(this);
            AddExtendedStyle(TreeViewStyleExtended.DoubleBuffer | TreeViewStyleExtended.AutoHScroll
                | TreeViewStyleExtended.FadeInOutExpandos);
        }

        /// <summary>
        /// Raises the Paint event.
        /// </summary>
        /// <param name="e">The PaintEventArgs.</param>
        protected override void OnPaint(PaintEventArgs e)
        {
            if (e != null)
            {
                // Send windows message to draw the control
                Message msg = new Message();
                msg.HWnd = Handle;
                msg.Msg = (int)WindowsMessage.PrintClient;
                msg.WParam = e.Graphics.GetHdc();
                msg.LParam = (IntPtr)PrintFlags.Client;
                DefWndProc(ref msg);

                e.Graphics.ReleaseHdc(msg.WParam);
            }

            base.OnPaint(e);
        }

        #region ---- PROPERTIES ---------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Gets or sets a value indicating whether the selection is hidden if the control has no
        /// focus.
        /// </summary>
        [DefaultValue(false)]
        public new bool HideSelection
        {
            get { return base.HideSelection; }
            set { base.HideSelection = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether items should be hot tracked by the mouse.
        /// </summary>
        [DefaultValue(true)]
        public new bool HotTracking
        {
            get { return base.HotTracking; }
            set { base.HotTracking = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether multiple nodes can be selected at the same
        /// time.
        /// </summary>
        [SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly",
            MessageId = "Multi", Justification = "Multi is not hungarian notation.")]
        [Category("Behavior")]
        [DefaultValue(false)]
        [Description("Determines wether multiple nodes can be selected at the same time or not.")]
        public bool MultiSelect
        {
            get
            {
                return _multiSelect;
            }
            set
            {
                _multiSelect = value;
                if (value)
                {
                    AddExtendedStyle(TreeViewStyleExtended.MultiSelect);
                }
                else
                {
                    RemoveExtendedStyle(TreeViewStyleExtended.MultiSelect);
                }
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether item lines will be drawn.
        /// </summary>
        [DefaultValue(false)]
        public new bool ShowLines
        {
            get { return base.ShowLines; }
            set { base.ShowLines = value; }
        }

        /// <summary>
        /// Control creation parameters.
        /// </summary>
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams createParams = base.CreateParams;

                // Only apply other effects on Windows Vista and newer
                if (Environment.OSVersion.Version.Major >= 6)
                {
                    createParams.Style |= 0x8000;
                }

                return createParams;
            }
        }

        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        private void AddExtendedStyle(TreeViewStyleExtended style)
        {
            // Extended styles are supported since Windows Vista
            if (Environment.OSVersion.Version.Major >= 6)
            {
                // Get the current extended style with lParam
                IntPtr lParam = NativeMethods.SendWindowsMessage(Handle, 0x112d, 0, 0);

                // Merge current style with new style and set it
                int extendedStyle = lParam.ToInt32() | (int)style;
                NativeMethods.SendWindowsMessage(Handle, 0x112c, 0, extendedStyle);
            }
        }

        private void RemoveExtendedStyle(TreeViewStyleExtended style)
        {
            // Extended styles are supported since Windows Vista
            if (Environment.OSVersion.Version.Major >= 6)
            {
                // Get the current extended style with lParam
                IntPtr lParam = NativeMethods.SendWindowsMessage(Handle, 0x112d, 0, 0);

                // Merge current style with new style and set it
                int extendedStyle = lParam.ToInt32();
                extendedStyle &= ~(int)style;
                NativeMethods.SendWindowsMessage(Handle, 0x112c, 0, extendedStyle);
            }
        }
    }
}
