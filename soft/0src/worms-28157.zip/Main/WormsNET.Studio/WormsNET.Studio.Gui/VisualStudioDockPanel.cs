﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using WormsNET.Studio.Gui.Properties;

namespace WormsNET.Studio.Gui
{
    /// <summary>
    /// DockPanel with Visual Studio 2013 style.
    /// </summary>
    public class VisualStudioDockPanel : DockPanel
    {
        #region ---- CONSTANTS ----------------------------------------------------------------------------
        #endregion

        private static readonly Color _borderColor            = Color.FromArgb(204, 206, 219);
        private static readonly Color _titleBarBackColor      = Color.FromArgb(  0, 122, 204);
        private static readonly Color _titleBarForeColor      = Color.FromArgb(255, 255, 255);
        private static readonly Color _titleBarGripColor      = Color.FromArgb( 89, 168, 222);
        private static readonly Color _buttonHoverBackColor   = Color.FromArgb( 82, 176, 239);
        private static readonly Color _buttonPressedBackColor = Color.FromArgb( 14,  97, 152);

        private static readonly Pen _borderPen
            = new Pen(_borderColor);
        private static readonly SolidBrush _titleBarBackBrush
            = new SolidBrush(_titleBarBackColor);
        private static readonly SolidBrush _buttonHoverBackBrush
            = new SolidBrush(_buttonHoverBackColor);
        private static readonly SolidBrush _buttonPressedBackBrush
            = new SolidBrush(_buttonPressedBackColor);
        private static readonly HatchBrush _titleBarGripBrush
            = new HatchBrush(HatchStyle.Percent20, _titleBarGripColor, _titleBarBackColor);

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        public VisualStudioDockPanel()
        {
            Padding = new Padding(1);
        }

        #region ---- METHODS (PROTECTED) ------------------------------------------------------------------
        #endregion

        protected override void OnDrawBorder(PaintEventArgs e)
        {
            e.Graphics.DrawRectangle(_borderPen, new Rectangle(
                e.ClipRectangle.X, e.ClipRectangle.Y,
                e.ClipRectangle.Width - 1, e.ClipRectangle.Height - 1));
        }

        protected override void OnDrawSplitter(PaintEventArgs e)
        {
        }

        protected override void OnDrawTitleBar(PaintEventArgs e)
        {
            e.Graphics.FillRectangle(_titleBarBackBrush, e.ClipRectangle);
        }

        protected override void OnDrawTitleBarText(PaintEventArgs e)
        {
            TextRenderer.DrawText(e.Graphics, Text, Font, e.ClipRectangle, _titleBarForeColor,
                TextFormatFlags.EndEllipsis);

            Size textSize = TextRenderer.MeasureText(Text, Font);
            Rectangle gripArea = new Rectangle(e.ClipRectangle.X + textSize.Width + 4,
                e.ClipRectangle.Y + 5, e.ClipRectangle.Width - textSize.Width - 9, 5);
            e.Graphics.RenderingOrigin = new Point(2, 1);
            e.Graphics.FillRectangle(_titleBarGripBrush, gripArea);
        }

        protected override void OnDrawDropButton(PaintEventArgs e)
        {
            DrawButton(e, Resources.PanelDrop);
        }

        protected override void OnDrawCloseButton(PaintEventArgs e)
        {
            DrawButton(e, Resources.PanelClose);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            Refresh();
        }

        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        private void DrawButton(PaintEventArgs e, Bitmap image)
        {
            SolidBrush backBrush = _titleBarBackBrush;
            if (PointToClient(MousePosition).InRectangle(e.ClipRectangle))
            {
                if (MouseButtons == MouseButtons.Left)
                {
                    backBrush = _buttonPressedBackBrush;
                }
                else
                {
                    backBrush = _buttonHoverBackBrush;
                }
            }
            e.Graphics.FillRectangle(backBrush, e.ClipRectangle);

            e.Graphics.DrawImage(image, e.ClipRectangle);
        }
    }
}
