﻿using System.Drawing;
using System.Windows.Forms;

namespace WormsNET.Studio.Gui
{
    /// <summary>
    /// Extension class for System.Drawing.Rectangle.
    /// </summary>
    public static class RectangleExtensions
    {
        #region ---- METHODS (PUBLIC) ---------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Inflates the rectangle with the specified padding.
        /// </summary>
        /// <param name="rectangle">The extended Rectangle.</param>
        /// <param name="padding">The padding which inflates the rectangle.</param>
        /// <returns>The rectangle resized conforming to the specified padding.</returns>
        public static Rectangle Inflate(this Rectangle rectangle, Padding padding)
        {
            return new Rectangle(rectangle.X - padding.Left, rectangle.Y - padding.Top,
                rectangle.Width + padding.Left + padding.Right,
                rectangle.Height + padding.Top + padding.Bottom);
        }

        /// <summary>
        /// Deflates the rectangle with the specified padding.
        /// </summary>
        /// <param name="rectangle">The extended Rectangle.</param>
        /// <param name="padding">The padding which deflates the rectangle.</param>
        /// <returns>The rectangle resized conforming to the specified padding.</returns>
        public static Rectangle Deflate(this Rectangle rectangle, Padding padding)
        {
            return new Rectangle(rectangle.X + padding.Left, rectangle.Y + padding.Top,
                rectangle.Width - padding.Left - padding.Right,
                rectangle.Height - padding.Top - padding.Bottom);
        }
    }
}
