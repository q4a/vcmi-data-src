﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace WormsNET.Studio.Gui
{
    /// <summary>
    /// Treeview displaying the environments contents.
    /// </summary>
    public class VisualStudioTreeView : TreeViewExtended
    {
        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="VisualStudioTreeView"/> class.
        /// </summary>
        public VisualStudioTreeView()
        {
            BackColor = Color.FromArgb(246, 246, 246);
            ForeColor = Color.FromArgb(30, 30, 30);
            BorderStyle = BorderStyle.None;
            FullRowSelect = true;
            LabelEdit = true;
            ShowLines = false;
            ShowRootLines = false;

            ImageList = new ImageList();
            ImageList.ColorDepth = ColorDepth.Depth32Bit;
            ImageList.ImageSize = new Size(16, 16);
        }

        #region ---- PROPERTIES ---------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Refreshes all nodes.
        /// </summary>
        internal new void Refresh()
        {
            CreateNodes();
        }

        #region ---- METHODS (PROTECTED) ------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Raises the MouseClick event.
        /// </summary>
        /// <param name="e">The MouseEventArgs.</param>
        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);

            if (e.Button == MouseButtons.Right)
            {
                SelectedNode = GetNodeAt(e.Location);
            }
        }

        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        private void CreateNodes()
        {
            Nodes.Clear();
        }
    }
}
