﻿using System;
using System.Drawing;
using System.Windows.Forms;
using WormsNET.Studio.Gui.Native;

namespace WormsNET.Studio.Gui
{
    /// <summary>
    /// Native window intercepting messages sent to an MdiClient of a FormExtended.
    /// </summary>
    internal class MdiClientNativeWindow : NativeWindow, IDisposable
    {
        #region ---- FIELDS -------------------------------------------------------------------------------
        #endregion

        private FormExtended  _parentForm;
        private MdiClient _mdiClient;
        private Bitmap    _backgroundBuffer;
        private bool      _forceUpdate;

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="MdiClientNativeWindow" /> class
        /// registering the message loop for the specified MdiClient on the specified
        /// VibeForm.
        /// </summary>
        /// <param name="parentForm">The parent form containing the properties to control the
        /// advanced MdiClient options.</param>
        /// <param name="mdiClient">The MdiClient which message loop will be connected.</param>
        internal MdiClientNativeWindow(FormExtended parentForm, MdiClient mdiClient)
        {
            if (parentForm == null)
            {
                throw new ArgumentNullException("parentForm");
            }
            if (mdiClient == null)
            {
                throw new ArgumentNullException("mdiClient");
            }

            _parentForm = parentForm;
            _mdiClient = mdiClient;
            AssignHandle(_mdiClient.Handle);
        }

        #region ---- EVENTS -------------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Raised after the MDI client background has been painted.
        /// </summary>
        internal event PaintEventHandler Paint;

        #region ---- METHODS (PUBLIC) ---------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Cleans up ressources.
        /// </summary>
        public void Dispose()
        {
            _backgroundBuffer.Dispose();
        }

        #region ---- METHODS (INTERNAL) -------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Forces the background graphics being redrawn even when the MDI container size hasn't
        /// changed.
        /// </summary>
        internal void ForceUpdate()
        {
            _forceUpdate = true;
            _mdiClient.Invalidate(false);
        }

        #region ---- METHODS (PROTECTED) ------------------------------------------------------------------
        #endregion

        /// <summary>
        /// The Windows message loop.
        /// </summary>
        /// <param name="m">The message sent.</param>
        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case (int)WindowsMessage.NcCalcSize:
                    // Remove scrollbars every time the nonclient area is calculated
                    if (!_parentForm.MdiContainerAutoScroll)
                    {
                        NativeMethods.SetScrollBarVisibility(m.HWnd, Native.ScrollBar.Both,
                            false);
                    }
                    return;

                case (int)WindowsMessage.EraseBkgnd:
                    // Ignore the background clear event and do everything in Paint
                    return;

                case (int)WindowsMessage.Paint:
                    // Draw the background of the MdiClient double buffered
                    PAINTSTRUCT paintStruct = new PAINTSTRUCT();
                    IntPtr deviceContext = NativeMethods.BeginPainting(m.HWnd, ref paintStruct);
                    using (Graphics gr = Graphics.FromHdc(deviceContext))
                    {
                        Size mdiSize = _mdiClient.ClientSize;
                        // Recreate the buffer only if the MdiClient's size has changed
                        if ((_forceUpdate || _backgroundBuffer == null || _backgroundBuffer.Size
                            != mdiSize) && mdiSize.Width > 0 && mdiSize.Height > 0)
                        {
                            _forceUpdate = false;
                            _backgroundBuffer = new Bitmap(mdiSize.Width, mdiSize.Height);
                            using (Graphics bufferGraphics = Graphics.FromImage(_backgroundBuffer))
                            {
                                // Draw background and raise Paint event
                                DrawBackground(bufferGraphics);
                                using (PaintEventArgs paintEventArgs = new PaintEventArgs(
                                    bufferGraphics, _mdiClient.ClientRectangle))
                                {
                                    OnPaint(paintEventArgs);
                                }
                            }
                        }
                        // Puffer zeichnen
                        gr.DrawImage(_backgroundBuffer, _mdiClient.ClientRectangle);
                    }
                    NativeMethods.EndPainting(m.HWnd, ref paintStruct);
                    return;

                case (int)WindowsMessage.Size:
                    // Resize-redraw method for the MdiClient
                    _mdiClient.Invalidate(false);
                    break;
            }

            base.WndProc(ref m);
        }

        /// <summary>
        /// Raises the Paint event.
        /// </summary>
        /// <param name="e">The PaintEventArgs.</param>
        protected virtual void OnPaint(PaintEventArgs e)
        {
            if (Paint != null)
            {
                Paint(this, e);
            }
        }

        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        private void DrawBackground(Graphics gr)
        {
            gr.Clear(_parentForm.MdiContainerBackColor);
        }
    }
}
