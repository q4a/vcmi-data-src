﻿using System.Drawing;
using System.Windows.Forms;

namespace WormsNET.Studio.Gui
{
    /// <summary>
    /// Extension class for System.Windows.Forms.Padding.
    /// </summary>
    public static class PaddingExtensions
    {
        #region ---- METHODS (PUBLIC) ---------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Returns true, if any of the left, top, right or bottom values has the specified value.
        /// </summary>
        /// <param name="padding">The extended Padding.</param>
        /// <param name="value">The value to check for.</param>
        /// <returns>True, if any of the values is the specified value.</returns>
        public static bool Any(this Padding padding, int value)
        {
            return padding.Left == value || padding.Top == value || padding.Right == value
                || padding.Bottom == value;
        }

        /// <summary>
        /// Converts the padding to a rectangle.
        /// </summary>
        /// <param name="padding">The extended Padding.</param>
        /// <returns>The converted rectangle.</returns>
        public static Rectangle ToRectangle(this Padding padding)
        {
            return new Rectangle(padding.Left, padding.Top, padding.Right - padding.Left,
                padding.Bottom - padding.Top);
        }
    }
}
