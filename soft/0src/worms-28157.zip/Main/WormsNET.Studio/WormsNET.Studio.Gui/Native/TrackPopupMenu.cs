﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The TPM_* constants.
    /// </summary>
    [Flags]
    internal enum TrackPopupMenuFlags : uint
    {
        /// <summary>
        /// The TPM_RIGHTBUTTON constant.
        /// </summary>
        RightButton = 0x00000002,

        /// <summary>
        /// The TPM_RETURNCMD constant.
        /// </summary>
        ReturnCmd = 0x00000100
    }
}
