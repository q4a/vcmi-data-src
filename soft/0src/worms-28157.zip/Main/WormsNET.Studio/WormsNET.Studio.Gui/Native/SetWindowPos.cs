﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The SWP_* constants.
    /// </summary>
    [Flags]
    internal enum SetWindowPos : uint
    {
        /// <summary>
        /// The SWP_NOSIZE constant.
        /// </summary>
        NoSize = 0x00000001,

        /// <summary>
        /// The SWP_NOMOVE constant.
        /// </summary>
        NoMove = 0x00000002,

        /// <summary>
        /// The SWP_NOZORDER constant.
        /// </summary>
        NoZOrder = 0x00000004,

        /// <summary>
        /// The SWP_NOREDRAW constant.
        /// </summary>
        NoRedraw = 0x00000008,

        /// <summary>
        /// The SWP_NOACTIVATE constant.
        /// </summary>
        NoActivate = 0x00000010,

        /// <summary>
        /// The SWP_DRAWFRAME constant.
        /// </summary>
        DrawFrame = 0x00000020,

        /// <summary>
        /// The SWP_FRAMECHANGED constant.
        /// </summary>
        FrameChanged = 0x00000020,

        /// <summary>
        /// The SWP_SHOWWINDOW constant.
        /// </summary>
        ShowWindow = 0x00000040,

        /// <summary>
        /// The SWP_HIDEWINDOW constant.
        /// </summary>
        HideWindow = 0x00000080,

        /// <summary>
        /// The SWP_NOCOPYBITS constant.
        /// </summary>
        NoCopyBits = 0x00000100,

        /// <summary>
        /// The SWP_NOREPOSITION constant.
        /// </summary>
        NoReposition = 0x00000200,

        /// <summary>
        /// The SWP_NOOWNERZORDER constant.
        /// </summary>
        NoOwnerZOrder = 0x00000200,

        /// <summary>
        /// The SWP_NOSENDCHANGING constant.
        /// </summary>
        NoSendChanging = 0x00000400,

        /// <summary>
        /// The SWP_DEFERERASE constant.
        /// </summary>
        DeferErase = 0x00002000,

        /// <summary>
        /// The SWP_ASYNCWINDOWPOS constant.
        /// </summary>
        AsyncWindowPos = 0x00004000,
    }
}
