﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The TVS_EX_* constants.
    /// </summary>
    [Flags]
    internal enum TreeViewStyleExtended : uint
    {
        /// <summary>
        /// The TVS_EX_MULTISELECT constant.
        /// </summary>
        MultiSelect = 0x00000002,

        /// <summary>
        /// The TVS_EX_DOUBLEBUFFER constant.
        /// </summary>
        DoubleBuffer = 0x00000004,

        /// <summary>
        /// The TVS_EX_NOINDENTSATE constant.
        /// </summary>
        NoIndentState = 0x00000008,
        
        /// <summary>
        /// The TVS_EX_RICHTOOLTIP constant.
        /// </summary>
        RichToolTip = 0x00000010,

        /// <summary>
        /// The TVS_EX_AUTOHSCROLL constant.
        /// </summary>
        AutoHScroll = 0x00000020,

        /// <summary>
        /// The TVS_EX_FADEINOUTEXPANDOS constant.
        /// </summary>
        FadeInOutExpandos = 0x00000040,

        /// <summary>
        /// The TVS_EX_PARTIALCHECKBOXES constant.
        /// </summary>
        PartialCheckBoxes = 0x00000080,

        /// <summary>
        /// The TVS_EX_EXCLUSIONCHECKBOXES constant.
        /// </summary>
        ExclusionCheckBoxes = 0x00000100,

        /// <summary>
        /// The TVS_EX_DIMMEDCHECKBOXES constant.
        /// </summary>
        DimmedCheckBoxes = 0x00000200,

        /// <summary>
        /// The TVS_EX_DRAWIMAGEASYNC constant.
        /// </summary>
        DrawImageAsync = 0x00000400
    }
}
