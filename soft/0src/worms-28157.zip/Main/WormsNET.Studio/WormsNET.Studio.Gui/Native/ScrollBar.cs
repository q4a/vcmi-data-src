﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The SB_* constants.
    /// </summary>
    internal enum ScrollBar : int
    {
        /// <summary>
        /// The SB_HORZ constant.
        /// </summary>
        Horizontal = 0x00000000,

        /// <summary>
        /// The SB_VERT constant.
        /// </summary>
        Vertical = 0x00000001,

        /// <summary>
        /// The SB_CTL constant.
        /// </summary>
        Control = 0x00000002,

        /// <summary>
        /// The SB_BOTH constant.
        /// </summary>
        Both = 0x00000003
    }
}
