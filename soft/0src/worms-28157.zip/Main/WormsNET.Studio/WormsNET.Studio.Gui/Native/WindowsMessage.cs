﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The WM_* constants.
    /// </summary>
    internal enum WindowsMessage : uint
    {
        /// <summary>
        /// The WM_SIZE constant.
        /// </summary>
        Size = 0x00000005,

        /// <summary>
        /// The WM_SETREDRAW constant.
        /// </summary>
        SetRedraw = 0x0000000B,

        /// <summary>
        /// The WM_PAINT constant.
        /// </summary>
        Paint = 0x0000000F,

        /// <summary>
        /// The WM_ERASEBKGND constant.
        /// </summary>
        EraseBkgnd = 0x00000014,

        /// <summary>
        /// The WM_NCCALCSIZE constant.
        /// </summary>
        NcCalcSize = 0x00000083,

        /// <summary>
        /// The WM_NCHITTEST constant.
        /// </summary>
        NcHitTest = 0x00000084,
        
        /// <summary>
        /// The WM_NCLBUTTONDOWN constant.
        /// </summary>
        NcLButtonDown = 0x000000A1,

        /// <summary>
        /// The WM_NCRBUTTONDOWN constant.
        /// </summary>
        NcRButtonDown = 0x000000A4,
        
        /// <summary>
        /// The WM_SYSCOMMAND constant.
        /// </summary>
        SysCommand = 0x00000112,

        /// <summary>
        /// The WM_CHANGEUISTATE constant.
        /// </summary>
        ChangeUIState = 0x00000127,
        
        /// <summary>
        /// The WM_LBUTTONUP constant.
        /// </summary>
        LButtonUp = 0x00000202,

        /// <summary>
        /// The WM_RBUTTONUP constant.
        /// </summary>
        RButtonUp = 0x00000205,

        /// <summary>
        /// The WM_RBUTTONUP constant.
        /// </summary>
        MButtonUp = 0x00000208,

        /// <summary>
        /// The WM_DWMCOMPOSITIONCHANGED constant.
        /// </summary>
        DwmCompositionChanged = 0x0000031E
    }
}
