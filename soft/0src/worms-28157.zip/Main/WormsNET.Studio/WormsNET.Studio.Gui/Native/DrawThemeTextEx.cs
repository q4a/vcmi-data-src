﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    internal enum DrawThemeTextFlags : uint
    {
        TextColor = 0x00000001,

        GlowSize = 0x00000800,

        Composited = 0x00002000
    }
}
