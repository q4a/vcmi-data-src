﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The AW_* constants.
    /// </summary>
    internal enum AnimateWindow : uint
    {
        /// <summary>
        /// The AW_HOR_POSITIVE constant.
        /// </summary>
        HorizontalPositive = 0x00000001,

        /// <summary>
        /// The AW_HOR_NEGATIVE constant.
        /// </summary>
        HorizontalNegative = 0x00000002,
        
        /// <summary>
        /// The AW_VER_POSITIVE constant.
        /// </summary>
        VerticalPositive = 0x00000004,

        /// <summary>
        /// The AW_VER_NEGATIVE constant.
        /// </summary>
        VerticalNegative = 0x0000008,

        /// <summary>
        /// The AW_CENTER constant.
        /// </summary>
        Center = 0x00000010,

        /// <summary>
        /// The AW_HIDE constant.
        /// </summary>
        Hide = 0x00010000,
        
        /// <summary>
        /// The AW_ACTIVATE constant.
        /// </summary>
        Activate = 0x00020000,
        
        /// <summary>
        /// The AW_SLIDE constant.
        /// </summary>
        Slide = 0x00040000,

        /// <summary>
        /// The AW_BLEND constant.
        /// </summary>
        Blend = 0x00080000
    }
}
