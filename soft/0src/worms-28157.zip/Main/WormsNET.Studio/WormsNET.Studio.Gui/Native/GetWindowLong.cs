﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The GWL_* constants.
    /// </summary>
    internal enum GetWindowLong : int
    {
        /// <summary>
        /// The GWL_EXSTYLE constant.
        /// </summary>
        ExStyle = -20,

        /// <summary>
        /// The GWL_STYLE constant.
        /// </summary>
        Style = -16
    }
}
