﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The CS_* constants.
    /// </summary>
    [Flags]
    internal enum ClassStyle : uint
    {
        /// <summary>
        /// The CS_DROPSHADOW constant.
        /// </summary>
        DropShadow = 0x00020000
    }
}
