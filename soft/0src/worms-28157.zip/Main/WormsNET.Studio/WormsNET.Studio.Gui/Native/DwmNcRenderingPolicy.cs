﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The DWMNCRP_* constants.
    /// </summary>
    [Flags]
    internal enum DwmNcRenderingPolicy : uint
    {
        /// <summary>
        /// The DWMNCRP_USEWINDOWSTYLE constant.
        /// The non-client rendering area is rendered based on the window style.
        /// </summary>
        UseWindowStyle,

        /// <summary>
        /// The DWMNCRP_DISABLED constant.
        /// The non-client area rendering is disabled; the window style is ignored.
        /// </summary>
        Disabled,

        /// <summary>
        /// The DWMNCRP_ENABLED constant.
        /// The non-client area rendering is enabled; the window style is ignored.
        /// </summary>
        Enabled,

        /// <summary>
        /// The DWMNCRP_LAST constant.
        /// The maximum recognized DWMNCRENDERINGPOLICY value, used for validation purposes.
        /// </summary>
        Last
    }
}
