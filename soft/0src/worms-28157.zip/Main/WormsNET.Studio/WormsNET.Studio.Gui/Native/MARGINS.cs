﻿using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace WormsNET.Studio.Gui.Native
{
    [StructLayout(LayoutKind.Sequential)]
    internal struct MARGINS
    {
        #region ---- FIELDS -------------------------------------------------------------------------------
        #endregion

        internal int LeftWidth;
        internal int RightWidth;
        internal int TopHeight;
        internal int BottomHeight;

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="MARGINS" /> struct by converting the
        /// specified padding.
        /// </summary>
        /// <param name="padding">The padding from which the MARGINS will be built.</param>
        internal MARGINS(Padding padding)
        {
            LeftWidth = padding.Left;
            RightWidth = padding.Right;
            TopHeight = padding.Top;
            BottomHeight = padding.Bottom;
        }
    }
}
