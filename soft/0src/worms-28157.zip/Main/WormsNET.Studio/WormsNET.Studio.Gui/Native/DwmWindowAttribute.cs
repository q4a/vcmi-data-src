﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The DWMWA_* constants.
    /// </summary>
    [Flags]
    internal enum DwmWindowAttribute : uint
    {
        /// <summary>
        /// The DWMWA_NCRENDERING_ENABLED constant.
        /// </summary>
        NcRenderingEnabled = 1,

        /// <summary>
        /// The DWMWA_NCRENDERING_POLICY constant.
        /// </summary>
        NcRenderingPolicy,

        /// <summary>
        /// The DWMWA_TRANSITIONS_FORCEDISABLED constant.
        /// </summary>
        TransitionsForceDisabled,

        /// <summary>
        /// The DWMWA_ALLOW_NCPAINT constant.
        /// </summary>
        AllowNcPaint,

        /// <summary>
        /// The DWMWA_CAPTION_BUTTON_BOUNDS constant.
        /// </summary>
        CaptionButtonBounds,

        /// <summary>
        /// The DWMWA_NONCLIENT_RTL_LAYOUT constant.
        /// </summary>
        NonClientRtlLayout,

        /// <summary>
        /// The DWMWA_FORCE_ICONIC_REPRESENTATION constant.
        /// </summary>
        ForceIconicRepresentation,

        /// <summary>
        /// The DWMWA_FLIP3D_POLICY constant.
        /// </summary>
        Flip3DPolicy,

        /// <summary>
        /// The DWMWA_EXTENDED_FRAME_BOUNDS constant.
        /// </summary>
        ExtendedFrameBounds,

        /// <summary>
        /// The DWMWA_HAS_ICONIC_BITMAP constant.
        /// </summary>
        HasIconicBitmap,

        /// <summary>
        /// The DWMWA_DISALLOW_PEEK constant.
        /// </summary>
        DisallowPeek,

        /// <summary>
        /// The DWMA_EXCLUDED_FROM_PEEK constant.
        /// </summary>
        ExcludedFromPeek,

        /// <summary>
        /// The DWMWA_CLOAK constant.
        /// </summary>
        Cloak,

        /// <summary>
        /// The DWMWA_CLOAKED constant.
        /// </summary>
        Cloaked,

        /// <summary>
        /// The DWMWA_FREEZE_REPRESENTATION constant.
        /// </summary>
        Freeze_Representation,
        
        /// <summary>
        /// The DWMWA_LAST constant.
        /// </summary>
        Last
    }
}
