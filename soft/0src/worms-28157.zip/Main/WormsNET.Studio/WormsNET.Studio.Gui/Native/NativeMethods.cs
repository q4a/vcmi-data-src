﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// Static class containing methods of native / WinAPI libraries.
    /// </summary>
    internal static class NativeMethods
    {
        #region ---- CONSTANTS ----------------------------------------------------------------------------
        #endregion

        private const int SUCCESS = 0x00000000;
        private const int SRCCOPY = 0x00CC0020;

        #region ---- DELEGATES ----------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Delegate for a subclassed window procedure.
        /// </summary>
        /// <param name="hWnd">The handle of the subclassed window.</param>
        /// <param name="uMsg">The message being passed.</param>
        /// <param name="wParam">First additional message information.</param>
        /// <param name="lParam">Second additional message information.</param>
        /// <param name="uIdSubclass">The subclass ID.</param>
        /// <param name="dwRefData">The reference data provided to the SetWindowSubclass function.</param>
        /// <returns>The return value is the result of the message processing and depends on the
        /// message sent.</returns>
        public delegate int SubWndProc(IntPtr hWnd, IntPtr uMsg, IntPtr wParam,
            IntPtr lParam, IntPtr uIdSubclass, IntPtr dwRefData);

        #region ---- METHODS (INTERNAL) -------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Adds the specified window procedure to the specified control making it possible to
        /// intercept messages.
        /// </summary>
        /// <param name="control">The control which will have the window procedure added.</param>
        /// <param name="windowProcedure">The window procedure to be added.</param>
        /// <param name="procedureID">The ID of the window procedure addition process.</param>
        internal static void AddWindowProcedure(Control control, SubWndProc windowProcedure,
            IntPtr procedureID)
        {
            if (control == null)
            {
                throw new ArgumentNullException("control");
            }
            if (windowProcedure == null)
            {
                throw new ArgumentNullException("windowProcedure");
            }
            if (procedureID == null)
            {
                throw new ArgumentNullException("procedureID");
            }

            if (!SetWindowSubclass(control.Handle, windowProcedure, procedureID, IntPtr.Zero))
            {
                throw new Win32Exception("SetWindowSubclass");
            }
        }
            
        /// <summary>
        /// Gets or sets a value indicating whether Aero is enabled system-wide or not. Setting
        /// this property is only supported in Windows Vista and Windows 7.
        /// </summary>
        internal static bool AeroGlassEnabled
        {
            get
            {
                // Systems earlier than Windows Vista do not support Glass
                if (Environment.OSVersion.Version.Major < 6)
                {
                    return false;
                }

                bool aeroEnabled = false;
                int result = DwmIsCompositionEnabled(out aeroEnabled);
                if (result != SUCCESS)
                {
                    throw new Win32Exception(result, "DwmIsCompositionEnabled");
                }
                return aeroEnabled;
            }
            set
            {
                if (Environment.OSVersion.Version.Major >= 6
                    && Environment.OSVersion.Version.Minor >= 0
                    && Environment.OSVersion.Version.Minor <= 1)
                {
                    uint hResult = DwmEnableComposition(value ? 1 : 0);
                    if (hResult != SUCCESS)
                    {
                        throw new Win32Exception((int)hResult, "DwmEnableComposition");
                    }
                }
            }
        }

        /// <summary>
        /// Animates the form with the specified animation for the specified duration.
        /// </summary>
        /// <param name="form">The form which will be faded in.</param>
        /// <param name="animation">The animation which will be used.</param>
        /// <param name="duration">The length of the animation.</param>
        internal static void AnimateWindow(Form form, AnimateWindow animation, int duration)
        {
            AnimateWindow(form.Handle, (uint)duration, (uint)animation);
        }

        /// <summary>
        /// Applies visual styles on the specified control.
        /// </summary>
        /// <param name="control">The control on which visual styles are applied.</param>
        internal static void ApplyVisualStyles(Control control)
        {
            if (control == null)
            {
                throw new ArgumentNullException("control");
            }

            int hResult = NativeMethods.SetWindowTheme(control.Handle, "explorer", null);
            if (hResult != SUCCESS)
            {
                throw new Win32Exception(hResult, "SetWindowTheme");
            }
        }

        /// <summary>
        /// Initializes the painting on the control with the specified handle and returns the
        /// PaintStruct required to end the painting progress again and the device display context
        /// needed for painting operations.
        /// </summary>
        /// <param name="handle">The handle of the control on which will be painted.</param>
        /// <param name="paintStruct">The PaintStruct required to end the painting.</param>
        /// <returns>The device display context needed for painting operations.</returns>
        internal static IntPtr BeginPainting(IntPtr handle, ref PAINTSTRUCT paintStruct)
        {
            IntPtr deviceContext = BeginPaint(handle, ref paintStruct);
            if (deviceContext == null)
            {
                throw new Win32Exception("BeginPaint");
            }
            return deviceContext;
        }

        /// <summary>
        /// Performs a bit-block transfer of the color data corresponding to a rectangle of pixels
        /// from the specified source device context into a destination device context.
        /// </summary>
        /// <param name="destinationHandle">A handle to the destination device context.</param>
        /// <param name="destinationBounds">The destination area into which will be blitted.</param>
        /// <param name="sourceHandle">A handle to the source device context.</param>
        /// <param name="sourceLocation">The source location from which will be blitted.</param>
        internal static void BitBlit(IntPtr destinationHandle, Rectangle destinationBounds,
            IntPtr sourceHandle, Point sourceLocation)
        {
            if (!BitBlt(destinationHandle, destinationBounds.X, destinationBounds.Y,
                destinationBounds.Width, destinationBounds.Height, sourceHandle, sourceLocation.X,
                sourceLocation.Y, SRCCOPY))
            {
                throw new Win32Exception("BitBlt");
            }
        }

        /// <summary>
        /// This function creates a memory device context compatible with the specified device.
        /// </summary>
        /// <param name="handle">Handle to an existing device context.</param>
        /// <returns>The handle to a memory device context.</returns>
        internal static IntPtr CreateCompatibleGdiDeviceContext(IntPtr handle)
        {
            IntPtr dcHandle = CreateCompatibleDC(handle);
            if (dcHandle == IntPtr.Zero)
            {
                throw new Win32Exception("CreateCompatibleDC");
            }
            return dcHandle;
        }

        /// <summary>
        /// Returns a DIB that applications can write to directly.
        /// </summary>
        /// <param name="handle">A handle to a device context.</param>
        /// <param name="bitmapInfo">Specifies various attributes of the DIB, including the bitmap
        /// dimensions and colors.</param>
        /// <returns>A handle to the newly created DIB.</returns>
        internal static IntPtr CreateDIBSection(IntPtr handle, ref BITMAPINFO bitmapInfo)
        {
            IntPtr ppvBits = new IntPtr(0);
            IntPtr dibSection = NativeMethods.CreateDIBSection(handle, ref bitmapInfo, 0,
                out ppvBits, IntPtr.Zero, 0);
            if (dibSection == IntPtr.Zero)
            {
                throw new Win32Exception("CreateDIBSection");
            }
            return dibSection;
        }

        /// <summary>
        /// Deletes the specified device context.
        /// </summary>
        /// <param name="handle">A handle to the device context which should be deleted.</param>
        internal static void DeleteGdiDeviceContext(IntPtr handle)
        {
            if (!DeleteDC(handle))
            {
                throw new Win32Exception("DeleteDC");
            }
        }

        /// <summary>
        /// Deletes the GDI object with the specified handle.
        /// </summary>
        /// <param name="handle">The handle to the GDI object which should be deleted.</param>
        internal static void DeleteGdiObject(IntPtr handle)
        {
            if (!DeleteObject(handle))
            {
                throw new Win32Exception("DeleteObject");
            }
        }

        /// <summary>
        /// Draws theme text with the specified options. This function is only supported on Windows
        /// Vista or newer. A fallback method will be used for older systems.
        /// </summary>
        /// <param name="gr">The Graphics object to draw with.</param>
        /// <param name="text">The text to draw.</param>
        /// <param name="font">The font to use.</param>
        /// <param name="bounds">The bounds in which to draw the text.</param>
        /// <param name="foreColor">The color of the text.</param>
        /// <param name="textFormatFlags">The text drawing options.</param>
        /// <param name="glowSize">The Aero Glass glow size of the text.</param>
        internal static void DrawThemeTextExtended(Graphics gr, string text, Font font,
            Rectangle bounds, Color foreColor, TextFormatFlags textFormatFlags, int glowSize)
        {
            if (gr == null)
            {
                throw new ArgumentNullException("gr");
            }
            if (font == null)
            {
                throw new ArgumentNullException("font");
            }
            if (bounds.Width == 0 || bounds.Height == 0)
            {
                return;
            }

            if (Environment.OSVersion.Version.Major >= 6)
            {
                IntPtr hdc = gr.GetHdc();

                // Generate memory bitmap for drawing operation and select it
                IntPtr bmHdc = NativeMethods.CreateCompatibleGdiDeviceContext(hdc);
                BITMAPINFO info = new BITMAPINFO();
                info.Size = Marshal.SizeOf(info);
                info.Width = bounds.Width;
                info.Height = -bounds.Height;
                info.Planes = 1;
                info.BitCount = 32;

                IntPtr dibSection = NativeMethods.CreateDIBSection(hdc, ref info);
                NativeMethods.SelectGdiObject(bmHdc, dibSection);

                // Create font handle and select it
                IntPtr fontHandle = font.ToHfont();
                NativeMethods.SelectGdiObject(bmHdc, fontHandle);

                // Generate drawing options
                DTTOPTS dttOpts = new DTTOPTS();
                dttOpts.DwSize = Marshal.SizeOf(typeof(DTTOPTS));
                dttOpts.CrText = ColorTranslator.ToWin32(foreColor);
                dttOpts.IGlowSize = glowSize;
                dttOpts.DwFlags = (int)(DrawThemeTextFlags.Composited
                    | DrawThemeTextFlags.TextColor);
                if (glowSize > 0)
                {
                    dttOpts.DwFlags |= (int)DrawThemeTextFlags.GlowSize;
                }
                RECT textBounds = new RECT(bounds);

                VisualStyleRenderer vsr = new VisualStyleRenderer(
                    VisualStyleElement.Window.Caption.Active);

                int result = DrawThemeTextEx(vsr.Handle, bmHdc, 0, 0, text, -1,
                    (int)textFormatFlags, ref textBounds, ref dttOpts);
                if (result != SUCCESS)
                {
                    throw new Win32Exception(result, "DrawThemeTextEx");
                }

                // Copy into the foreground
                NativeMethods.BitBlit(hdc, bounds, bmHdc, Point.Empty);

                // Delete the created drawing objects
                NativeMethods.DeleteGdiObject(fontHandle);
                NativeMethods.DeleteGdiObject(dibSection);
                NativeMethods.DeleteGdiDeviceContext(bmHdc);

                gr.ReleaseHdc(hdc);
            }
            else
            {
                TextRenderer.DrawText(gr, text, font, bounds, foreColor, textFormatFlags);
            }
        }

        /// <summary>
        /// Ends the painting on the control with the specified handle. Requires the paintStruct
        /// created at BeginPainting.
        /// </summary>
        /// <param name="handle">The handle of the control on which was painted.</param>
        /// <param name="paintStruct">The PaintStruct created at BeginPainting.</param>
        internal static void EndPainting(IntPtr handle, ref PAINTSTRUCT paintStruct)
        {
            EndPaint(handle, ref paintStruct);
        }

        /// <summary>
        /// Expands the Aero Glass effect into the client area of the specifed form.
        /// If Aero Glass is not enabled or not supported, nothing will happen.
        /// </summary>
        /// <param name="form">The form which Aero Glass will be expanded.</param>
        /// <param name="padding">The amount of expansion on each side. If one side is negative,
        /// the complete window will be glassy.</param>
        internal static void ExtendAeroGlass(Form form, Padding padding)
        {
            if (AeroGlassEnabled)
            {
                MARGINS margins = new MARGINS(padding);
                int result = DwmExtendFrameIntoClientArea(form.Handle, ref margins);
                if (result != SUCCESS)
                {
                    throw new Win32Exception(result, "DwmExtendFrameIntoClientArea");
                }
            }
        }

        /// <summary>
        /// Gets style informations about the specified control.
        /// </summary>
        /// <param name="control">The control which style informations should be retrieved.</param>
        /// <param name="styleOffset">The style type to be retrieved.</param>
        /// <returns>The style informations.</returns>
        internal static int GetWindowLong(Control control, GetWindowLong styleOffset)
        {
            if (control == null)
            {
                throw new ArgumentNullException("control");
            }

            return GetWindowLong(control.Handle, (int)styleOffset);
        }

        /// <summary>
        /// Releases the mouse capture of other controls.
        /// </summary>
        internal static void ReleaseMouseCapture()
        {
            ReleaseCapture();
        }

        /// <summary>
        /// Places (posts) a message in the message queue associated with the thread that created
        /// the specified window and returns without waiting for the thread to process the message.
        /// </summary>
        /// <param name="handle">A handle to the window whose window procedure is to receive the
        ///     message.</param>
        /// <param name="message">The message to be posted.</param>
        /// <param name="wParam">First additional message-specific information.</param>
        /// <param name="lParam">Second additional message-specific information.</param>
        /// <returns>True, if the function succeeds.</returns>
        internal static bool PostWindowsMessage(IntPtr handle, uint message, int wParam,
            int lParam)
        {
            return PostMessage(handle, message, new IntPtr(wParam), new IntPtr(lParam));
        }

        /// <summary>
        /// Removes the specified additional window procedure from the specified control.
        /// </summary>
        /// <param name="control">The control which additional window procedure will be removed.</param>
        /// <param name="windowProcedure">The additional window procedure which will be removed.</param>
        /// <param name="procedureID">The ID of the window procedure addition process.</param>
        internal static void RemoveWindowProcedure(Control control, SubWndProc windowProcedure,
            IntPtr procedureID)
        {
            if (control == null)
            {
                throw new ArgumentNullException("control");
            }
            if (windowProcedure == null)
            {
                throw new ArgumentNullException("windowProcedure");
            }
            if (procedureID == null)
            {
                throw new ArgumentNullException("procedureID");
            }

            if (!RemoveWindowSubclass(control.Handle, windowProcedure, procedureID))
            {
                throw new Win32Exception("RemoveWindowSubclass");
            }
        }

        /// <summary>
        /// Sends the specified message to a window or windows. The function calls the window
        /// procedure for the specified window and does not return until the window procedure has
        /// processed the message.
        /// </summary>
        /// <param name="handle">A handle to the window whose window procedure will receive the
        ///     message.</param>
        /// <param name="message">The message to be sent.</param>
        /// <param name="wParam">First additional message-specific information.</param>
        /// <param name="lParam">Second additional message-specific information.</param>
        /// <returns>The return value specifies the result of the message processing; it depends on
        /// the message sent.</returns>
        internal static IntPtr SendWindowsMessage(IntPtr handle, uint message, int wParam,
            int lParam)
        {
            return SendWindowsMessage(handle, message, new IntPtr(wParam), new IntPtr(lParam));
        }

        /// <summary>
        /// Sends the specified message to a window or windows. The function calls the window
        /// procedure for the specified window and does not return until the window procedure has
        /// processed the message.
        /// </summary>
        /// <param name="handle">A handle to the window whose window procedure will receive the
        ///     message.</param>
        /// <param name="message">The message to be sent.</param>
        /// <param name="wParam">First additional message-specific information.</param>
        /// <param name="lParam">Second additional message-specific information.</param>
        /// <returns>The return value specifies the result of the message processing; it depends on
        /// the message sent.</returns>
        internal static IntPtr SendWindowsMessage(IntPtr handle, uint message, int wParam,
            IntPtr lParam)
        {
            return SendWindowsMessage(handle, message, new IntPtr(wParam), lParam);
        }

        /// <summary>
        /// Sends the specified message to a window or windows. The function calls the window
        /// procedure for the specified window and does not return until the window procedure has
        /// processed the message.
        /// </summary>
        /// <param name="handle">A handle to the window whose window procedure will receive the
        ///     message.</param>
        /// <param name="message">The message to be sent.</param>
        /// <param name="wParam">First additional message-specific information.</param>
        /// <param name="lParam">Second additional message-specific information.</param>
        /// <returns>The return value specifies the result of the message processing; it depends on
        /// the message sent.</returns>
        internal static IntPtr SendWindowsMessage(IntPtr handle, uint message, IntPtr wParam,
            IntPtr lParam)
        {
            return SendMessage(handle, message, wParam, lParam);
        }

        /// <summary>
        /// Selects an object into the specified device context. The new object replaces the
        /// previous object of the same type.
        /// </summary>
        /// <param name="deviceContext">A handle to the device context.</param>
        /// <param name="handle">A handle to the object to be selected.</param>
        /// <returns>A handle to the object being replaced. </returns>
        internal static IntPtr SelectGdiObject(IntPtr deviceContext, IntPtr handle)
        {
            IntPtr result = SelectObject(deviceContext, handle);
            if (result == IntPtr.Zero)
            {
                throw new Win32Exception("SelectObject");
            }
            return result;
        }

        /// <summary>
        /// Sets the specified Aero property to the specified value on the specified form.
        /// If Aero Glass is not enabled or not supported, nothing will happen.
        /// </summary>
        /// <param name="form">The form which will have its Aero property changed.</param>
        /// <param name="property">The property which will be changed.</param>
        /// <param name="value">The new value of the property.</param>
        internal static void SetAeroWindowProperty(Form form, DwmWindowAttribute property,
            uint value)
        {
            if (AeroGlassEnabled)
            {
                IntPtr valuePointer = Marshal.AllocHGlobal(sizeof(int));
                Marshal.WriteInt32(valuePointer, (int)value);
                int result = DwmSetWindowAttribute(form.Handle, (uint)property, valuePointer,
                    sizeof(int));
                if (result != SUCCESS)
                {
                    throw new Win32Exception(result, "DwmSetWindowAttribtue");
                }
            }
        }

        /// <summary>
        /// Sets the visibility of the specified scrollbars.
        /// </summary>
        /// <param name="handle">The handle of the control on which scrollbars should be shown or
        ///     hidden.</param>
        /// <param name="scrollBars">The scrollbars which should be shown or hidden.</param>
        /// <param name="show">Determines wether to show or hide the scrollbars.</param>
        internal static void SetScrollBarVisibility(IntPtr handle, ScrollBar scrollBars,
            bool show)
        {
            if (!ShowScrollBar(handle, (int)scrollBars, show))
            {
                throw new Win32Exception("ShowScrollBar");
            }
        }

        /// <summary>
        /// Sets the style to the specified control.
        /// </summary>
        /// <param name="control">The control to be manipulated.</param>
        /// <param name="styleOffset">The style type to be set.</param>
        /// <param name="style">The style to be set.</param>
        /// <returns>Returns the specified style if succeeded.</returns>
        internal static int SetWindowLong(Control control, GetWindowLong styleOffset,
            int style)
        {
            if (control == null)
            {
                throw new ArgumentNullException("control");
            }

            return SetWindowLong(control.Handle, (int)styleOffset, style);
        }

        /// <summary>
        /// Sets the controls location, width and z order with the specified flags.
        /// </summary>
        /// <param name="control">The control to be repositioned.</param>
        /// <param name="controlAfter">The control behind the control to be repositioned.</param>
        /// <param name="x">The new X location.</param>
        /// <param name="y">The new Y location.</param>
        /// <param name="width">The new width.</param>
        /// <param name="height">The new height.</param>
        /// <param name="flags">The flags used for repositioning.</param>
        internal static void SetWindowPosition(Control control, Control controlAfter, int x, int y,
            int width, int height, SetWindowPos flags)
        {
            if (control == null)
            {
                throw new ArgumentNullException("control");
            }

            if (!SetWindowPos(control.Handle,
                controlAfter == null ? IntPtr.Zero : controlAfter.Handle,
                x, y, width, height, (uint)flags))
            {
                throw new Win32Exception("SetWindowPos");
            }
        }

        /// <summary>
        /// Shows the window menu at the specified location with the specified options.
        /// </summary>
        /// <param name="form">The window which menu will be shown.</param>
        /// <param name="location">The location at which the menu will be shown.</param>
        /// <returns>The menu item ID of the item the user clicked.</returns>
        internal static int ShowWindowMenu(Form form, Point location)
        {
            IntPtr menuHandle = GetSystemMenu(form.Handle, false);
            RECT rect = new RECT();
            return TrackPopupMenu(menuHandle,
                (uint)(TrackPopupMenuFlags.ReturnCmd | TrackPopupMenuFlags.RightButton),
                location.X, location.Y, 0, form.Handle, ref rect);
        }

        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        [DllImport("user32.dll")]
        private static extern int AnimateWindow(IntPtr hwand, uint dwTime, uint dwFlags);

        [DllImport("user32.dll")]
        private static extern IntPtr BeginPaint(IntPtr hWnd, ref PAINTSTRUCT paintStruct);

        [DllImport("gdi32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool BitBlt(IntPtr hdc, int nXDest, int nYDest, int nWidth,
            int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, uint dwRop);

        [DllImport("gdi32.dll")]
        private static extern IntPtr CreateCompatibleDC(IntPtr hDC);

        [DllImport("gdi32.dll")]
        private static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFO pbmi,
            uint iUsage, out IntPtr ppvBits, IntPtr hSection, uint dwOffset);

        [DllImport("gdi32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool DeleteDC(IntPtr hdc);

        [DllImport("gdi32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool DeleteObject(IntPtr hObject);

        [DllImport("uxtheme.dll", CharSet = CharSet.Unicode, PreserveSig = true)]
        private static extern int DrawThemeTextEx(IntPtr hTheme, IntPtr hdc, int iPartId,
            int iStateId, string text, int iCharCount, int dwFlags, ref RECT pRect,
            ref DTTOPTS pOptions);

        [DllImport("dwmapi.dll", PreserveSig = false)]
        private static extern uint DwmEnableComposition(int compositionAction);

        [DllImport("dwmapi.dll", PreserveSig = false)]
        private static extern int DwmExtendFrameIntoClientArea(IntPtr hwnd, ref MARGINS margins);

        [DllImport("dwmapi.dll", PreserveSig = false)]
        private static extern int DwmIsCompositionEnabled(
            [MarshalAs(UnmanagedType.Bool)]out bool pfEnabled);

        [DllImport("dwmapi.dll", PreserveSig = true)]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, uint dwmAttribute,
            IntPtr pvAttribute, uint cbAttribute);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool EndPaint(IntPtr hWnd, ref PAINTSTRUCT paintStruct);

        [DllImport("user32.dll")]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd,
            [MarshalAs(UnmanagedType.Bool)]bool bRevert);

        [DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, int index);

        [DllImportAttribute("user32.dll")]
        private static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool PostMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

        [DllImport("comctl32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool RemoveWindowSubclass(IntPtr hWnd, SubWndProc subClassProc,
            IntPtr uIdSubclass);

        [DllImport("gdi32.dll")]
        private static extern IntPtr SelectObject(IntPtr hDC, IntPtr hObject);

        [DllImport("user32.dll", CharSet = CharSet.Auto, PreserveSig = false)]
        private static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam,
            IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern int SetWindowLong(IntPtr hWnd, int index, int value);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int x, int y,
            int cx, int cy, uint uFlags);

        [DllImport("comctl32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetWindowSubclass(IntPtr hWnd, SubWndProc subClassProc,
            IntPtr uIdSubclass, IntPtr dwRefData);

        [DllImport("uxtheme.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
        private static extern int SetWindowTheme(IntPtr hwnd,
            [MarshalAs(UnmanagedType.LPWStr)]string pszSubAppName,
            [MarshalAs(UnmanagedType.LPWStr)]string pszSubIdList);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool ShowScrollBar(IntPtr hWnd, int wBar,
            [MarshalAs(UnmanagedType.Bool)]bool bShow);

        [DllImport("user32.dll")]
        private static extern int TrackPopupMenu(IntPtr hMenu, uint wFlags, int x, int y,
            int nReserved, IntPtr hWnd, ref RECT prcRect);
    }
}
