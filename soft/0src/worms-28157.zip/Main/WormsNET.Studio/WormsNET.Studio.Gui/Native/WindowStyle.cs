﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The WS_* constants.
    /// </summary>
    internal enum WindowStyle : uint
    {
        /// <summary>
        /// The WS_BORDER constant.
        /// </summary>
        Border = 0x00800000
    }
}
