﻿using System;
using System.Runtime.InteropServices;

namespace WormsNET.Studio.Gui.Native
{
    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    internal struct PAINTSTRUCT
    {
        public IntPtr Hdc;
        public int FErase;
        public RECT RcPaint;
        public int FRestore;
        public int FIncUpdate;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        public byte[] RgbReserved;
    }
}
