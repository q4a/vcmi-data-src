﻿using System.Runtime.InteropServices;

namespace WormsNET.Studio.Gui.Native
{
    [StructLayout(LayoutKind.Sequential)]
    internal struct POINT
    {
        public int X;
        public int Y;
    }
}
