﻿using System;
using System.Runtime.InteropServices;

namespace WormsNET.Studio.Gui.Native
{
    [StructLayout(LayoutKind.Sequential)]
    internal struct DTTOPTS
    {
        public int DwSize;
        public int DwFlags;
        public int CrText;
        public int CrBorder;
        public int CrShadow;
        public int ITextShadowType;
        public POINT PtShadowOffset;
        public int IBorderSize;
        public int IFontPropId;
        public int IColorPropId;
        public int IStateId;
        public bool FApplyOverlay;
        public int IGlowSize;
        public int PfnDrawTextCallback;
        public IntPtr LParam;
    }
}
