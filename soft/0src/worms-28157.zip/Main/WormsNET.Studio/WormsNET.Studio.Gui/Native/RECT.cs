﻿using System.Drawing;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// A native RECT represents a rectangle.
    /// </summary>
    internal struct RECT
    {
        #region ---- FIELDS -------------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// The X coordinate of the RECT.
        /// </summary>
        public int Left;

        /// <summary>
        /// The Y coordinate of the RECT.
        /// </summary>
        public int Top;

        /// <summary>
        /// The width of the RECT.
        /// </summary>
        public int Right;

        /// <summary>
        /// The height of the RECT.
        /// </summary>
        public int Bottom;

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="RECT" /> struct with the specified
        /// coordinates and sizes.
        /// </summary>
        /// <param name="left">X coordinate.</param>
        /// <param name="top">Y coordinate.</param>
        /// <param name="right">The width.</param>
        /// <param name="bottom">The height.</param>
        public RECT(int left, int top, int right, int bottom)
        {
            Left = left;
            Top = top;
            Right = right;
            Bottom = bottom;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RECT" /> struct from the specified
        /// rectangle.
        /// </summary>
        /// <param name="rectangle">The rectangle to create the RECT from.</param>
        public RECT(Rectangle rectangle)
        {
            Left = rectangle.Left;
            Top = rectangle.Top;
            Right = rectangle.Right - rectangle.Left;
            Bottom = rectangle.Bottom - rectangle.Top;
        }

        #region ---- OPERATORS ----------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Converts a native RECT to a Rectangle.
        /// </summary>
        /// <param name="rect">Native RECT to convert.</param>
        /// <returns>The converted Rectangle.</returns>
        public static implicit operator Rectangle(RECT rect)
        {
            return Rectangle.FromLTRB(rect.Left, rect.Top, rect.Right, rect.Bottom);
        }

        /// <summary>
        /// Converts a Rectangle to a native RECT.
        /// </summary>
        /// <param name="rect">Rectangle to convert.</param>
        /// <returns>The converted RECT.</returns>
        public static implicit operator RECT(Rectangle rect)
        {
            return new RECT(rect.Left, rect.Top, rect.Right, rect.Bottom);
        }
    }
}
