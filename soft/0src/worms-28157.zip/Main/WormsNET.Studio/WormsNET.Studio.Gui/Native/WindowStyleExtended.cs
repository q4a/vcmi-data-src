﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The WS_EX_* constants.
    /// </summary>
    internal enum WindowStyleExtended : int
    {
        /// <summary>
        /// The WS_EX_CLIENTEDGE constant.
        /// </summary>
        ClientEdge = 0x00000200
    }
}
