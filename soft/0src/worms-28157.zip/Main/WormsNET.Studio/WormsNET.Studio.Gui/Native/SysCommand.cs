﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The SC_* constants.
    /// </summary>
    internal enum SysCommand : uint
    {
        /// <summary>
        /// The SC_ISSECURE constant.
        /// Indicates whether the screen saver is secure.
        /// </summary>
        IsSecure = 0x00000001,

        /// <summary>
        /// The SC_SIZE constant.
        /// Sizes the window.
        /// </summary>
        Size = 0x0000F000,

        /// <summary>
        /// The SC_MOVE constant.
        /// Moves the window.
        /// </summary>
        Move = 0x0000F010,

        /// <summary>
        /// The SC_MINIMIZE constant.
        /// Minimizes the window.
        /// </summary>
        Minimize = 0x0000F020,

        /// <summary>
        /// The SC_MAXIMIZE constant.
        /// Maximizes the window.
        /// </summary>
        Maximize = 0x0000F030,

        /// <summary>
        /// The SC_NEXTWINDOW constant.
        /// Moves to the next window.
        /// </summary>
        NextWindow = 0x0000F040,

        /// <summary>
        /// The SC_PREVWINDOW constant.
        /// Moves to the previous window.
        /// </summary>
        PrevWindow = 0x0000F050,

        /// <summary>
        /// The SC_CLOSE constant.
        /// Closes the window.
        /// </summary>
        Close = 0x0000F060,

        /// <summary>
        /// The SC_VSCROLL constant.
        /// Scrolls vertically.
        /// </summary>
        VScroll = 0x0000F070,

        /// <summary>
        /// The SC_HSCROLL constant.
        /// Scrolls horizontally.
        /// </summary>
        HScroll = 0x0000F080,

        /// <summary>
        /// The SC_MOUSEMENU constant.
        /// Retrieves the window menu as a result of a mouse click.
        /// </summary>
        MouseMenu = 0x0000F090,

        /// <summary>
        /// The SC_KEYMENU constant.
        /// Retrieves the window menu as a result of a keystroke.
        /// </summary>
        KeyMenu = 0x0000F100,

        /// <summary>
        /// The SC_RESTORE constant.
        /// Restores the window to its normal position and size.
        /// </summary>
        Restore = 0x0000F120,

        /// <summary>
        /// The SC_TASKLIST constant.
        /// Activates the Start menu.
        /// </summary>
        TaskList = 0x0000F130,

        /// <summary>
        /// The SC_SCREENSAVE constant.
        /// Restores the window to its normal position and size.
        /// </summary>
        ScreenSave = 0x0000F140,

        /// <summary>
        /// The SC_HOTKEY constant.
        /// Activates the window associated with the application-specified hot key. The lParam
        /// parameter identifies the window to activate.
        /// </summary>
        Hotkey = 0x0000F150,

        /// <summary>
        /// The SC_DEFAULT constant.
        /// Selects the default item; the user double-clicked the window menu.
        /// </summary>
        Default = 0x0000F160,

        /// <summary>
        /// The SC_MONITORPOWER constant.
        /// Sets the state of the display. This command supports devices that have power-saving
        /// features, such as a battery-powered personal computer.
        /// </summary>
        MonitorPower = 0x0000F170,

        /// <summary>
        /// The SC_CONTEXTHELP constant.
        /// Changes the cursor to a question mark with a pointer.
        /// </summary>
        ContextHelp = 0x0000F180,
    }
}
