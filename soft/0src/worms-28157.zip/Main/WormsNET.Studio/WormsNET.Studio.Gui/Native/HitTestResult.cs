﻿using System;

namespace WormsNET.Studio.Gui.Native
{
    /// <summary>
    /// The HT_* constants.
    /// </summary>
    [Flags]
    internal enum HitTestResult : uint
    {
        /// <summary>
        /// The HT_CAPTION constant.
        /// </summary>
        Caption = 0x00000002
    }
}
