﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace WormsNET.Studio.Gui
{
    /// <summary>
    /// Panel which has a title bar and a splitter, allowing to be docked in different directions.
    /// </summary>
    [ToolboxBitmap(typeof(Panel))]
    public class DockPanel : Panel
    {
        #region ---- CONSTANTS ----------------------------------------------------------------------------
        #endregion

        private const int               _titleBarHeight = 21;
        private const int               _buttonSize = 15;
        private const int               _splitterSize = 6;
        private static readonly Padding _titleBarPadding = new Padding(-1, -3, -3, -4);
        private static readonly Font    _marlett = new Font("Marlett", 9f);
        
        #region ---- FIELDS -------------------------------------------------------------------------------
        #endregion

        private Rectangle _borderBounds;
        private Rectangle _titleBarBounds;
        private Rectangle _titleBarTextBounds;
        private Rectangle _closeButtonBounds;
        private Rectangle _dropButtonBounds;
        private Rectangle _splitterBounds;

        private Padding   _padding;

        private Rectangle _lastMouseArea;
        private bool      _isDraggingSplitter;

        private bool      _showDropButton;
        private bool      _showCloseButton;

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="DockPanel" /> class.
        /// </summary>
        public DockPanel()
        {
            ShowDropButton = true;
            ShowCloseButton = true;
            Text = Name;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer
                | ControlStyles.ResizeRedraw, true);
            UpdateLayout();
        }

        #region ---- EVENTS -------------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Raised when the user clicked the drop button.
        /// </summary>
        [Category("Action")]
        [Description("Occurs when the user clicked the drop button.")]
        public event EventHandler DropButtonClicked;

        /// <summary>
        /// Raised when the user clicked the close button.
        /// </summary>
        [Category("Action")]
        [Description("Occurs when the user clicked the close button.")]
        public event EventHandler CloseButtonClicked;

        #region ---- PROPERTIES ---------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Gets the area of the border set through padding.
        /// </summary>
        [Browsable(false)]
        public Rectangle BorderBounds
        {
            get { return _borderBounds; }
        }

        /// <summary>
        /// Gets the area of the title bar.
        /// </summary>
        [Browsable(false)]
        public Rectangle TitleBarBounds
        {
            get { return _titleBarBounds; }
        }

        /// <summary>
        /// Gets the are of the title bar text.
        /// </summary>
        [Browsable(false)]
        public Rectangle TitleBarTextBounds
        {
            get { return _titleBarTextBounds; }
        }

        /// <summary>
        /// Gets the area of the drop button.
        /// </summary>
        [Browsable(false)]
        public Rectangle DropButtonBounds
        {
            get { return _dropButtonBounds; }
        }

        /// <summary>
        /// Gets the area of the close button.
        /// </summary>
        [Browsable(false)]
        public Rectangle CloseButtonBounds
        {
            get { return _closeButtonBounds; }
        }

        /// <summary>
        /// Gets the area of the splitter.
        /// </summary>
        [Browsable(false)]
        public Rectangle SplitterBounds
        {
            get { return _splitterBounds; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the drop button is shown.
        /// </summary>
        [Category("Appearance")]
        [DefaultValue(true)]
        [Description("Determines wether the drop button is shown in the titlebar.")]
        public bool ShowDropButton
        {
            get
            {
                return _showDropButton;
            }
            set
            {
                _showDropButton = value;
                UpdateLayout();
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the close button is shown.
        /// </summary>
        [Category("Appearance")]
        [DefaultValue(true)]
        [Description("Determines wether the close button is shown in the titlebar.")]
        public bool ShowCloseButton
        {
            get
            {
                return _showCloseButton;
            }
            set
            {
                _showCloseButton = value;
                UpdateLayout();
            }
        }

        /// <summary>
        /// Gets or sets the titlebar text.
        /// </summary>
        [Browsable(true)]
        [Category("Appearance")]
        [Description("The text displayed in the titlebar.")]
        public override string Text
        {
            get
            {
                return base.Text;
            }
            set
            {
                base.Text = value;
                Refresh();
            }
        }

        /// <summary>
        /// Gets or sets the padding of the dock panel.
        /// </summary>
        public new Padding Padding
        {
            get
            {
                return _padding;
            }
            set
            {
                _padding = value;
                UpdateLayout();
            }
        }

        #region ---- METHODS (PROTECTED) ------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Raises the DockChanged event.
        /// </summary>
        /// <param name="e">The EventArgs.</param>
        protected override void OnDockChanged(EventArgs e)
        {
            base.OnDockChanged(e);

            UpdateLayout();
        }

        /// <summary>
        /// Raises the GotFocus event.
        /// </summary>
        /// <param name="e">The EventArgs.</param>
        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
            Controls[0].Focus();
        }

        /// <summary>
        /// Raises the MouseMove event.
        /// </summary>
        /// <param name="e">The MouseEventArgs.</param>
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            if (e == null)
            {
                throw new ArgumentNullException("e");
            }

            if (_isDraggingSplitter)
            {
                // Splitter dragging behavior, resize panel as needed
                if (Dock == DockStyle.Left)
                {
                    Width = e.Location.X + (_splitterSize / 2);
                }
                else if (Dock == DockStyle.Right)
                {
                    Width += -e.Location.X + (_splitterSize / 2);
                }
                else if (Dock == DockStyle.Top)
                {
                    Height = e.Location.Y + (_splitterSize / 2);
                }
                else if (Dock == DockStyle.Bottom)
                {
                    Height += -e.Location.Y + (_splitterSize / 2);
                }
            }
            else
            {
                // Default behavior, find hovered areas and refresh properties if needed
                Rectangle currentArea = Rectangle.Empty;
                if (e.Location.InRectangle(_dropButtonBounds))
                {
                    currentArea = _dropButtonBounds;
                }
                else if (e.Location.InRectangle(_closeButtonBounds))
                {
                    currentArea = _closeButtonBounds;
                }
                else if (e.Location.InRectangle(_splitterBounds))
                {
                    currentArea = _splitterBounds;
                    if (Dock == DockStyle.Left || Dock == DockStyle.Right)
                    {
                        Cursor = Cursors.SizeWE;
                    }
                    else if (Dock == DockStyle.Top || Dock == DockStyle.Bottom)
                    {
                        Cursor = Cursors.SizeNS;
                    }
                }
                else
                {
                    currentArea = Rectangle.Empty;
                    Cursor = Cursors.Default;
                }

                if (currentArea != _lastMouseArea)
                {
                    _lastMouseArea = currentArea;
                    Refresh();
                }
            }
        }

        /// <summary>
        /// Raises the MouseDown event.
        /// </summary>
        /// <param name="e">The MouseEventArgs.</param>
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            if (e == null)
            {
                throw new ArgumentNullException("e");
            }

            if (e.Button == MouseButtons.Left && _lastMouseArea == _splitterBounds)
            {
                Capture = true;
                _isDraggingSplitter = true;
            }
        }

        /// <summary>
        /// Raises the MouseUp event.
        /// </summary>
        /// <param name="e">The MouseEventArgs.</param>
        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (Capture)
            {
                Capture = false;
                _isDraggingSplitter = false;
            }

            base.OnMouseUp(e);
        }

        /// <summary>
        /// Raises the MouseClick event.
        /// </summary>
        /// <param name="e">The MouseEventArgs.</param>
        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);

            if (e == null)
            {
                throw new ArgumentNullException("e");
            }

            if (e.Button == MouseButtons.Left)
            {
                if (_lastMouseArea == _dropButtonBounds)
                {
                    OnDropButtonClicked();
                }
                else if (_lastMouseArea == _closeButtonBounds)
                {
                    OnCloseButtonClicked();
                }
            }
        }

        /// <summary>
        /// Raises the MouseLeave event.
        /// </summary>
        /// <param name="e">The EventArgs.</param>
        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);

            Cursor = Cursors.Default;

            if (_lastMouseArea != Rectangle.Empty)
            {
                _lastMouseArea = Rectangle.Empty;
                Refresh();
            }
        }

        /// <summary>
        /// Raises the Paint event.
        /// </summary>
        /// <param name="e">The PaintEventArgs.</param>
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (e == null)
            {
                throw new ArgumentNullException("e");
            }

            using (PaintEventArgs eventArgs = new PaintEventArgs(e.Graphics, _borderBounds))
            {
                OnDrawBorder(eventArgs);
            }
            using (PaintEventArgs eventArgs = new PaintEventArgs(e.Graphics, _titleBarBounds))
            {
                OnDrawTitleBar(eventArgs);
            }
            using (PaintEventArgs eventArgs = new PaintEventArgs(e.Graphics, _titleBarTextBounds))
            {
                OnDrawTitleBarText(eventArgs);
            }
            using (PaintEventArgs eventArgs = new PaintEventArgs(e.Graphics, _dropButtonBounds))
            {
                OnDrawDropButton(eventArgs);
            }
            using (PaintEventArgs eventArgs = new PaintEventArgs(e.Graphics, _closeButtonBounds))
            {
                OnDrawCloseButton(eventArgs);
            }
            using (PaintEventArgs eventArgs = new PaintEventArgs(e.Graphics, _splitterBounds))
            {
                OnDrawSplitter(eventArgs);
            }
        }

        /// <summary>
        /// Raises the SizeChanged event.
        /// </summary>
        /// <param name="e">The EventArgs.</param>
        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);

            UpdateLayout();
        }

        /// <summary>
        /// Raises the DrawBorder event.
        /// </summary>
        /// <param name="e">The PaintEventArgs.</param>
        protected virtual void OnDrawBorder(PaintEventArgs e)
        {
            if (e == null)
            {
                throw new ArgumentNullException("e");
            }
        }

        /// <summary>
        /// Raises the DrawTitleBar event.
        /// </summary>
        /// <param name="e">The PaintEventArgs.</param>
        protected virtual void OnDrawTitleBar(PaintEventArgs e)
        {
            if (e == null)
            {
                throw new ArgumentNullException("e");
            }

            using (SolidBrush brush = new SolidBrush(SystemColors.ActiveCaption))
            {
                e.Graphics.FillRectangle(brush, e.ClipRectangle);
            }
        }

        /// <summary>
        /// Raises the DrawTitleBarText event.
        /// </summary>
        /// <param name="e">The Paint EventArgs.</param>
        protected virtual void OnDrawTitleBarText(PaintEventArgs e)
        {
            if (e == null)
            {
                throw new ArgumentNullException("e");
            }

            TextRenderer.DrawText(e.Graphics, Text, Font, _titleBarTextBounds,
                SystemColors.ActiveCaptionText, TextFormatFlags.EndEllipsis);
        }

        /// <summary>
        /// Raises the DrawDropButton event.
        /// </summary>
        /// <param name="e">The PaintEventArgs.</param>
        protected virtual void OnDrawDropButton(PaintEventArgs e)
        {
            DrawButton(e, "u");
        }

        /// <summary>
        /// Raises the DrawCloseButton event.
        /// </summary>
        /// <param name="e">The PaintEventArgs.</param>
        protected virtual void OnDrawCloseButton(PaintEventArgs e)
        {
            DrawButton(e, "r");
        }

        /// <summary>
        /// Raises the DrawSplitter event.
        /// </summary>
        /// <param name="e">The PaintEventArgs.</param>
        protected virtual void OnDrawSplitter(PaintEventArgs e)
        {
        }

        /// <summary>
        /// Raises the DropButtonClicked event.
        /// </summary>
        protected virtual void OnDropButtonClicked()
        {
            if (DropButtonClicked != null)
            {
                DropButtonClicked(this, EventArgs.Empty);
            }
        }

        /// <summary>
        /// Raises the CloseButtonClicked event.
        /// </summary>
        protected virtual void OnCloseButtonClicked()
        {
            Hide();
            if (CloseButtonClicked != null)
            {
                CloseButtonClicked(this, EventArgs.Empty);
            }
        }

        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        private void UpdateLayout()
        {
            // Titlebar and Splitter
            if (Dock == DockStyle.Left)
            {
                base.Padding = new Padding(_padding.Left, _padding.Top + _titleBarHeight,
                    _splitterSize + _padding.Right, _padding.Bottom);
                _borderBounds = new Rectangle(0, 0, Width - _splitterSize, Height);
                _titleBarBounds = new Rectangle(_padding.Left, _padding.Bottom,
                    Width - _splitterSize - _padding.Horizontal, _titleBarHeight);
                _splitterBounds = new Rectangle(Width - _splitterSize, 0, _splitterSize, Height);
            }
            else if (Dock == DockStyle.Right)
            {
                base.Padding = new Padding(_splitterSize + _padding.Left, _padding.Top + _titleBarHeight,
                    _padding.Left, _padding.Bottom);
                _borderBounds = new Rectangle(0, 0, Width - _splitterSize, Height);
                _titleBarBounds = new Rectangle(_splitterSize + _padding.Left, _padding.Top,
                    Width - _splitterSize - _padding.Horizontal, _titleBarHeight);
                _splitterBounds = new Rectangle(0, 0, _splitterSize, Height);
            }
            else if (Dock == DockStyle.Top)
            {
                base.Padding = new Padding(_padding.Top, _padding.Top + _titleBarHeight,
                    _padding.Left, _splitterSize + _padding.Bottom);
                _borderBounds = new Rectangle(0, 0, Width, Height - _splitterSize);
                _titleBarBounds = new Rectangle(_padding.Left, _padding.Top,
                    Width - _padding.Horizontal, _titleBarHeight);
                _splitterBounds = new Rectangle(0, Height - _splitterSize, Width, _splitterSize);
            }
            else if (Dock == DockStyle.Bottom)
            {
                base.Padding = new Padding(_padding.Left, _splitterSize + _padding.Top + _titleBarHeight,
                    _padding.Right, _padding.Bottom);
                _borderBounds = new Rectangle(0, 0, Width, Height - _splitterSize);
                _titleBarBounds = new Rectangle(_padding.Left, _splitterSize + _padding.Top,
                    Width - _padding.Horizontal, _titleBarHeight);
                _splitterBounds = new Rectangle(0, 0, Width, _splitterSize);
            }
            else
            {
                base.Padding = new Padding(_padding.Left, _padding.Top + _titleBarHeight,
                    _padding.Right, _padding.Bottom);
                _borderBounds = new Rectangle(0, 0, Width, Height);
                _titleBarBounds = new Rectangle(_padding.Left, _padding.Top,
                    Width - _padding.Horizontal, _titleBarHeight);
                _splitterBounds = Rectangle.Empty;
            }

            // Titlebar Text
            _titleBarTextBounds = _titleBarBounds.Inflate(_titleBarPadding);
            int buttonCount = 0;
            if (_showDropButton)
            {
                buttonCount++;
            }
            if (_showCloseButton)
            {
                buttonCount++;
            }
            _titleBarTextBounds.Width -= _buttonSize * buttonCount;

            // Buttons
            Rectangle firstButtonArea = new Rectangle(_titleBarBounds.X + _titleBarBounds.Width
                + _titleBarPadding.Right - _buttonSize, _titleBarBounds.Y - _titleBarPadding.Top,
                _buttonSize, _buttonSize);
            if (_showCloseButton && _showDropButton)
            {
                _closeButtonBounds = firstButtonArea;
                _dropButtonBounds = _closeButtonBounds;
                _dropButtonBounds.X -= _buttonSize;
            }
            else if (_showCloseButton)
            {
                _closeButtonBounds = firstButtonArea;
                _dropButtonBounds = Rectangle.Empty;
            }
            else if (_showDropButton)
            {
                _closeButtonBounds = Rectangle.Empty;
                _dropButtonBounds = firstButtonArea;
            }
            else
            {
                _closeButtonBounds = Rectangle.Empty;
                _dropButtonBounds = Rectangle.Empty;
            }

            Refresh();
        }

        private void DrawButton(PaintEventArgs e, string marlettIcon)
        {
            Color backColor = SystemColors.ActiveCaption;
            Color foreColor = SystemColors.ActiveCaptionText;
            if (PointToClient(MousePosition).InRectangle(e.ClipRectangle))
            {
                backColor = SystemColors.InactiveCaption;
                foreColor = SystemColors.InactiveCaptionText;
            }

            using (SolidBrush brush = new SolidBrush(backColor))
            {
                e.Graphics.FillRectangle(brush, e.ClipRectangle);
            }
            TextRenderer.DrawText(e.Graphics, marlettIcon, _marlett, e.ClipRectangle, foreColor,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }
    }
}
