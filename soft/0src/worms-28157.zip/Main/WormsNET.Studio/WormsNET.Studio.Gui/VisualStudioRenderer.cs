﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace WormsNET.Studio.Gui
{
    /// <summary>
    /// Renderer for a Visual Studio 2013-like interface.
    /// </summary>
    public class VisualStudioRenderer : ToolStripProfessionalRenderer
    {
        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="VisualStudioRenderer" /> class.
        /// </summary>
        public VisualStudioRenderer()
            : base(new VisualStudioColorTable())
        {
            RoundedEdges = false;
        }

        #region ---- PROPERTIES ---------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Raises the RenderGrip event.
        /// </summary>
        /// <param name="e">The ToolStripGripRenderEventArgs.</param>
        protected override void OnRenderGrip(ToolStripGripRenderEventArgs e)
        {
            if (e == null)
            {
                throw new ArgumentNullException("e");
            }

            using (HatchBrush hb = new HatchBrush(HatchStyle.Percent20, ColorTable.GripDark,
                ColorTable.GripLight))
            {
                Rectangle bounds = e.GripBounds.Inflate(new Padding(2, -4, 2, -4));
                e.Graphics.FillRectangle(hb, bounds);
            }
        }
    }
}
