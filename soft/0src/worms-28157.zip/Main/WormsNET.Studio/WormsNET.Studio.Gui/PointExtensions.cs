﻿using System.Drawing;

namespace WormsNET.Studio.Gui
{
    /// <summary>
    /// Extension class for System.Drawing.Point.
    /// </summary>
    public static class PointExtensions
    {
        #region ---- METHODS (PUBLIC) ---------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Returns if this point is inside the specified rectangle.
        /// </summary>
        /// <param name="point">The extended Point.</param>
        /// <param name="rectangle">The rectangle in which the point is expected or not.</param>
        /// <returns>True, if the point is inside the specified rectangle.</returns>
        public static bool InRectangle(this Point point, Rectangle rectangle)
        {
            return point.X >= rectangle.X && point.X < rectangle.X + rectangle.Width
                && point.Y >= rectangle.Y && point.Y < rectangle.Y + rectangle.Height;
        }
    }
}
