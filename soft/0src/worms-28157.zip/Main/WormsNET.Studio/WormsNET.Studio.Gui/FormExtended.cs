﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using WormsNET.Studio.Gui.Native;

namespace WormsNET.Studio.Gui
{
    /// <summary>
    /// Extended Windows.Forms form.
    /// </summary>
    public class FormExtended : Form, IMessageFilter
    {
        #region ---- FIELDS -------------------------------------------------------------------------------
        #endregion

        private bool                  _aeroBorder;
        private bool                  _dropShadow;
        private bool                  _movable;
        private bool                  _isActive;
        private bool                  _isParentActive;
        private Padding               _glassPadding;
        private bool                  _glassMovable;

        private MdiClient             _mdiContainer;
        private bool                  _mdiContainerAutoScroll;
        private Color                 _mdiContainerBackColor;
        private BorderStyle           _mdiContainerBorderStyle;
        private MdiClientNativeWindow _mdiContainerWindow;

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="FormExtended" /> class.
        /// </summary>
        public FormExtended()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.ResizeRedraw,
                true);

            // Register the Windows message filter
            Application.AddMessageFilter(this);

            // Set default values
            Font = SystemFonts.MessageBoxFont;

            _aeroBorder = true;
            _dropShadow = false;
            _movable = true;

            _glassPadding = new Padding(0, 0, 0, 0);
            _glassMovable = true;

            _mdiContainerAutoScroll = true;
            _mdiContainerBackColor = SystemColors.AppWorkspace;
            _mdiContainerBorderStyle = BorderStyle.Fixed3D;
        }

        #region ---- EVENTS -------------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Raised after the forms background has been repainted.
        /// </summary>
        [Browsable(true)]
        [Category("Appearance")]
        [Description("Raised after the forms background has been repainted.")]
        public new event PaintEventHandler Paint;

        /// <summary>
        /// Raised after the MDI containers background has been repainted.
        /// </summary>
        [Browsable(true)]
        [Category("Appearance")]
        [Description("Raised after the MDI containers background has been repainted.")]
        public event PaintEventHandler PaintMdi
        {
            add { _mdiContainerWindow.Paint += value; }
            remove { _mdiContainerWindow.Paint -= value; }
        }

        /// <summary>
        /// Raised before a mouse click is handled by a control.
        /// </summary>
        [Browsable(true)]
        [Category("Action")]
        [Description("Raised before a mouse click is handled by a control.")]
        public event MouseEventHandler PreviewMouseClick;

        #region ---- PROPERTIES ---------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Gets or sets a value indicating whether the window uses an Aero Glass or a Basic
        /// border.
        /// </summary>
        [Category("Appearance")]
        [DefaultValue(true)]
        [Description("Determines wether the window uses an Aero or a Basic border.")]
        public bool AeroBorder
        {
            get
            {
                return _aeroBorder;
            }
            set
            {
                if (_aeroBorder != value)
                {
                    _aeroBorder = value;
                    RefreshAeroBorder();
                }
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the form drops a menu shadow.
        /// </summary>
        [Category("Appearance")]
        [DefaultValue(false)]
        [Description("Determines if the form drops a menu shadow.")]
        public bool DropShadow
        {
            get
            {
                return _dropShadow;
            }
            set
            {
                _dropShadow = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the form fades in when being shown.
        /// </summary>
        [Category("Appearance")]
        [DefaultValue(false)]
        [Description("Determines if the form fades in when being shown.")]
        public bool FadeIn
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the background color required for controls to appear correctly on Glass or Basic
        /// areas.
        /// </summary>
        [Browsable(false)]
        public Color GlassBackColor
        {
            get
            {
                if (DesignMode || !AeroBorder || MdiParent != null || !NativeMethods.AeroGlassEnabled)
                {
                    if ((DesignMode || _isActive) && (MdiParent == null || _isParentActive))
                    {
                        return SystemColors.GradientActiveCaption;
                    }
                    else
                    {
                        return SystemColors.GradientInactiveCaption;
                    }
                }
                return Color.Black;
            }
        }

        /// <summary>
        /// Gets or sets the area which will be used for expanded Aero Glass effects.
        /// </summary>
        [Category("Appearance")]
        [Description("Determines the area which will be used for expanded Aero Glass effects.")]
        public Padding GlassPadding
        {
            get
            {
                return _glassPadding;
            }
            set
            {
                _glassPadding = value;
                RefreshGlassPadding();
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the window can be moved by dragging Aero Glass
        /// areas.
        /// </summary>
        [Category("Behavior")]
        [DefaultValue(true)]
        [Description("Determines if the window can be moved by dragging glass areas.")]
        public bool GlassMovable
        {
            get { return _glassMovable; }
            set { _glassMovable = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the MDI container shows scrollbars if the
        /// content does not fit into its area.
        /// </summary>
        [Category("Window Style")]
        [DefaultValue(true)]
        [Description("A value indicating whether the MDI container shows scrollbars if the "
            + "content does not fit into its area.")]
        public bool MdiContainerAutoScroll
        {
            get
            {
                return _mdiContainerAutoScroll;
            }
            set
            {
                if (_mdiContainerAutoScroll != value)
                {
                    _mdiContainerAutoScroll = value;

                    // Update the MdiClient border to recalculate the nonclient area
                    if (MdiContainer != null)
                    {
                        RefreshMdiContainerBorder();
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the background color of the MDI container.
        /// </summary>
        [Category("Window Style")]
        [DefaultValue(typeof(Color), "AppWorkspace")]
        [Description("The background color of the MDI container.")]
        public Color MdiContainerBackColor
        {
            get
            {
                return _mdiContainerBackColor;
            }
            set
            {
                if (_mdiContainerBackColor != value)
                {
                    _mdiContainerBackColor = value;

                    // Update the MdiClient BackColor
                    if (MdiContainer != null)
                    {
                        MdiContainer.BackColor = _mdiContainerBackColor;
                        _mdiContainerWindow.ForceUpdate();
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the border style of the MDI container.
        /// </summary>
        [Category("Window Style")]
        [DefaultValue(BorderStyle.Fixed3D)]
        [Description("The border style of the MDI container.")]
        public BorderStyle MdiContainerBorderStyle
        {
            get
            {
                return _mdiContainerBorderStyle;
            }
            set
            {
                if (_mdiContainerBorderStyle != value)
                {
                    _mdiContainerBorderStyle = value;

                    // Update the MdiClient border
                    if (MdiContainer != null)
                    {
                        // Get current styles
                        int style = NativeMethods.GetWindowLong(MdiContainer, GetWindowLong.Style);
                        int exStyle = NativeMethods.GetWindowLong(MdiContainer, GetWindowLong.ExStyle);

                        // Modify existing style flags
                        switch (_mdiContainerBorderStyle)
                        {
                            case BorderStyle.Fixed3D:
                                style &= ~(int)WindowStyle.Border;
                                exStyle |= (int)WindowStyleExtended.ClientEdge;
                                break;
                            case BorderStyle.FixedSingle:
                                style |= (int)WindowStyle.Border;
                                exStyle &= ~(int)WindowStyleExtended.ClientEdge;
                                break;
                            case BorderStyle.None:
                                style &= ~(int)WindowStyle.Border;
                                exStyle &= ~(int)WindowStyleExtended.ClientEdge;
                                break;
                        }

                        // Set the new styles
                        NativeMethods.SetWindowLong(MdiContainer, GetWindowLong.Style, style);
                        NativeMethods.SetWindowLong(MdiContainer, GetWindowLong.ExStyle, exStyle);

                        RefreshMdiContainerBorder();
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the parent form of this window which will turn into an MDI window then.
        /// </summary>
        [Category("Window Style")]
        [DefaultValue(null)]
        [Description("The parent form of this window which will turn into an MDI window then.")]
        public new Form MdiParent
        {
            get
            {
                return base.MdiParent;
            }
            set
            {
                if (base.MdiParent != value)
                {
                    if (base.MdiParent != null)
                    {
                        MdiParent.Activated -= MdiParent_Activated;
                        MdiParent.Deactivate -= MdiParent_Deactivate;
                    }

                    base.MdiParent = value;

                    if (base.MdiParent != null)
                    {
                        MdiParent.Activated += MdiParent_Activated;
                        MdiParent.Deactivate += MdiParent_Deactivate;
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the form can be moved.
        /// </summary>
        [Category("Behavior")]
        [DefaultValue(true)]
        [Description("Determines if the form can be moved.")]
        public bool Movable
        {
            get { return _movable; }
            set { _movable = value; }
        }
        
        /// <summary>
        /// Gets or sets a value indicating whether the form can be moved everywhere, not only the
        /// titlebar.
        /// </summary>
        public bool MovableEverywhere
        {
            get; set;
        }

        /// <summary>
        /// Gets or sets the text displayed in the titlebar of the window.
        /// </summary>
        public override string Text
        {
            get
            {
                return base.Text;
            }
            set
            {
                base.Text = value;
                // If the control box is not visible, changes of the text force style refreshes
                if (!ControlBox)
                {
                    RefreshAeroBorder();
                    RefreshGlassPadding();
                }
            }
        }

        /// <summary>
        /// Gets or sets the MdiContainer used to display child windows.
        /// </summary>
        [Browsable(false)]
        internal MdiClient MdiContainer
        {
            get
            {
                return _mdiContainer;
            }
            set
            {
                if (_mdiContainer != value)
                {
                    // Release native window message procedure of existing container
                    if (_mdiContainer != null && _mdiContainerWindow != null)
                    {
                        _mdiContainerWindow.ReleaseHandle();
                    }

                    _mdiContainer = value;

                    // Refresh properties
                    if (_mdiContainer != null)
                    {
                        MdiContainerAutoScroll = MdiContainerAutoScroll;
                        MdiContainerBackColor = MdiContainerBackColor;
                        MdiContainerBorderStyle = MdiContainerBorderStyle;
                        _mdiContainerWindow = new MdiClientNativeWindow(this, _mdiContainer);
                    }
                }
            }
        }

        /// <summary>
        /// Gets the control creation parameters.
        /// </summary>
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                if (_dropShadow)
                {
                    cp.ClassStyle |= (int)ClassStyle.DropShadow;
                }
                return cp;
            }
        }

        #region ---- METHODS (PUBLIC) ---------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Filters out a message before it is dispatched.
        /// </summary>
        /// <param name="m">The message to be dispatched. You cannot modify this message.</param>
        /// <returns>true to filter the message and stop it from being dispatched; false to allow
        /// the message to continue to the next filter or control.</returns>
        public bool PreFilterMessage(ref Message m)
        {
            switch (m.Msg)
            {
                case (int)WindowsMessage.LButtonUp:
                    OnPreviewMouseClick(MouseButtons.Left);
                    return false;
                case (int)WindowsMessage.MButtonUp:
                    OnPreviewMouseClick(MouseButtons.Middle);
                    return false;
                case (int)WindowsMessage.RButtonUp:
                    OnPreviewMouseClick(MouseButtons.Right);
                    return false;
            }
            return false;
        }

        #region ---- METHODS (PROTECTED) ------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Windows message procedure.
        /// </summary>
        /// <param name="m">The message sent.</param>
        protected override void WndProc(ref Message m)
        {
            // Do not fetch messages in design mode
            if (!DesignMode)
            {
                switch (m.Msg)
                {
                    case (int)WindowsMessage.DwmCompositionChanged:
                        // Expand Aero Glass if it has been enabled again
                        RefreshGlassPadding();
                        break;

                    case (int)WindowsMessage.NcHitTest:
                        if (MovableEverywhere)
                        {
                            m.Result = (IntPtr)HitTestResult.Caption;
                            return;
                        }
                        // React on click in Aero Glass region as in a titlebar
                        if (_glassMovable && MouseInClientArea())
                        {
                            if (MouseInGlassArea())
                            {
                                m.Result = (IntPtr)HitTestResult.Caption;
                            }
                            else
                            {
                                m.Result = IntPtr.Zero;
                            }
                            return;
                        }
                        break;

                    case (int)WindowsMessage.NcRButtonDown:
                        // Show window system menu on right click in Aero Glass region
                        if (_glassMovable && MouseInClientArea())
                        {
                            int clickedItem = NativeMethods.ShowWindowMenu(this, Cursor.Position);
                            if (clickedItem != 0)
                            {
                                NativeMethods.PostWindowsMessage(Handle,
                                    (uint)WindowsMessage.SysCommand, clickedItem, 0);
                            }
                        }
                        break;

                    case (int)WindowsMessage.SysCommand:
                        // Handle windows moving
                        if (!_movable)
                        {
                            int command = m.WParam.ToInt32() & 0xFFF0;
                            if (command == (int)SysCommand.Move)
                            {
                                return;
                            }
                        }
                        break;
                }
            }

            base.WndProc(ref m);
        }

        /// <summary>
        /// Raises the Activated event.
        /// </summary>
        /// <param name="e">The EventArgs.</param>
        protected override void OnActivated(EventArgs e)
        {
            _isActive = true;
            Invalidate(false);

            base.OnActivated(e);
        }

        /// <summary>
        /// Raises the Deactivate event.
        /// </summary>
        /// <param name="e">The EventArgs.</param>
        protected override void OnDeactivate(EventArgs e)
        {
            _isActive = false;
            Invalidate(false);

            base.OnDeactivate(e);
        }

        /// <summary>
        /// Raises the Load event.
        /// </summary>
        /// <param name="e">The EventArgs.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (FadeIn)
            {
                NativeMethods.AnimateWindow(this, AnimateWindow.Activate | AnimateWindow.Blend,
                    250);
            }
        }

        /// <summary>
        /// Raises the Paint event.
        /// </summary>
        /// <param name="e">The PaintEventArgs.</param>
        protected override void OnPaint(PaintEventArgs e)
        {
            if (e == null)
            {
                throw new ArgumentNullException("e");
            }

            // Fill Glass areas with color
            e.Graphics.Clear(GlassBackColor);
            if (!_glassPadding.Any(-1))
            {
                using (SolidBrush br = new SolidBrush(BackColor))
                {
                    e.Graphics.FillRectangle(br, ClientRectangle.Deflate(_glassPadding));
                }
            }
            if (MdiContainer != null)
            {
                using (SolidBrush br = new SolidBrush(_mdiContainerBackColor))
                {
                    e.Graphics.FillRectangle(br,
                        new Rectangle(_mdiContainer.Location, _mdiContainer.Size));
                }
            }

            // Raise the custom Paint event
            if (Paint != null)
            {
                Paint(this, e);
            }
        }

        /// <summary>
        /// Raises the ControlAdded event.
        /// </summary>
        /// <param name="e">The ControlEventArgs.</param>
        protected override void OnControlAdded(ControlEventArgs e)
        {
            if (e == null)
            {
                throw new ArgumentNullException("e");
            }

            // Gets the MdiClient control when it was added
            if (MdiContainer == null)
            {
                MdiContainer = e.Control as MdiClient;
            }

            base.OnControlAdded(e);
        }

        /// <summary>
        /// Raises the ControlRemoved event.
        /// </summary>
        /// <param name="e">The ControlEventArgs.</param>
        protected override void OnControlRemoved(ControlEventArgs e)
        {
            if (e == null)
            {
                throw new ArgumentNullException("e");
            }

            // Unsets the MdiClient control when it was removed
            if (e.Control == MdiContainer)
            {
                MdiContainer = null;
            }

            base.OnControlRemoved(e);
        }

        /// <summary>
        /// Raises the PreviewMouseClick event.
        /// </summary>
        /// <param name="buttons">The mouse buttons which are pressed.</param>
        protected void OnPreviewMouseClick(MouseButtons buttons)
        {
            if (PreviewMouseClick != null)
            {
                PreviewMouseClick(this, new MouseEventArgs(buttons, 1, MousePosition.X,
                    MousePosition.Y, 0));
            }
        }

        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        private void RefreshAeroBorder()
        {
            if (!DesignMode)
            {
                // Turn the Aero Glass border on or off
                NativeMethods.SetAeroWindowProperty(this,
                    DwmWindowAttribute.NcRenderingPolicy, (uint)(_aeroBorder
                    ? DwmNcRenderingPolicy.Enabled : DwmNcRenderingPolicy.Disabled));

                // Expand glass if Aero has been enabled back or remove the expansion
                if (_aeroBorder)
                {
                    RefreshGlassPadding();
                }
                else
                {
                    NativeMethods.ExtendAeroGlass(this, Padding.Empty);
                }
            }
            // Refresh the window background
            Invalidate(false);
        }

        private void RefreshGlassPadding()
        {
            if (!DesignMode && AeroBorder && MdiParent == null)
            {
                NativeMethods.ExtendAeroGlass(this, _glassPadding);
                Invalidate(false);
            }
        }

        private bool MouseInClientArea()
        {
            Point p = PointToClient(Cursor.Position);
            return p.X > 0 && p.X < ClientRectangle.Width
                && p.Y > 0 && p.Y < ClientRectangle.Height;
        }

        private bool MouseInGlassArea()
        {
            if (_glassPadding.Any(-1))
            {
                return true;
            }
            else
            {
                Point p = PointToClient(Cursor.Position);
                return p.X < _glassPadding.Left
                    || p.X > ClientRectangle.Width - _glassPadding.Right
                    || p.Y < _glassPadding.Top
                    || p.Y > ClientRectangle.Height - _glassPadding.Bottom;
            }
        }

        private void RefreshMdiContainerBorder()
        {
            NativeMethods.SetWindowPosition(MdiContainer, null, 0, 0, 0, 0,
                SetWindowPos.NoActivate | SetWindowPos.NoMove | SetWindowPos.NoSize
                | SetWindowPos.NoZOrder | SetWindowPos.NoOwnerZOrder
                | SetWindowPos.FrameChanged);
        }

        #region ---- EVENTHANDLER -------------------------------------------------------------------------
        #endregion

        private void MdiParent_Activated(object sender, EventArgs e)
        {
            _isParentActive = true;
            Invalidate(false);
        }

        private void MdiParent_Deactivate(object sender, EventArgs e)
        {
            _isParentActive = false;
            Invalidate(false);
        }
    }
}
