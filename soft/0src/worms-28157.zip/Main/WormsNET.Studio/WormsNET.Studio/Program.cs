﻿using System;
using System.Windows.Forms;
using WormsNET.Studio.Gui;

namespace WormsNET.Studio
{
    /// <summary>
    /// Main class of the application containing the entry point.
    /// </summary>
    internal static class Program
    {
        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Set Visual Studio-like design
            ToolStripManager.Renderer = new VisualStudioRenderer();

            Application.Run(new FormSplashscreen());
            Application.Run(new FormMain());
        }
    }
}
