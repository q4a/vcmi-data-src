﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using WormsNET.Studio.Gui;

namespace WormsNET.Studio
{
    /// <summary>
    /// The main window of the application.
    /// </summary>
    public partial class FormMain : FormExtended
    {
        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="FormMain" /> class.
        /// </summary>
        public FormMain()
        {
            InitializeComponent();
        }

        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        private void NewCommand(Type fileFormat)
        {
            throw new NotImplementedException();
        }

        private void OpenCommand()
        {
            // Create OpenFileDialog
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Open File";
            openFileDialog.Multiselect = true;

            // Set up OpenFileDialog filter
            StringBuilder supportedExtensions = new StringBuilder();
            StringBuilder filter = new StringBuilder()
                .AppendFormat("All Supported Files|{0}|All Files|*.*|", supportedExtensions);
            openFileDialog.Filter = filter.ToString();

            // Show the OpenFileDialog
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Create the forms which correspond to the file formats of the selected files
                foreach (string fileName in openFileDialog.FileNames)
                {
                }
            }
        }

        private void SaveCommand()
        {
            throw new NotImplementedException();
        }

        private void ImportCommand()
        {
            throw new NotImplementedException();
        }

        private void ExportCommand()
        {
            throw new NotImplementedException();
        }

        private void WindowsCascadeCommand()
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void WindowsStackedCommand()
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void WindowsSideBySideCommand()
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void WindowsMinimizeAllCommand()
        {
            foreach (Form mdiChildren in MdiChildren)
            {
                mdiChildren.WindowState = FormWindowState.Minimized;
            }
        }

        private void AboutCommand()
        {
            MessageBox.Show(String.Format("{0} {1}{2}{3}{2}{4}", Application.ProductName,
                Application.ProductVersion, Environment.NewLine, Application.CompanyName,
                "Licensed under Ms-PL"), "About Worms.NET Studio", MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void CloseCommand()
        {
            throw new NotImplementedException();
        }

        private void ExitCommand()
        {
            Close();
        }

        private bool FileFitsMask(string fileName, string fileMask)
        {
            string pattern = '^' + Regex.Escape(fileMask.Replace(".", "__DOT__")
                .Replace("*", "__STAR__").Replace("?", "__QM__")).Replace("__DOT__", "[.]")
                .Replace("__STAR__", ".*").Replace("__QM__", ".") + '$';
            return new Regex(pattern, RegexOptions.IgnoreCase).IsMatch(fileName);
        }

        #region ---- EVENTHANDLER -------------------------------------------------------------------------
        #endregion

        private void _tsmiMainFileOpen_Click(object sender, EventArgs e)
        {
            OpenCommand();
        }

        private void _tsmiMainFileSave_Click(object sender, EventArgs e)
        {
            SaveCommand();
        }

        private void _tsmiMainFileImport_Click(object sender, EventArgs e)
        {
            ImportCommand();
        }

        private void _tsmiMainFileExport_Click(object sender, EventArgs e)
        {
            ExitCommand();
        }

        private void _tsmiMainFileExit_Click(object sender, EventArgs e)
        {
            ExitCommand();
        }

        private void _tsmiMainHelpAbout_Click(object sender, EventArgs e)
        {
            AboutCommand();
        }

        private void _tsbMainOpen_Click(object sender, EventArgs e)
        {
            OpenCommand();
        }

        private void _tsbMainSave_Click(object sender, EventArgs e)
        {
            SaveCommand();
        }

        private void _tsbMainClose_Click(object sender, EventArgs e)
        {
            CloseCommand();
        }

        private void _tsbFileImport_Click(object sender, EventArgs e)
        {
            ImportCommand();
        }

        private void _tsbFileExport_Click(object sender, EventArgs e)
        {
            ExportCommand();
        }

        private void _tsmiMainWindowCascade_Click(object sender, EventArgs e)
        {
            WindowsCascadeCommand();
        }

        private void _tsmiMainWindowStacked_Click(object sender, EventArgs e)
        {
            WindowsStackedCommand();
        }

        private void _tsmiMainWindowSideBySide_Click(object sender, EventArgs e)
        {
            WindowsSideBySideCommand();
        }

        private void _tsmiMainWindowMinimizeAll_Click(object sender, EventArgs e)
        {
            WindowsMinimizeAllCommand();
        }
    }
}
