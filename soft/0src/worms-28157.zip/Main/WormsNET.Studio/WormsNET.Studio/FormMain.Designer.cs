﻿namespace WormsNET.Studio
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this._msMain = new System.Windows.Forms.MenuStrip();
            this._tsmiMainFile = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainFileNew = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this._tssMainFile1 = new System.Windows.Forms.ToolStripSeparator();
            this._tsmiMainFileImport = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainFileExport = new System.Windows.Forms.ToolStripMenuItem();
            this._tssMainFile2 = new System.Windows.Forms.ToolStripSeparator();
            this._tsmiMainFileClose = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainFileCloseAll = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainWindow = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainWindowCascade = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainWindowStacked = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainWindowSideBySide = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainWindowMinimizeAll = new System.Windows.Forms.ToolStripMenuItem();
            this._tssMainWindow1 = new System.Windows.Forms.ToolStripSeparator();
            this._tsmiMainHelp = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiMainHelpWebsite = new System.Windows.Forms.ToolStripMenuItem();
            this._tssMainHelp1 = new System.Windows.Forms.ToolStripSeparator();
            this._tsmiMainHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this._tsbFile = new System.Windows.Forms.ToolStrip();
            this._tsddbMainNew = new System.Windows.Forms.ToolStripDropDownButton();
            this._tsbMainOpen = new System.Windows.Forms.ToolStripButton();
            this._tsbMainSave = new System.Windows.Forms.ToolStripButton();
            this._tsbMainClose = new System.Windows.Forms.ToolStripButton();
            this._tssFile1 = new System.Windows.Forms.ToolStripSeparator();
            this._tsbFileImport = new System.Windows.Forms.ToolStripButton();
            this._tsbFileExport = new System.Windows.Forms.ToolStripButton();
            this._dpMain = new WormsNET.Studio.Gui.VisualStudioDockPanel();
            this._tvSolution = new WormsNET.Studio.Gui.VisualStudioTreeView();
            this._msMain.SuspendLayout();
            this._tsbFile.SuspendLayout();
            this._dpMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // _msMain
            // 
            this._msMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._tsmiMainFile,
            this._tsmiMainWindow,
            this._tsmiMainHelp});
            this._msMain.Location = new System.Drawing.Point(0, 0);
            this._msMain.MdiWindowListItem = this._tsmiMainWindow;
            this._msMain.Name = "_msMain";
            this._msMain.Padding = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this._msMain.Size = new System.Drawing.Size(984, 24);
            this._msMain.TabIndex = 0;
            // 
            // _tsmiMainFile
            // 
            this._tsmiMainFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._tsmiMainFileNew,
            this._tsmiMainFileOpen,
            this._tsmiMainFileSave,
            this._tsmiMainFileSaveAs,
            this._tssMainFile1,
            this._tsmiMainFileImport,
            this._tsmiMainFileExport,
            this._tssMainFile2,
            this._tsmiMainFileClose,
            this._tsmiMainFileCloseAll,
            this._tsmiMainFileExit});
            this._tsmiMainFile.Name = "_tsmiMainFile";
            this._tsmiMainFile.Size = new System.Drawing.Size(40, 20);
            this._tsmiMainFile.Text = "&FILE";
            // 
            // _tsmiMainFileNew
            // 
            this._tsmiMainFileNew.Image = global::WormsNET.Studio.Properties.Resources.New;
            this._tsmiMainFileNew.Name = "_tsmiMainFileNew";
            this._tsmiMainFileNew.Size = new System.Drawing.Size(197, 22);
            this._tsmiMainFileNew.Text = "&New";
            // 
            // _tsmiMainFileOpen
            // 
            this._tsmiMainFileOpen.Image = global::WormsNET.Studio.Properties.Resources.Open;
            this._tsmiMainFileOpen.Name = "_tsmiMainFileOpen";
            this._tsmiMainFileOpen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this._tsmiMainFileOpen.Size = new System.Drawing.Size(197, 22);
            this._tsmiMainFileOpen.Text = "&Open...";
            this._tsmiMainFileOpen.Click += new System.EventHandler(this._tsmiMainFileOpen_Click);
            // 
            // _tsmiMainFileSave
            // 
            this._tsmiMainFileSave.Image = global::WormsNET.Studio.Properties.Resources.Save;
            this._tsmiMainFileSave.Name = "_tsmiMainFileSave";
            this._tsmiMainFileSave.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this._tsmiMainFileSave.Size = new System.Drawing.Size(197, 22);
            this._tsmiMainFileSave.Text = "&Save";
            this._tsmiMainFileSave.Click += new System.EventHandler(this._tsmiMainFileSave_Click);
            // 
            // _tsmiMainFileSaveAs
            // 
            this._tsmiMainFileSaveAs.Name = "_tsmiMainFileSaveAs";
            this._tsmiMainFileSaveAs.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt) 
            | System.Windows.Forms.Keys.S)));
            this._tsmiMainFileSaveAs.Size = new System.Drawing.Size(197, 22);
            this._tsmiMainFileSaveAs.Text = "Save &As...";
            // 
            // _tssMainFile1
            // 
            this._tssMainFile1.Name = "_tssMainFile1";
            this._tssMainFile1.Size = new System.Drawing.Size(194, 6);
            // 
            // _tsmiMainFileImport
            // 
            this._tsmiMainFileImport.Image = global::WormsNET.Studio.Properties.Resources.Import;
            this._tsmiMainFileImport.Name = "_tsmiMainFileImport";
            this._tsmiMainFileImport.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this._tsmiMainFileImport.Size = new System.Drawing.Size(197, 22);
            this._tsmiMainFileImport.Text = "&Import...";
            this._tsmiMainFileImport.Click += new System.EventHandler(this._tsmiMainFileImport_Click);
            // 
            // _tsmiMainFileExport
            // 
            this._tsmiMainFileExport.Image = global::WormsNET.Studio.Properties.Resources.Export;
            this._tsmiMainFileExport.Name = "_tsmiMainFileExport";
            this._tsmiMainFileExport.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this._tsmiMainFileExport.Size = new System.Drawing.Size(197, 22);
            this._tsmiMainFileExport.Text = "&Export...";
            this._tsmiMainFileExport.Click += new System.EventHandler(this._tsmiMainFileExport_Click);
            // 
            // _tssMainFile2
            // 
            this._tssMainFile2.Name = "_tssMainFile2";
            this._tssMainFile2.Size = new System.Drawing.Size(194, 6);
            // 
            // _tsmiMainFileClose
            // 
            this._tsmiMainFileClose.Image = global::WormsNET.Studio.Properties.Resources.Close;
            this._tsmiMainFileClose.Name = "_tsmiMainFileClose";
            this._tsmiMainFileClose.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.W)));
            this._tsmiMainFileClose.Size = new System.Drawing.Size(197, 22);
            this._tsmiMainFileClose.Text = "&Close";
            // 
            // _tsmiMainFileCloseAll
            // 
            this._tsmiMainFileCloseAll.Name = "_tsmiMainFileCloseAll";
            this._tsmiMainFileCloseAll.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.W)));
            this._tsmiMainFileCloseAll.Size = new System.Drawing.Size(197, 22);
            this._tsmiMainFileCloseAll.Text = "Close A&ll";
            // 
            // _tsmiMainFileExit
            // 
            this._tsmiMainFileExit.Image = global::WormsNET.Studio.Properties.Resources.Exit;
            this._tsmiMainFileExit.Name = "_tsmiMainFileExit";
            this._tsmiMainFileExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this._tsmiMainFileExit.Size = new System.Drawing.Size(197, 22);
            this._tsmiMainFileExit.Text = "E&xit";
            this._tsmiMainFileExit.Click += new System.EventHandler(this._tsmiMainFileExit_Click);
            // 
            // _tsmiMainWindow
            // 
            this._tsmiMainWindow.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._tsmiMainWindowCascade,
            this._tsmiMainWindowStacked,
            this._tsmiMainWindowSideBySide,
            this._tsmiMainWindowMinimizeAll,
            this._tssMainWindow1});
            this._tsmiMainWindow.Name = "_tsmiMainWindow";
            this._tsmiMainWindow.Size = new System.Drawing.Size(70, 20);
            this._tsmiMainWindow.Text = "&WINDOW";
            // 
            // _tsmiMainWindowCascade
            // 
            this._tsmiMainWindowCascade.Name = "_tsmiMainWindowCascade";
            this._tsmiMainWindowCascade.Size = new System.Drawing.Size(217, 22);
            this._tsmiMainWindowCascade.Text = "Cascade windows";
            this._tsmiMainWindowCascade.Click += new System.EventHandler(this._tsmiMainWindowCascade_Click);
            // 
            // _tsmiMainWindowStacked
            // 
            this._tsmiMainWindowStacked.Name = "_tsmiMainWindowStacked";
            this._tsmiMainWindowStacked.Size = new System.Drawing.Size(217, 22);
            this._tsmiMainWindowStacked.Text = "Show windows stacked";
            this._tsmiMainWindowStacked.Click += new System.EventHandler(this._tsmiMainWindowStacked_Click);
            // 
            // _tsmiMainWindowSideBySide
            // 
            this._tsmiMainWindowSideBySide.Name = "_tsmiMainWindowSideBySide";
            this._tsmiMainWindowSideBySide.Size = new System.Drawing.Size(217, 22);
            this._tsmiMainWindowSideBySide.Text = "Show windows side by side";
            this._tsmiMainWindowSideBySide.Click += new System.EventHandler(this._tsmiMainWindowSideBySide_Click);
            // 
            // _tsmiMainWindowMinimizeAll
            // 
            this._tsmiMainWindowMinimizeAll.Name = "_tsmiMainWindowMinimizeAll";
            this._tsmiMainWindowMinimizeAll.Size = new System.Drawing.Size(217, 22);
            this._tsmiMainWindowMinimizeAll.Text = "Minimize all windows";
            this._tsmiMainWindowMinimizeAll.Click += new System.EventHandler(this._tsmiMainWindowMinimizeAll_Click);
            // 
            // _tssMainWindow1
            // 
            this._tssMainWindow1.Name = "_tssMainWindow1";
            this._tssMainWindow1.Size = new System.Drawing.Size(214, 6);
            // 
            // _tsmiMainHelp
            // 
            this._tsmiMainHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._tsmiMainHelpWebsite,
            this._tssMainHelp1,
            this._tsmiMainHelpAbout});
            this._tsmiMainHelp.Name = "_tsmiMainHelp";
            this._tsmiMainHelp.Size = new System.Drawing.Size(47, 20);
            this._tsmiMainHelp.Text = "&HELP";
            // 
            // _tsmiMainHelpWebsite
            // 
            this._tsmiMainHelpWebsite.Name = "_tsmiMainHelpWebsite";
            this._tsmiMainHelpWebsite.Size = new System.Drawing.Size(210, 22);
            this._tsmiMainHelpWebsite.Text = "Worms.NET Website";
            // 
            // _tssMainHelp1
            // 
            this._tssMainHelp1.Name = "_tssMainHelp1";
            this._tssMainHelp1.Size = new System.Drawing.Size(207, 6);
            // 
            // _tsmiMainHelpAbout
            // 
            this._tsmiMainHelpAbout.Name = "_tsmiMainHelpAbout";
            this._tsmiMainHelpAbout.Size = new System.Drawing.Size(210, 22);
            this._tsmiMainHelpAbout.Text = "About Worms.NET Studio";
            this._tsmiMainHelpAbout.Click += new System.EventHandler(this._tsmiMainHelpAbout_Click);
            // 
            // _tsbFile
            // 
            this._tsbFile.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._tsddbMainNew,
            this._tsbMainOpen,
            this._tsbMainSave,
            this._tsbMainClose,
            this._tssFile1,
            this._tsbFileImport,
            this._tsbFileExport});
            this._tsbFile.Location = new System.Drawing.Point(0, 24);
            this._tsbFile.Margin = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this._tsbFile.Name = "_tsbFile";
            this._tsbFile.Size = new System.Drawing.Size(984, 25);
            this._tsbFile.TabIndex = 5;
            this._tsbFile.Text = "toolStrip1";
            // 
            // _tsddbMainNew
            // 
            this._tsddbMainNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this._tsddbMainNew.Image = global::WormsNET.Studio.Properties.Resources.New;
            this._tsddbMainNew.Margin = new System.Windows.Forms.Padding(0, 1, 0, 1);
            this._tsddbMainNew.Name = "_tsddbMainNew";
            this._tsddbMainNew.Size = new System.Drawing.Size(29, 23);
            this._tsddbMainNew.Text = "New";
            // 
            // _tsbMainOpen
            // 
            this._tsbMainOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this._tsbMainOpen.Image = global::WormsNET.Studio.Properties.Resources.Open;
            this._tsbMainOpen.Margin = new System.Windows.Forms.Padding(0, 1, 0, 1);
            this._tsbMainOpen.Name = "_tsbMainOpen";
            this._tsbMainOpen.Size = new System.Drawing.Size(23, 23);
            this._tsbMainOpen.Text = "Open...";
            this._tsbMainOpen.Click += new System.EventHandler(this._tsbMainOpen_Click);
            // 
            // _tsbMainSave
            // 
            this._tsbMainSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this._tsbMainSave.Image = global::WormsNET.Studio.Properties.Resources.Save;
            this._tsbMainSave.Margin = new System.Windows.Forms.Padding(0, 1, 0, 1);
            this._tsbMainSave.Name = "_tsbMainSave";
            this._tsbMainSave.Size = new System.Drawing.Size(23, 23);
            this._tsbMainSave.Text = "Save";
            this._tsbMainSave.Click += new System.EventHandler(this._tsbMainSave_Click);
            // 
            // _tsbMainClose
            // 
            this._tsbMainClose.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this._tsbMainClose.Image = global::WormsNET.Studio.Properties.Resources.Close;
            this._tsbMainClose.Margin = new System.Windows.Forms.Padding(0, 1, 0, 1);
            this._tsbMainClose.Name = "_tsbMainClose";
            this._tsbMainClose.Size = new System.Drawing.Size(23, 23);
            this._tsbMainClose.Text = "Close";
            this._tsbMainClose.Click += new System.EventHandler(this._tsbMainClose_Click);
            // 
            // _tssFile1
            // 
            this._tssFile1.Name = "_tssFile1";
            this._tssFile1.Size = new System.Drawing.Size(6, 25);
            // 
            // _tsbFileImport
            // 
            this._tsbFileImport.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this._tsbFileImport.Image = global::WormsNET.Studio.Properties.Resources.Import;
            this._tsbFileImport.Name = "_tsbFileImport";
            this._tsbFileImport.Size = new System.Drawing.Size(23, 22);
            this._tsbFileImport.Text = "Import...";
            this._tsbFileImport.Click += new System.EventHandler(this._tsbFileImport_Click);
            // 
            // _tsbFileExport
            // 
            this._tsbFileExport.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this._tsbFileExport.Image = global::WormsNET.Studio.Properties.Resources.Export;
            this._tsbFileExport.Name = "_tsbFileExport";
            this._tsbFileExport.Size = new System.Drawing.Size(23, 22);
            this._tsbFileExport.Text = "Export...";
            this._tsbFileExport.Click += new System.EventHandler(this._tsbFileExport_Click);
            // 
            // _dpMain
            // 
            this._dpMain.Controls.Add(this._tvSolution);
            this._dpMain.Dock = System.Windows.Forms.DockStyle.Left;
            this._dpMain.Location = new System.Drawing.Point(0, 49);
            this._dpMain.MinimumSize = new System.Drawing.Size(138, 0);
            this._dpMain.Name = "_dpMain";
            this._dpMain.Padding = new System.Windows.Forms.Padding(1);
            this._dpMain.Size = new System.Drawing.Size(200, 512);
            this._dpMain.TabIndex = 5;
            this._dpMain.Text = "Solution Explorer";
            // 
            // _tvSolution
            // 
            this._tvSolution.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this._tvSolution.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this._tvSolution.Dock = System.Windows.Forms.DockStyle.Fill;
            this._tvSolution.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this._tvSolution.FullRowSelect = true;
            this._tvSolution.ImageIndex = 0;
            this._tvSolution.LabelEdit = true;
            this._tvSolution.Location = new System.Drawing.Point(1, 22);
            this._tvSolution.Name = "_tvSolution";
            this._tvSolution.SelectedImageIndex = 0;
            this._tvSolution.ShowRootLines = false;
            this._tvSolution.Size = new System.Drawing.Size(192, 489);
            this._tvSolution.TabIndex = 0;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(242)))));
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this._dpMain);
            this.Controls.Add(this._tsbFile);
            this.Controls.Add(this._msMain);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this._msMain;
            this.MdiContainerBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(242)))));
            this.MdiContainerBorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Worms.NET Studio";
            this._msMain.ResumeLayout(false);
            this._msMain.PerformLayout();
            this._tsbFile.ResumeLayout(false);
            this._tsbFile.PerformLayout();
            this._dpMain.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip _msMain;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainFile;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainFileOpen;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator _tssMainFile2;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainFileExit;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainFileNew;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainFileSave;
        private System.Windows.Forms.ToolStripSeparator _tssMainFile1;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainFileImport;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainFileExport;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainFileClose;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainFileCloseAll;
        private System.Windows.Forms.ToolStrip _tsbFile;
        private System.Windows.Forms.ToolStripDropDownButton _tsddbMainNew;
        private System.Windows.Forms.ToolStripButton _tsbMainOpen;
        private System.Windows.Forms.ToolStripButton _tsbMainSave;
        private System.Windows.Forms.ToolStripButton _tsbMainClose;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainWindow;
        private System.Windows.Forms.ToolStripSeparator _tssMainWindow1;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainHelp;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainHelpAbout;
        private System.Windows.Forms.ToolStripSeparator _tssFile1;
        private System.Windows.Forms.ToolStripButton _tsbFileImport;
        private System.Windows.Forms.ToolStripButton _tsbFileExport;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainHelpWebsite;
        private System.Windows.Forms.ToolStripSeparator _tssMainHelp1;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainWindowCascade;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainWindowStacked;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainWindowSideBySide;
        private System.Windows.Forms.ToolStripMenuItem _tsmiMainWindowMinimizeAll;
        private Gui.VisualStudioDockPanel _dpMain;
        private Gui.VisualStudioTreeView _tvSolution;
    }
}

