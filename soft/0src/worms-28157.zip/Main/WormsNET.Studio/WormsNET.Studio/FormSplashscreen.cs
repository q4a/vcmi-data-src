﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using WormsNET.Studio.Gui;
using WormsNET.Studio.Properties;

namespace WormsNET.Studio
{
    /// <summary>
    /// Shows a splash screen to display the current state of starting the application.
    /// </summary>
    public partial class FormSplashscreen : FormExtended
    {
        #region ---- FIELDS -------------------------------------------------------------------------------
        #endregion

        private string _status;

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Initializes a new instance of FormSplashscreen.
        /// </summary>
        public FormSplashscreen()
        {
            InitializeComponent();
        }

        #region ---- PROPERTIES ---------------------------------------------------------------------------
        #endregion

        private string Status
        {
            get
            {
                return _status;
            }
            set
            {
                _status = value;
                Refresh();
            }
        }

        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        private void LoadPlugins()
        {
            Status = "Looking for extensions...";

            if (Directory.Exists("Extensions"))
            {
                foreach (string file in Directory.GetFiles("Extensions", "*.dll"))
                {
                    Assembly assembly = Assembly.LoadFrom(file);
                    Type[] types = assembly.GetTypes();
                    foreach (Type type in types)
                    {
                        //if (typeof(IPlugin).IsAssignableFrom(type))
                        //{
                        //    IPlugin plugin = (IPlugin)Activator.CreateInstance(type);
                        //}
                    }
                }
            }
            else
            {
                Directory.CreateDirectory("Extensions");
            }
        }

        private void ShowMainWindow()
        {
            Status = "Opening window...";
            Close();
        }

        #region ---- EVENTHANDLER -------------------------------------------------------------------------
        #endregion

        private void FormSplashscreen_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.HighQuality;
            e.Graphics.PixelOffsetMode = PixelOffsetMode.Half;

            // Background and border
            e.Graphics.Clear(Color.FromArgb(0, 0, 0));
            using (SolidBrush br = new SolidBrush(BackColor))
            {
                e.Graphics.FillRectangle(br, new Rectangle(1, 1, ClientSize.Width - 2,
                    ClientSize.Height - 2));
            }

            // Icon and title
            e.Graphics.DrawImage(Resources.IconSplash, new Rectangle(34, 30, 42, 42));
            using (Font font = new Font("Segoe UI", 28))
            {
                TextRenderer.DrawText(e.Graphics, "Worms.NET", font, new Point(79, 23), ForeColor);
            }

            // Arrow and subtitle
            using (SolidBrush br = new SolidBrush(Color.FromArgb(76, 76, 79)))
            {
                e.Graphics.FillPolygon(br, new Point[] { new Point(1, 96), new Point(20, 115),
                    new Point(1, 134) });
            }
            using (Font font = new Font("Segoe UI Light", 19))
            {
                TextRenderer.DrawText(e.Graphics, "Studio " + Application.ProductVersion, font,
                    new Point(26, 95), ForeColor);
            }

            // Status
            TextRenderer.DrawText(e.Graphics, Status, Font, new Point(29, 162),
                Color.FromArgb(153, 153, 153));

            // License
            TextRenderer.DrawText(e.Graphics, "This program is licensed under the Microsoft "
                + "Permissive License (Ms-PL)." + Environment.NewLine + Environment.NewLine
                + "Visit us on CodePlex: wormsnet.codeplex.com", Font, new Point(30, 509),
                Color.FromArgb(153, 153, 153));
        }

        private void FormSplashscreen_Shown(object sender, EventArgs e)
        {
            LoadPlugins();
            ShowMainWindow();
        }
    }
}
