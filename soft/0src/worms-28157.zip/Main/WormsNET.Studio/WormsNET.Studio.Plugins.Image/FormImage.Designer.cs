﻿namespace WormsNET.Studio.Image
{
    partial class FormImage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormImage));
            this._pbImage = new System.Windows.Forms.PictureBox();
            this._lvPalette = new System.Windows.Forms.ListView();
            this._lvhPalettePalette = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            ((System.ComponentModel.ISupportInitialize)(this._pbImage)).BeginInit();
            this.SuspendLayout();
            // 
            // _pbImage
            // 
            this._pbImage.BackColor = System.Drawing.Color.Black;
            this._pbImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this._pbImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this._pbImage.Location = new System.Drawing.Point(50, 0);
            this._pbImage.Name = "_pbImage";
            this._pbImage.Size = new System.Drawing.Size(574, 441);
            this._pbImage.TabIndex = 0;
            this._pbImage.TabStop = false;
            // 
            // _lvPalette
            // 
            this._lvPalette.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this._lvhPalettePalette});
            this._lvPalette.Dock = System.Windows.Forms.DockStyle.Left;
            this._lvPalette.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this._lvPalette.Location = new System.Drawing.Point(0, 0);
            this._lvPalette.MultiSelect = false;
            this._lvPalette.Name = "_lvPalette";
            this._lvPalette.Size = new System.Drawing.Size(50, 441);
            this._lvPalette.TabIndex = 1;
            this._lvPalette.UseCompatibleStateImageBehavior = false;
            this._lvPalette.View = System.Windows.Forms.View.Details;
            // 
            // _lvhPalettePalette
            // 
            this._lvhPalettePalette.Text = "Palette";
            this._lvhPalettePalette.Width = 28;
            // 
            // FormImage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this._pbImage);
            this.Controls.Add(this._lvPalette);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormImage";
            this.Text = "Image";
            ((System.ComponentModel.ISupportInitialize)(this._pbImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox _pbImage;
        private System.Windows.Forms.ListView _lvPalette;
        private System.Windows.Forms.ColumnHeader _lvhPalettePalette;
    }
}