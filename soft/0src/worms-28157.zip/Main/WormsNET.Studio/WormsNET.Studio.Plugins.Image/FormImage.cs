﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using WImage = WormsNET.Image.Image;

namespace WormsNET.Studio.Image
{
    /// <summary>
    /// Form visualizing the Image file format (IMG).
    /// </summary>
    public partial class FormImage : Form
    {
        #region ---- FIELDS -------------------------------------------------------------------------------
        #endregion

        WImage _image;

        #region ---- CONSTRUCTORS -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Default constructor.
        /// </summary>
        public FormImage()
        {
            InitializeComponent();
        }

        #region ---- METHODS (PUBLIC) ---------------------------------------------------------------------
        #endregion

        public void New()
        {
            throw new NotImplementedException();
        }

        public void Open(string fileName)
        {
            Text = "Image \"" + Path.GetFileNameWithoutExtension(fileName) + "\"";

            // Load the image and display its palette
            _image = new WImage(fileName);
            _pbImage.BackgroundImage = _image.Bitmap;
            foreach (Color color in _image.Bitmap.Palette.Entries)
            {
                ListViewItem item = _lvPalette.Items.Add("     ");
                item.BackColor = color;
                item.ForeColor = color.GetBrightness() > 0.5 ? Color.Black : Color.White;
            }
        }

        public void Save(string fileName)
        {
            throw new NotImplementedException();
        }

        public void Import(string fileName)
        {
            throw new NotImplementedException();
        }

        public void Export(string fileName)
        {
            throw new NotImplementedException();
        }

        #region ---- PROPERTIES ---------------------------------------------------------------------------
        #endregion

        public bool CanNew
        {
            get { throw new NotImplementedException(); }
        }

        public bool CanOpen
        {
            get { throw new NotImplementedException(); }
        }

        public bool CanSave
        {
            get { throw new NotImplementedException(); }
        }

        public bool CanImport
        {
            get { throw new NotImplementedException(); }
        }

        public bool CanExport
        {
            get { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Gets the forms instance.
        /// </summary>
        public Form Form
        {
            get { return this; }
        }
    }
}
