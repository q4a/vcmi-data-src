﻿namespace WormsNET.PalEditor
{
    partial class PaletteEditor
    {
        /// <summary> 
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Komponenten-Designer generierter Code

        /// <summary> 
        /// Erforderliche Methode für die Designerunterstützung. 
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this._cmColor = new System.Windows.Forms.ContextMenuStrip(this.components);
            this._tstbColor = new System.Windows.Forms.ToolStripTextBox();
            this._tsmiColorDialog = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this._tsmiBrighten = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiDarken = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiInverse = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiColorChannel = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiBgr = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiBRG = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiGBR = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiGRB = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiRBG = new System.Windows.Forms.ToolStripMenuItem();
            this._cd = new System.Windows.Forms.ColorDialog();
            this._tsmiDesaturate = new System.Windows.Forms.ToolStripMenuItem();
            this._cmColor.SuspendLayout();
            this.SuspendLayout();
            // 
            // _cmColor
            // 
            this._cmColor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._tstbColor,
            this._tsmiColorDialog,
            this._tsmiSeparator1,
            this._tsmiBrighten,
            this._tsmiDarken,
            this._tsmiInverse,
            this._tsmiDesaturate,
            this._tsmiColorChannel});
            this._cmColor.Name = "_cmColor";
            this._cmColor.Size = new System.Drawing.Size(161, 189);
            // 
            // _tstbColor
            // 
            this._tstbColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._tstbColor.Name = "_tstbColor";
            this._tstbColor.Size = new System.Drawing.Size(100, 23);
            this._tstbColor.TextChanged += new System.EventHandler(this._tstbColor_TextChanged);
            // 
            // _tsmiColorDialog
            // 
            this._tsmiColorDialog.Name = "_tsmiColorDialog";
            this._tsmiColorDialog.Size = new System.Drawing.Size(160, 22);
            this._tsmiColorDialog.Text = "Color Dialog...";
            this._tsmiColorDialog.Click += new System.EventHandler(this._tsmiColorDialog_Click);
            // 
            // _tsmiSeparator1
            // 
            this._tsmiSeparator1.Name = "_tsmiSeparator1";
            this._tsmiSeparator1.Size = new System.Drawing.Size(157, 6);
            // 
            // _tsmiBrighten
            // 
            this._tsmiBrighten.Name = "_tsmiBrighten";
            this._tsmiBrighten.Size = new System.Drawing.Size(160, 22);
            this._tsmiBrighten.Text = "Brighten";
            this._tsmiBrighten.Click += new System.EventHandler(this._tsmiBrighten_Click);
            // 
            // _tsmiDarken
            // 
            this._tsmiDarken.Name = "_tsmiDarken";
            this._tsmiDarken.Size = new System.Drawing.Size(160, 22);
            this._tsmiDarken.Text = "Darken";
            this._tsmiDarken.Click += new System.EventHandler(this._tsmiDarken_Click);
            // 
            // _tsmiInverse
            // 
            this._tsmiInverse.Name = "_tsmiInverse";
            this._tsmiInverse.Size = new System.Drawing.Size(160, 22);
            this._tsmiInverse.Text = "Inverse";
            this._tsmiInverse.Click += new System.EventHandler(this._tsmiInverse_Click);
            // 
            // _tsmiColorChannel
            // 
            this._tsmiColorChannel.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._tsmiBgr,
            this._tsmiBRG,
            this._tsmiGBR,
            this._tsmiGRB,
            this._tsmiRBG});
            this._tsmiColorChannel.Name = "_tsmiColorChannel";
            this._tsmiColorChannel.Size = new System.Drawing.Size(160, 22);
            this._tsmiColorChannel.Text = "Color Channel";
            // 
            // _tsmiBgr
            // 
            this._tsmiBgr.Name = "_tsmiBgr";
            this._tsmiBgr.Size = new System.Drawing.Size(96, 22);
            this._tsmiBgr.Text = "BGR";
            this._tsmiBgr.Click += new System.EventHandler(this._tsmiBgr_Click);
            // 
            // _tsmiBRG
            // 
            this._tsmiBRG.Name = "_tsmiBRG";
            this._tsmiBRG.Size = new System.Drawing.Size(96, 22);
            this._tsmiBRG.Text = "BRG";
            this._tsmiBRG.Click += new System.EventHandler(this._tsmiBRG_Click);
            // 
            // _tsmiGBR
            // 
            this._tsmiGBR.Name = "_tsmiGBR";
            this._tsmiGBR.Size = new System.Drawing.Size(96, 22);
            this._tsmiGBR.Text = "GBR";
            this._tsmiGBR.Click += new System.EventHandler(this._tsmiGBR_Click);
            // 
            // _tsmiGRB
            // 
            this._tsmiGRB.Name = "_tsmiGRB";
            this._tsmiGRB.Size = new System.Drawing.Size(96, 22);
            this._tsmiGRB.Text = "GRB";
            this._tsmiGRB.Click += new System.EventHandler(this._tsmiGRB_Click);
            // 
            // _tsmiRBG
            // 
            this._tsmiRBG.Name = "_tsmiRBG";
            this._tsmiRBG.Size = new System.Drawing.Size(96, 22);
            this._tsmiRBG.Text = "RBG";
            this._tsmiRBG.Click += new System.EventHandler(this._tsmiRBG_Click);
            // 
            // _cd
            // 
            this._cd.AnyColor = true;
            this._cd.FullOpen = true;
            this._cd.SolidColorOnly = true;
            // 
            // _tsmiDesaturate
            // 
            this._tsmiDesaturate.Name = "_tsmiDesaturate";
            this._tsmiDesaturate.Size = new System.Drawing.Size(160, 22);
            this._tsmiDesaturate.Text = "Desaturate";
            this._tsmiDesaturate.Click += new System.EventHandler(this._tsmiDesaturate_Click);
            // 
            // PaletteEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "PaletteEditor";
            this.Size = new System.Drawing.Size(175, 173);
            this._cmColor.ResumeLayout(false);
            this._cmColor.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip _cmColor;
        private System.Windows.Forms.ToolStripTextBox _tstbColor;
        private System.Windows.Forms.ToolStripMenuItem _tsmiColorDialog;
        private System.Windows.Forms.ToolStripSeparator _tsmiSeparator1;
        private System.Windows.Forms.ToolStripMenuItem _tsmiBrighten;
        private System.Windows.Forms.ToolStripMenuItem _tsmiDarken;
        private System.Windows.Forms.ToolStripMenuItem _tsmiInverse;
        private System.Windows.Forms.ToolStripMenuItem _tsmiColorChannel;
        private System.Windows.Forms.ToolStripMenuItem _tsmiBgr;
        private System.Windows.Forms.ToolStripMenuItem _tsmiBRG;
        private System.Windows.Forms.ToolStripMenuItem _tsmiGBR;
        private System.Windows.Forms.ToolStripMenuItem _tsmiGRB;
        private System.Windows.Forms.ToolStripMenuItem _tsmiRBG;
        private System.Windows.Forms.ColorDialog _cd;
        private System.Windows.Forms.ToolStripMenuItem _tsmiDesaturate;
    }
}
