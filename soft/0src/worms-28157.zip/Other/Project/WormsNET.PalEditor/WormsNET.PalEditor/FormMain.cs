﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace WormsNET.PalEditor
{
    #region #### FormMain ##################################################################################
    #endregion
    /// <summary>
    /// Hauptfenster der Anwendung.
    /// </summary>
    public partial class FormMain : Form
    {
        #region ---- KONSTANTEN ----------------------------------------------------------------------------
        #endregion

        const short _palVersion = 0x0300;

        #region ---- KONSTRUKTOREN -------------------------------------------------------------------------
        #endregion
        
        /// <summary>
        /// Standardkonstruktor.
        /// </summary>
        public FormMain()
        {
            InitializeComponent();
            RandomizeBackColor();
        }

        #region ---- METHODEN (PRIVATE) --------------------------------------------------------------------
        #endregion

        private void RandomizeBackColor()
        {
            Random rand = new Random();
            int colorPart = rand.Next(0, 4);
            int colorValue = rand.Next(50, 90);
            Color color = Color.Black;
            switch (colorPart)
            {
                case 0:
                    color = Color.FromArgb(colorValue, 0, 0);
                    break;
                case 1:
                    color = Color.FromArgb(0, colorValue, 0);
                    break;
                case 2:
                    color = Color.FromArgb(0, 0, colorValue);
                    break;
                case 3:
                    color = Color.FromArgb(colorValue, colorValue, 0);
                    break;
            }
            BackColor = color;
            Color lighterColor = color.Brighten(1.5f);
            Color lightColor = color.Brighten(1.8f);
            _btLoad.FlatAppearance.MouseOverBackColor = lightColor;
            _btSave.FlatAppearance.MouseOverBackColor = lightColor;
            _btLoad.FlatAppearance.MouseDownBackColor = lighterColor;
            _btSave.FlatAppearance.MouseDownBackColor = lighterColor;
        }

        private void ShowOpenFileDialog(bool closeAtAbort)
        {
            if (_ofd.ShowDialog() == DialogResult.OK)
            {
                LoadPal(_ofd.FileName);
            }
            else
            {
                Close();
            }
        }

        private void ShowSaveFileDialog()
        {
            if (_sfd.ShowDialog() == DialogResult.OK)
            {
                SavePal(_sfd.FileName);
            }
        }

        private void LoadPal(string filename)
        {
            FileStream stream = new FileStream(filename, FileMode.Open, FileAccess.Read,
                FileShare.Read);
            using (BinaryReader reader = new BinaryReader(stream))
            {
                // RIFF Header
                string riff = reader.ReadString(4); // RIFF
                int dataSize = reader.ReadInt32();
                string type = reader.ReadString(4); // PAL 

                // Data Chunk
                string chunkType = reader.ReadString(4); // data
                int chunkSize = reader.ReadInt32();
                short palVersion = reader.ReadInt16();
                short palEntries = reader.ReadInt16();

                _palEditor.Clear();
                for (int i = 0; i < palEntries; i++)
                {
                    byte red = reader.ReadByte();
                    byte green = reader.ReadByte();
                    byte blue = reader.ReadByte();
                    byte flags = reader.ReadByte();
                    _palEditor.Add(Color.FromArgb(red, green, blue));
                }
            }

            string shortFilename = Path.GetFileName(filename);
            _ofd.FileName = shortFilename;
            _sfd.InitialDirectory = _ofd.InitialDirectory;
            _sfd.FileName = shortFilename;
            Text = Application.ProductName + " - " + shortFilename;
        }

        private void SavePal(string filename)
        {
            // Länge berechnen
            int length = 4 + 4 + 4 + 4 + 2 + 2 + _palEditor.Count * 4;

            FileStream stream = new FileStream(filename, FileMode.Create, FileAccess.Write,
                FileShare.None);
            using (BinaryWriter bw = new BinaryWriter(stream))
            {
                // RIFF Header
                bw.Write("RIFF", BinaryStringFormat.NoPrefixOrTermination);
                bw.Write(length);
                bw.Write("PAL ", BinaryStringFormat.NoPrefixOrTermination);

                // Data Chunk
                bw.Write("data", BinaryStringFormat.NoPrefixOrTermination);
                bw.Write(_palEditor.Count * 4 + 4);
                bw.Write(_palVersion);
                bw.Write((short)_palEditor.Count);

                foreach (Color color in _palEditor.Colors)
                {
                    bw.Write((byte)color.R);
                    bw.Write((byte)color.G);
                    bw.Write((byte)color.B);
                    bw.Write((byte)0);
                }
            }

            string shortFilename = Path.GetFileName(filename);
            Text = Application.ProductName + " - " + shortFilename;
            _ofd.InitialDirectory = _sfd.InitialDirectory;
            _ofd.FileName = shortFilename;
            _sfd.FileName = shortFilename;
        }

        #region ---- EVENTHANDLER --------------------------------------------------------------------------
        #endregion

        private void FormMain_Shown(object sender, EventArgs e)
        {
            if (Environment.GetCommandLineArgs().Length == 2)
            {
                string filename = Environment.GetCommandLineArgs()[1];
                if (File.Exists(filename))
                {
                    LoadPal(filename);
                }
            }
            else
            {
                ShowOpenFileDialog(true);
            }
        }

        private void _paButtons_Click(object sender, EventArgs e)
        {
            RandomizeBackColor();
        }

        private void _btLoad_Click(object sender, EventArgs e)
        {
            ShowOpenFileDialog(false);
        }

        private void _btSave_Click(object sender, EventArgs e)
        {
            ShowSaveFileDialog();
        }

        private void _tkZoom_Scroll(object sender, EventArgs e)
        {
            _palEditor.TileSize = new Size(_tkZoom.Value, _tkZoom.Value);
        }

    } // #### FormMain #############################################################################
}
