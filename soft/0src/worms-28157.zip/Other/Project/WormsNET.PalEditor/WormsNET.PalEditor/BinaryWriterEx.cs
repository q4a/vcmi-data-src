﻿using System.IO;
using System.Text;

namespace WormsNET.PalEditor
{
    #region #### BinaryWriterEx ###########################################################################
    #endregion
    /// <summary>
    /// Extension class for System.IO.BinaryWriter.
    /// </summary>
    public static class BinaryWriterEx
    {
        #region ---- METHODS (PUBLIC) ---------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Writes a string in the specified binary format to this stream and advances the current
        /// position of the stream in accordance with the binary format and the specific characters
        /// being written to the stream.
        /// </summary>
        /// <param name="bw">The extended BinaryWriter.</param>
        /// <param name="value">The value to write.</param>
        /// <param name="format">The binary string format used for converting the string.</param>
        public static void Write(this BinaryWriter bw, string value, BinaryStringFormat format)
        {
            Write(bw, value, format, new ASCIIEncoding());
        }
        /// <summary>
        /// Writes a string in the specified binary format to this stream in the specified encoding
        /// and advances the current position of the stream in accordance with the encoding used,
        /// the binary format and the specific characters being written to the stream.
        /// </summary>
        /// <param name="bw">The extended BinaryWriter.</param>
        /// <param name="value">The value to write.</param>
        /// <param name="format">The binary string format used for converting the string.</param>
        /// <param name="encoding">The encoding used for converting the string.</param>
        public static void Write(this BinaryWriter bw, string value, BinaryStringFormat format,
            Encoding encoding)
        {
            if (format == BinaryStringFormat.VariableLengthPrefix)
            {
                bw.Write(value);
            }
            else if (format == BinaryStringFormat.WordLengthPrefix)
            {
                bw.Write(value.Length);
                bw.Write(encoding.GetBytes(value));
            }
            else if (format == BinaryStringFormat.ZeroTerminated)
            {
                bw.Write(encoding.GetBytes(value));
                bw.Write((byte)0);
            }
            else if (format == BinaryStringFormat.NoPrefixOrTermination)
            {
                bw.Write(encoding.GetBytes(value));
            }
        }

    } // #### BinaryWriterEx ######################################################################
}
