﻿using System.Drawing;

namespace WormsNET.PalEditor
{
    #region #### ColorEx ###################################################################################
    #endregion
    /// <summary>
    /// Statische Erweiterungsklasse für Color.
    /// </summary>
    public static class ColorEx
    {
        #region ---- METHODEN (PUBLIC) ---------------------------------------------------------------------
        #endregion
        
        /// <summary>
        /// Gibt eine erhellte oder verdunkelte Farbe zurück. Werte kleiner als 1.0 entsprechen
        /// dabei einer Verdunklung, Werte größer als 1.0 einer Erhellung der Ausgangsfarbe.
        /// </summary>
        /// <param name="color">Die erweiterte Farbe.</param>
        /// <param name="brightness">Der neue Helligkeitswert der Farbe.</param>
        public static Color Brighten(this Color color, float brightness)
        {
            return Color.FromArgb((byte)(color.R * brightness), (byte)(color.G * brightness),
                (byte)(color.B * brightness));
        }

    } // #### ColorEx ##############################################################################
}
