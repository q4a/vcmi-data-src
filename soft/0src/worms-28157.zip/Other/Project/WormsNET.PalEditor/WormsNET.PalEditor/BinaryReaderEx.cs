﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace WormsNET.PalEditor
{
    #region #### BinaryReaderEx ###########################################################################
    #endregion
    /// <summary>
    /// Extension class for System.IO.BinaryReader.
    /// </summary>
    public static class BinaryReaderEx
    {
        #region ---- METHODS (PUBLIC) ---------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Reads a string from the current stream. The string is available in the specified
        /// binary format.
        /// </summary>
        /// <param name="br">The extended BinaryReader.</param>
        /// <param name="format">The binary format, in which the string should be read.</param>
        /// <returns>The string being read.</returns>
        public static string ReadString(this BinaryReader br, BinaryStringFormat format)
        {
            return ReadString(br, format, new ASCIIEncoding());
        }
        /// <summary>
        /// Reads a string from the current stream. The string is available in the specified
        /// binary format and encoding.
        /// </summary>
        /// <param name="br">The extended BinaryReader.</param>
        /// <param name="format">The binary format, in which the string should be read.</param>
        /// <param name="encoding">The encoding used for converting the string. This is not
        ///     relevant for the VariableLengthPrefix binary format.</param>
        /// <returns>The string being read.</returns>
        public static string ReadString(this BinaryReader br, BinaryStringFormat format,
            Encoding encoding)
        {
            if (format == BinaryStringFormat.VariableLengthPrefix)
            {
                return br.ReadString();
            }
            else if (format == BinaryStringFormat.WordLengthPrefix)
            {
                int length = br.ReadInt32();
                return encoding.GetString(br.ReadBytes(length));
            }
            else if (format == BinaryStringFormat.ZeroTerminated)
            {
                // Read single bytes
                List<byte> bytes = new List<byte>();
                byte readByte = br.ReadByte();
                while (readByte != 0)
                {
                    bytes.Add(readByte);
                    readByte = br.ReadByte();
                }

                // Convert to string
                return encoding.GetString(bytes.ToArray());
            }
            else if (format == BinaryStringFormat.NoPrefixOrTermination)
            {
                throw new ArgumentException("NoPrefixOrTermination cannot be used for read "
                    + "operations. Specify the length of the string instead to read strings with "
                    + "no prefix or terminator.");
            }
            else
            {
                throw new ArgumentOutOfRangeException("The specified binary string format is "
                    + "invalid.");
            }
        }

        /// <summary>
        /// Reads a string from the current stream. The string has neither a prefix or postfix, the
        /// length has to be specified manually.
        /// </summary>
        /// <param name="br">The extended BinaryReader.</param>
        /// <param name="length">The length of the string.</param>
        /// <returns>The string being read.</returns>
        public static string ReadString(this BinaryReader br, int length)
        {
            return ReadString(br, length, new ASCIIEncoding());
        }
        /// <summary>
        /// Reads a string from the current stream. The string has neither a prefix or postfix, the
        /// length has to be specified manually. The string is available in the specified encoding.
        /// </summary>
        /// <param name="br">The extended BinaryReader.</param>
        /// <param name="length">The length of the string.</param>
        /// <param name="encoding">The encoding to use for reading the string.</param>
        /// <returns>The string being read.</returns>
        public static string ReadString(this BinaryReader br, int length, Encoding encoding)
        {
            return encoding.GetString(br.ReadBytes(length));
        }

    } // #### BinaryReaderEx ######################################################################
}
