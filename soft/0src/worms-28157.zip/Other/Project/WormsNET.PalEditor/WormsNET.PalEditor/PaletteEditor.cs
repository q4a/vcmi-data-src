﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Windows.Forms;

namespace WormsNET.PalEditor
{
    #region #### PaletteEditor #############################################################################
    #endregion
    /// <summary>
    /// Zeigt eine Farbpalette an und erlaubt deren Bearbeitung.
    /// </summary>
    [ToolboxBitmap(typeof(Panel))]
    public partial class PaletteEditor : UserControl
    {
        #region ---- MEMBERVARIABLEN -----------------------------------------------------------------------
        #endregion

        List<Color> _colors;
        int? _hoveredIndex;
        int? _lastSelectedIndex;
        List<int> _selectedIndizes;

        Size _tileCount;
        Size _tileSize;

        Pen _selectPen1;
        Pen _selectPen2;
        Pen _hoverPen1;
        Pen _hoverPen2;

        #region ---- KONSTRUKTOREN -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Standardkonstruktor.
        /// </summary>
        public PaletteEditor()
        {
            // Doublebuffering und Resizeredraw einschalten
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer
                | ControlStyles.ResizeRedraw, true);

            // Membervariablen initialisieren
            _colors = new List<Color>();
            _selectedIndizes = new List<int>();
            _tileSize = new Size(32, 32);

            // Grafikobjekte erstellen
            _selectPen1 = new Pen(Color.Black);
            _selectPen2 = new Pen(Color.White);
            _hoverPen1 = new Pen(Color.FromArgb(128, Color.Black));
            _hoverPen2 = new Pen(Color.FromArgb(128, Color.White));

            InitializeComponent();
        }

        #region ---- EIGENSCHAFTEN -------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Gibt die Größe eines Farbeintrags an oder legt sie fest.
        /// </summary>
        public Size TileSize
        {
            get { return _tileSize; }
            set
            {
                _tileSize = value;
                CalculateSizes();
                Invalidate();
            }
        }

        #region ---- METHODEN (PUBLIC) ---------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Gibt die Liste der angezeigten Farben an.
        /// </summary>
        public ReadOnlyCollection<Color> Colors
        {
            get { return _colors.AsReadOnly(); }
        }

        /// <summary>
        /// Fügt die übergebene Farbe hinzu.
        /// </summary>
        /// <param name="color">Die hinzuzufügende Farbe.</param>
        public void Add(Color color)
        {
            _colors.Add(color);
            Invalidate();
        }

        /// <summary>
        /// Löscht alle Farben.
        /// </summary>
        public void Clear()
        {
            _colors = new List<Color>();
            Invalidate();
        }

        /// <summary>
        /// Gibt die Anzahl der angezeigten Farben an.
        /// </summary>
        public int Count
        {
            get { return _colors.Count; }
        }

        #region ---- METHODEN (PROTECTED) ------------------------------------------------------------------
        #endregion

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.A)
            {
                int selectedCount = _selectedIndizes.Count;
                _selectedIndizes.Clear();
                if (selectedCount < _colors.Count / 2)
                {
                    // Minderheit der Indizes waren ausgewählt, alle auswählen
                    for (int i = 0; i < _colors.Count; i++)
                    {
                        _selectedIndizes.Add(i);
                    }
                }
            }
            Invalidate();

            base.OnKeyDown(e);
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (_selectedIndizes.Contains(_hoveredIndex.Value))
                {
                    if (_selectedIndizes.Count > 1)
                    {
                        // Mehrere Farben ausgewählt
                        ShowContextMenuMultiColor(e);
                    }
                    else
                    {
                        // Eine Farbe ausgewählt
                        ShowContextMenuSingleColor();
                    }
                }
                else
                {
                    // Nicht ausgewähltes Farbfeld angeklickt, die Farbe auswählen
                    _selectedIndizes.Clear();
                    _selectedIndizes.Add(_hoveredIndex.Value);
                    Invalidate();
                    ShowContextMenuSingleColor();
                }
            }

            base.OnMouseClick(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            // Maus muss sich innerhalb des Controls befinden
            if (!ClientRectangle.IntersectsWith(new Rectangle(e.Location, new Size(1, 1))))
            {
                return;
            }

            _hoveredIndex = e.Location.Y / _tileSize.Height * _tileCount.Width + e.Location.X
                / _tileSize.Width;

            if (e.Button == MouseButtons.Left)
            {
                if (Control.ModifierKeys == Keys.Control)
                {
                    if (_lastSelectedIndex == null
                        || _lastSelectedIndex.Value != _hoveredIndex.Value)
                    {
                        if (_selectedIndizes.Contains(_hoveredIndex.Value))
                        {
                            _selectedIndizes.Remove(_hoveredIndex.Value);
                            _lastSelectedIndex = _hoveredIndex;
                        }
                        else
                        {
                            _selectedIndizes.Add(_hoveredIndex.Value);
                            _lastSelectedIndex = _hoveredIndex;
                        }
                    }
                }
                else if (Control.ModifierKeys == Keys.None)
                {
                    _selectedIndizes.Clear();
                    _selectedIndizes.Add(_hoveredIndex.Value);
                }
            }
            Invalidate();

            base.OnMouseMove(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (!_hoveredIndex.HasValue || e.Button != MouseButtons.Left)
            {
                return;
            }

            if (Control.ModifierKeys == Keys.Control)
            {
                if (_selectedIndizes.Contains(_hoveredIndex.Value))
                {
                    _selectedIndizes.Remove(_hoveredIndex.Value);
                    _lastSelectedIndex = _hoveredIndex;
                }
                else
                {
                    _selectedIndizes.Add(_hoveredIndex.Value);
                    _lastSelectedIndex = _hoveredIndex;
                }
            }
            else if (Control.ModifierKeys == Keys.None)
            {
                _selectedIndizes.Clear();
                _selectedIndizes.Add(_hoveredIndex.Value);
            }
            Invalidate();

            base.OnMouseDown(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            _lastSelectedIndex = null;

            base.OnMouseUp(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hoveredIndex = null;
            Invalidate();

            base.OnMouseLeave(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);

            for (int i = 0; i < _colors.Count; i++)
            {
                // Position des Tiles berechnen
                Point tileLocation = GetColorLocation(i);

                // Hintergrund zeichnen
                using (SolidBrush br = new SolidBrush(_colors[i]))
                {
                    e.Graphics.FillRectangle(br, new Rectangle(tileLocation, _tileSize));
                }

                // Rahmenbereiche berechnen
                Rectangle borderRect1 = new Rectangle(tileLocation.X, tileLocation.Y,
                    _tileSize.Width - 1, _tileSize.Height - 1);
                Rectangle borderRect2 = borderRect1;
                borderRect2.Inflate(-1, -1);
                // Stati darstellen
                if (_selectedIndizes.Contains(i))
                {
                    // Ausgewähltes Item
                    e.Graphics.DrawRectangle(_selectPen1, borderRect1);
                    e.Graphics.DrawRectangle(_selectPen2, borderRect2);
                }
                if (_hoveredIndex.HasValue && _hoveredIndex == i)
                {
                    // Gehovertes Item
                    e.Graphics.DrawRectangle(_hoverPen1, borderRect1);
                    e.Graphics.DrawRectangle(_hoverPen2, borderRect2);
                }
            }
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            CalculateSizes();
            base.OnSizeChanged(e);
        }

        #region ---- METHODEN (PRIVATE) --------------------------------------------------------------------
        #endregion

        private void CalculateSizes()
        {
            _tileCount = new Size(ClientSize.Width / _tileSize.Width,
                ClientSize.Height / _tileSize.Height);
        }

        private Point GetColorLocation(int index)
        {
            return new Point((index % _tileCount.Width) * _tileSize.Width,
                (index / _tileCount.Width) * _tileSize.Height);
        }
        
        private void ShowContextMenuSingleColor()
        {

            _tstbColor.Text = ColorTranslator.ToHtml(_colors[_hoveredIndex.Value]);
            _cd.Color = _colors[_hoveredIndex.Value];
            Point screenPosition = PointToScreen(GetColorLocation(_hoveredIndex.Value));
            screenPosition.Y += _tileSize.Height;
            _cmColor.Show(screenPosition);
        }

        private void ShowContextMenuMultiColor(MouseEventArgs e)
        {
            _tstbColor.Text = "(multiple)";
            _cd.Color = Color.Black;
            _cmColor.Show(PointToScreen(e.Location));
        }

        private int ClampColor(float value)
        {
            return Math.Max(0, Math.Min((int)value, 255));
        }

        #region ---- EVENTHANDLER --------------------------------------------------------------------------
        #endregion

        private void _tstbColor_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Color color = ColorTranslator.FromHtml(_tstbColor.Text);
                if (color.A == 255)
                {
                    foreach (int selectIndex in _selectedIndizes)
                    {
                        _colors[selectIndex] = color;
                    }
                    Invalidate();
                }
                _cd.Color = color;
            }
            catch
            {
            }
        }

        private void _tsmiColorDialog_Click(object sender, EventArgs e)
        {
            if (_cd.ShowDialog() == DialogResult.OK)
            {
                _tstbColor.Text = ColorTranslator.ToHtml(_cd.Color);
                foreach (int selectIndex in _selectedIndizes)
                {
                    _colors[selectIndex] = _cd.Color;
                }
            }
        }

        private void _tsmiBrighten_Click(object sender, EventArgs e)
        {
            foreach (int selectIndex in _selectedIndizes)
            {
                Color color = _colors[selectIndex];
                _colors[selectIndex] = Color.FromArgb(ClampColor(color.R * 1.1f),
                    ClampColor(color.G * 1.1f), ClampColor(color.B * 1.1f));
            }
        }

        private void _tsmiDarken_Click(object sender, EventArgs e)
        {
            foreach (int selectIndex in _selectedIndizes)
            {
                Color color = _colors[selectIndex];
                _colors[selectIndex] = Color.FromArgb(ClampColor((float)color.R * 0.9f),
                    ClampColor((float)color.G * 0.9f), ClampColor((float)color.B * 0.9f));
            }
        }

        private void _tsmiInverse_Click(object sender, EventArgs e)
        {
            foreach (int selectIndex in _selectedIndizes)
            {
                Color color = _colors[selectIndex];
                _colors[selectIndex] = Color.FromArgb(255 - color.R, 255 - color.G, 255 - color.B);
            }
        }

        private void _tsmiDesaturate_Click(object sender, EventArgs e)
        {
            foreach (int selectIndex in _selectedIndizes)
            {
                int brightness = (int)(_colors[selectIndex].GetBrightness() * 255.0f);
                _colors[selectIndex] = Color.FromArgb(brightness, brightness, brightness);
            }
        }

        private void _tsmiBgr_Click(object sender, EventArgs e)
        {
            foreach (int selectIndex in _selectedIndizes)
            {
                Color color = _colors[selectIndex];
                _colors[selectIndex] = Color.FromArgb(color.B, color.G, color.R);
            }
        }

        private void _tsmiBRG_Click(object sender, EventArgs e)
        {
            foreach (int selectIndex in _selectedIndizes)
            {
                Color color = _colors[selectIndex];
                _colors[selectIndex] = Color.FromArgb(color.B, color.R, color.G);
            }
        }

        private void _tsmiGBR_Click(object sender, EventArgs e)
        {
            foreach (int selectIndex in _selectedIndizes)
            {
                Color color = _colors[selectIndex];
                _colors[selectIndex] = Color.FromArgb(color.G, color.B, color.R);
            }
        }

        private void _tsmiGRB_Click(object sender, EventArgs e)
        {
            foreach (int selectIndex in _selectedIndizes)
            {
                Color color = _colors[selectIndex];
                _colors[selectIndex] = Color.FromArgb(color.G, color.R, color.B);
            }
        }

        private void _tsmiRBG_Click(object sender, EventArgs e)
        {
            foreach (int selectIndex in _selectedIndizes)
            {
                Color color = _colors[selectIndex];
                _colors[selectIndex] = Color.FromArgb(color.R, color.B, color.G);
            }
        }

    } // #### PaletteEditor ########################################################################
}
