﻿namespace WormsNET.PalEditor
{
    partial class FormMain
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this._btLoad = new System.Windows.Forms.Button();
            this._btSave = new System.Windows.Forms.Button();
            this._ofd = new System.Windows.Forms.OpenFileDialog();
            this._sfd = new System.Windows.Forms.SaveFileDialog();
            this._tkZoom = new System.Windows.Forms.TrackBar();
            this._lbZoom = new System.Windows.Forms.Label();
            this._paButtons = new System.Windows.Forms.Panel();
            this._palEditor = new WormsNET.PalEditor.PaletteEditor();
            ((System.ComponentModel.ISupportInitialize)(this._tkZoom)).BeginInit();
            this._paButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // _btLoad
            // 
            this._btLoad.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this._btLoad.FlatAppearance.BorderSize = 2;
            this._btLoad.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this._btLoad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this._btLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btLoad.Location = new System.Drawing.Point(12, 12);
            this._btLoad.Name = "_btLoad";
            this._btLoad.Size = new System.Drawing.Size(75, 26);
            this._btLoad.TabIndex = 0;
            this._btLoad.Text = "Load";
            this._btLoad.UseVisualStyleBackColor = true;
            this._btLoad.Click += new System.EventHandler(this._btLoad_Click);
            // 
            // _btSave
            // 
            this._btSave.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this._btSave.FlatAppearance.BorderSize = 2;
            this._btSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this._btSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this._btSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btSave.Location = new System.Drawing.Point(93, 12);
            this._btSave.Name = "_btSave";
            this._btSave.Size = new System.Drawing.Size(75, 26);
            this._btSave.TabIndex = 1;
            this._btSave.Text = "Save";
            this._btSave.UseVisualStyleBackColor = true;
            this._btSave.Click += new System.EventHandler(this._btSave_Click);
            // 
            // _ofd
            // 
            this._ofd.Filter = "Palette Files|*.pal|All Files|*.*";
            this._ofd.Title = "Open Worms Palette File";
            // 
            // _sfd
            // 
            this._sfd.Filter = "Palette Files|*.pal|All Files|*.*";
            this._sfd.Title = "Save Worms Palette File";
            // 
            // _tkZoom
            // 
            this._tkZoom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._tkZoom.AutoSize = false;
            this._tkZoom.LargeChange = 10;
            this._tkZoom.Location = new System.Drawing.Point(400, 15);
            this._tkZoom.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
            this._tkZoom.Maximum = 50;
            this._tkZoom.Minimum = 10;
            this._tkZoom.Name = "_tkZoom";
            this._tkZoom.Size = new System.Drawing.Size(100, 23);
            this._tkZoom.TabIndex = 3;
            this._tkZoom.TickStyle = System.Windows.Forms.TickStyle.None;
            this._tkZoom.Value = 30;
            this._tkZoom.Scroll += new System.EventHandler(this._tkZoom_Scroll);
            // 
            // _lbZoom
            // 
            this._lbZoom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._lbZoom.AutoSize = true;
            this._lbZoom.Location = new System.Drawing.Point(355, 18);
            this._lbZoom.Name = "_lbZoom";
            this._lbZoom.Size = new System.Drawing.Size(39, 15);
            this._lbZoom.TabIndex = 2;
            this._lbZoom.Text = "Zoom";
            // 
            // _paButtons
            // 
            this._paButtons.Controls.Add(this._btLoad);
            this._paButtons.Controls.Add(this._btSave);
            this._paButtons.Controls.Add(this._lbZoom);
            this._paButtons.Controls.Add(this._tkZoom);
            this._paButtons.Dock = System.Windows.Forms.DockStyle.Top;
            this._paButtons.Location = new System.Drawing.Point(0, 0);
            this._paButtons.Name = "_paButtons";
            this._paButtons.Size = new System.Drawing.Size(512, 49);
            this._paButtons.TabIndex = 0;
            this._paButtons.Click += new System.EventHandler(this._paButtons_Click);
            // 
            // _palEditor
            // 
            this._palEditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this._palEditor.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._palEditor.Location = new System.Drawing.Point(0, 49);
            this._palEditor.Name = "_palEditor";
            this._palEditor.Size = new System.Drawing.Size(512, 512);
            this._palEditor.TabIndex = 1;
            this._palEditor.TileSize = new System.Drawing.Size(32, 32);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Navy;
            this.ClientSize = new System.Drawing.Size(512, 561);
            this.Controls.Add(this._palEditor);
            this.Controls.Add(this._paButtons);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(464, 151);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Worms.NET PAL Editor";
            this.Shown += new System.EventHandler(this.FormMain_Shown);
            ((System.ComponentModel.ISupportInitialize)(this._tkZoom)).EndInit();
            this._paButtons.ResumeLayout(false);
            this._paButtons.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button _btLoad;
        private System.Windows.Forms.Button _btSave;
        private System.Windows.Forms.OpenFileDialog _ofd;
        private System.Windows.Forms.SaveFileDialog _sfd;
        private System.Windows.Forms.TrackBar _tkZoom;
        private System.Windows.Forms.Label _lbZoom;
        private System.Windows.Forms.Panel _paButtons;
        private PaletteEditor _palEditor;
    }
}

