﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using Microsoft.Win32;

namespace WormsNET.ImgViewer
{
    #region #### FormMain ##################################################################################
    #endregion
    /// <summary>
    /// Hauptform der Anwendung.
    /// </summary>
    public partial class FormMain : Form
    {
        #region ---- MEMBERVARIABLEN -----------------------------------------------------------------------
        #endregion

        byte[,] _palette = new byte[1, 3];

        #region ---- KONSTRUKTOR ---------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Standardkonstruktor.
        /// </summary>
        public FormMain()
        {
            InitializeComponent();

            string[] args = Environment.GetCommandLineArgs();
            if (args.Length > 1 && File.Exists(args[1]))
            {
                if (ReadIMG(args[1]))
                {
                    Text = Application.ProductName + " - " + args[1];
                    string directoryOfFile = Path.GetDirectoryName(args[1]);
                    _ofdOpen.InitialDirectory = directoryOfFile;
                    _sfdSave.InitialDirectory = directoryOfFile;
                }
            }
            else
            {
                try
                {
                    RegistryKey regKey = Registry.CurrentUser
                        .OpenSubKey(@"Software\Team17SoftwareLTD\WormsArmageddon", true);
                    String gamePath = regKey.GetValue("PATH", String.Empty).ToString();
                    _ofdOpen.InitialDirectory = gamePath;
                    _sfdSave.InitialDirectory = gamePath;
                }
                catch
                {
                }
            }
        }

        #region ---- METHODEN (PRIVATE) --------------------------------------------------------------------
        #endregion

        private bool ReadIMG(string path)
        {
            string description = "";
            bool isCompressed = false;
            bool hasPalette = false;
            short width, height;
            short numberOfColors = 1;
            byte[] imageData;

            ResetGUI();
                
            FileStream fr = new FileStream(path, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fr);

            // Header überprüfen
            byte[] header = br.ReadBytes(4);
            byte[] correctHeader = { 0x49, 0x4D, 0x47, 0x1A };
            if (!CompareArrays(header, correctHeader))
            {
                _cbHeader.Checked = false;
                SetErrorLabel("Invalid header.");
                return false;
            }

            // Dateilänge auslesen
            byte[] fileLengthArray = br.ReadBytes(4);

            // Ggf. Bildbeschreibung auslesen
            byte bitsPerPixel = br.ReadByte();
            if (bitsPerPixel > 48)
            {
                br.BaseStream.Seek(-1, SeekOrigin.Current);
                while (true)
                {
                    byte[] b = br.ReadBytes(1);
                    if (b[0] == 0)
                    {
                        break;
                    }
                    else
                    {
                        description += (char)b[0];
                    }
                }
                bitsPerPixel = br.ReadByte();
            }

            // Imageflags auslesen
            byte flags = br.ReadByte();
            switch (flags)
            {
                case 0x00:
                    break;
                case 0x40:
                    isCompressed = true;
                    break;
                case 0x80:
                    hasPalette = true;
                    break;
                case 0xC0:
                    isCompressed = true;
                    hasPalette = true;
                    break;
                default:
                    _cbPalette.CheckState = CheckState.Indeterminate;
                    _cbCompressed.CheckState = CheckState.Indeterminate;
                    SetErrorLabel("Invalid image flags.");
                    return false;
            }

            // Ggf. Palette auslesen
            if (hasPalette)
            {
                numberOfColors = BitConverter.ToInt16(br.ReadBytes(2), 0);
                numberOfColors++;
                _palette = new byte[numberOfColors, 3];
                for (int i = 0; i < numberOfColors; i++)
                {
                    if (i > 0)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            _palette[i, j] = br.ReadByte();
                        }
                    }
                    ListViewItem newItem = _lvColors.Items.Add("R=" + _palette[i, 0]
                        + " G=" + _palette[i, 1] + " B=" + _palette[i, 2]);
                    newItem.BackColor = Color.FromArgb(_palette[i, 0], _palette[i, 1],
                        _palette[i, 2]);
                    newItem.ForeColor = GetForeColor(newItem.BackColor);
                }
            }

            // Größe des Bildes
            width = BitConverter.ToInt16(br.ReadBytes(2), 0);
            height = BitConverter.ToInt16(br.ReadBytes(2), 0);
            _pbImage.Size = new Size(width, height);

            // Dekomprimierung durchführen, wenn nötig
            if (isCompressed)
            {
                imageData = new byte[width * height];
                Decompress(br, ref imageData);
            }
            else
            {
                imageData = br.ReadBytes(width * height);
            }

            // Bild zeichnen
            DrawIMG(width, height, imageData);

            // Datei und Ressourcen freigeben
            br.Close();
            fr.Close();

            // Informationen anzeigen
            _tsmiSaveAs.Enabled = true;
            _tsmiClose.Enabled = true;
            _lbFilename.Text = Path.GetFileNameWithoutExtension(path);
            _cbHeader.Checked = true;
            _cbCompressed.Checked = isCompressed;
            _tbLength.Text = BitConverter.ToInt32(fileLengthArray, 0).ToString();
            _tbDescription.Text = description;
            _tbSizeBpp.Text = width.ToString() + "×" + height.ToString()
                + "×" + bitsPerPixel.ToString();
            _cbPalette.Checked = hasPalette;
            _colColors.Text = "Colors (" + numberOfColors.ToString() + ")";
            SetErrorLabel("");

            return true;
        }

        private bool CompareArrays(byte[] a, byte[] b)
        {
            if (a.Length == b.Length)
            {
                for (int i = 0; i < a.Length; i++)
                {
                    if (a[i] != b[i])
                    {
                        return false;
                    }
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool Decompress(BinaryReader b, ref byte[] dStream)
        {
            int cmd;
            int output = 0; // Offset of next write
            while ((cmd = b.ReadByte()) != -1)
            { // Read a byte
                if ((cmd & 0x80) == 0)
                { // Command: 1 byte (color)
                    dStream[output++] = (byte)cmd;
                }
                else
                {
                    int arg1 = (cmd >> 3) & 0xF; // Arg1 = bits 2-5
                    int arg2 = b.ReadByte();
                    if (arg2 == -1)
                        return false;
                    arg2 = ((cmd << 8) | arg2) & 0x7FF; // Arg2 = bits 6-16
                    if (arg1 == 0)
                    {
                        if (arg2 == 0) // Command: 0x80 0x00
                            return false;
                        int arg3 = b.ReadByte();
                        if (arg3 == -1)
                            return false;
                        // Command: 3 bytes
                        output = CopyData(output, arg2, arg3 + 18, ref dStream);
                    }
                    else
                    {
                        // Command: 2 bytes
                        output = CopyData(output, arg2 + 1, arg1 + 2, ref dStream);
                    }
                }
            }
            return true;
        }

        private int CopyData(int dOffset, int cOffset, int Repeat, ref byte[] dStream)
        {
            for (; Repeat > 0; Repeat--)
            {
                dStream[dOffset] = dStream[dOffset++ - cOffset];
            }
            return dOffset;
        }

        private unsafe void DrawIMG(short width, short height, byte[] imageData)
        {
            Bitmap bm = new Bitmap(width, height);
            BitmapData bmData = bm.LockBits(new Rectangle(0, 0, width, height),
                ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
            int pixelSize = 4;

            for (int y = 0; y < bmData.Height; y++)
            {
                byte* row = (byte*)bmData.Scan0 + (y * bmData.Stride);
                for (int x = 0; x < bmData.Width; x++)
                {
                    byte paletteEntry = imageData[y * width + x];
                    byte r = _palette[paletteEntry, 0];
                    byte g = _palette[paletteEntry, 1];
                    byte b = _palette[paletteEntry, 2];
                    if (r != 0 || b != 0 || g != 0)
                    {
                        row[x * pixelSize] = b;
                        row[x * pixelSize + 1] = g;
                        row[x * pixelSize + 2] = r;
                        row[x * pixelSize + 3] = 255;
                    }
                }
            }
            bm.UnlockBits(bmData);
            _pbImage.BackgroundImage = bm;
        }

        private Color GetForeColor(Color color)
        {
            if (color.GetBrightness() < 0.5)
            {
                return Color.White;
            }
            else
            {
                return Color.Black;
            }
        }

        private void ResetGUI()
        {
            Text = Application.ProductName;
            _tsmiSaveAs.Enabled = false;
            _tsmiClose.Enabled = false;
            _lbError.Visible = true;
            _lbError.Text = "No image loaded.";
            _lbFilename.Text = "No image loaded.";
            _cbHeader.Checked = false;
            _cbCompressed.Checked = false;
            _tbLength.Text = String.Empty;
            _tbDescription.Text = String.Empty;
            _tbSizeBpp.Text = String.Empty;
            _cbPalette.Checked = false;
            _colColors.Text = "Colors";
            _lvColors.Items.Clear();
        }

        private void SetErrorLabel(string text)
        {
            if (text.Length > 0)
            {
                _lbError.Visible = true;
                _lbError.Text = text;
                _pbImage.Size = new Size(0, 0);
            }
            else
            {
                _lbError.Visible = false;
            }
        }

        #region ---- EVENTHANDLER --------------------------------------------------------------------------
        #endregion

        private void _tsmiOpen_Click(object sender, EventArgs e)
        {
            if (_ofdOpen.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if (ReadIMG(_ofdOpen.FileName))
                    {
                        Text = Application.ProductName + " - " + _ofdOpen.FileName;
                    }
                }
                catch (Exception ex)
                {
                    _lbError.Visible = true;
                    _lbError.Text = "Unknown error occured. "
                        + "Please send a screenshot of this information to the developers:"
                        + Environment.NewLine + ex.ToString();
                }
            }
        }

        private void _tsmiSaveAs_Click(object sender, EventArgs e)
        {
            if (_sfdSave.ShowDialog() == DialogResult.OK)
            {
                switch (_sfdSave.FilterIndex)
                {
                    case 1:
                        _pbImage.BackgroundImage.Save(_sfdSave.FileName, ImageFormat.Bmp);
                        break;
                    case 2:
                        _pbImage.BackgroundImage.Save(_sfdSave.FileName, ImageFormat.Png);
                        break;
                    case 3:
                        _pbImage.BackgroundImage.Save(_sfdSave.FileName, ImageFormat.Jpeg);
                        break;
                }
                _sfdSave.InitialDirectory = Path.GetDirectoryName(_sfdSave.FileName);
            }
        }

        private void _tsmiClose_Click(object sender, EventArgs e)
        {
            Text = Application.ProductName;
            _tsmiSaveAs.Enabled = false;
            _tsmiClose.Enabled = false;
            ResetGUI();
            _pbImage.BackgroundImage = null;
            _pbImage.Size = new Size(0, 0);
        }

        private void _tsmiExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void _tsmiDetails_Click(object sender, EventArgs e)
        {
            _scDetailsPreview.Panel1Collapsed = !_tsmiDetails.Checked;
        }

        private void _tsmiFitToWindow_Click(object sender, EventArgs e)
        {
            if (_tsmiFitToWindow.Checked)
            {
                _pbImage.BackgroundImageLayout = ImageLayout.Zoom;
                _pbImage.Dock = DockStyle.Fill;
            }
            else
            {
                _pbImage.BackgroundImageLayout = ImageLayout.None;
                _pbImage.Dock = DockStyle.None;
            }
        }

        private void _tsmiAbout_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Application.ProductName + " " + Application.ProductVersion.ToString()
                + Environment.NewLine + "The Worms.NET Team" + Environment.NewLine
                + "Licensed under Ms-PL" + Environment.NewLine
                + "Decompression algorithm by Pisto.", "About", MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void _lvColors_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem foundItem in _lvColors.Items)
            {
                foundItem.Selected = false;
            }
        }

        private void _tsmiBlack_Click(object sender, EventArgs e)
        {
            _pbImage.BackColor = (_tsmiBlack.Checked ? Color.Black : SystemColors.Control);
        }

    } // #### FormMain #############################################################################
}
