﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace WormsNET.ImgViewer
{
    #region #### ExtendedListView #########################################################################
    #endregion
    /// <summary>
    /// Zeigt eine Auflistung von Elementen in einer von fünf verschiedenen Ansichten an.
    /// </summary>
    [ToolboxBitmap(typeof(ListView))]
    public class ExtendedListView : ListView
    {
        #region ---- DELEGATES ----------------------------------------------------------------------------
        #endregion

        delegate void CallBackSetGroupState(ListViewGroup group, ListViewGroupState state);
        delegate void CallbackSetGroupString(ListViewGroup group, string value);

        #region ---- MEMBERVARIABLEN ----------------------------------------------------------------------
        #endregion

        int? _fillColumnIndex;         // Index der Spalte, die den restlichen Platz einnimmt
        bool _codeColumnWidthChange;   // Wurden die Spaltenbreiten vom Code geändert?
        bool _enableAdditionalHotKeys; // Zusätzliche Tastenkombinationen erlauben?
        bool _hoverSelectionDelay;     // Delay vor kompletter Auswahl bei HotTracking?
        bool _visualStylesEnabled;     // Gibt an, ob visuelle Stile verwendet werden

        #region ---- KONSTRUKTOREN & DESTRUKTOR -----------------------------------------------------------
        #endregion

        /// <summary>
        /// Erstellt eine neue Instanz der ExtendedListView-Klasse.
        /// </summary>
        public ExtendedListView()
        {
            // Flimmern verhindern durch Doppelpufferung (aktiviert auch blaues Auswahlrechteck)
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer,
                true);

            // Eigenschaften setzen
            _enableAdditionalHotKeys = true;
            _fillColumnIndex = null;
            _hoverSelectionDelay = false;
            _visualStylesEnabled = true;
        }

        #region ---- EIGENSCHAFTEN ------------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Gibt an oder legt fest, ob zusätzliche Tastenkombinationen wie z.B. Strg+A zur Auswahl
        /// aller Items unterstützt werden sollen.
        /// </summary>
        [Browsable(true)]
        [Category("Behavior")]
        [DefaultValue(true)]
        [Description("Determines wether additional shortcuts like Ctrl+A for selecting all items "
            + "are supported.")]
        public bool EnableAdditionalHotKeys
        {
            get
            {
                return _enableAdditionalHotKeys;
            }
            set
            {
                _enableAdditionalHotKeys = value;
            }
        }

        /// <summary>
        /// Gibt den Index der Spalte an, die den restlichen nicht von anderen in der ListView
        /// vorhandenen Spalten verbrauchten Platz einnimmt oder legt diesen fest.
        /// </summary>
        [Browsable(true)]
        [Category("Layout")]
        [DefaultValue(null)]
        [Description("Determines the index of the column which automatically fits into the "
            + "remaining space of the list view which is not used by all the other columns.")]
        public int? FillColumnIndex
        {
            get
            {
                return _fillColumnIndex;
            }
            set
            {
                // Nur setzen, wenn sich der Wert vom bisherigen unterscheidet
                if (!_fillColumnIndex.Equals(value))
                {
                    _fillColumnIndex = value;
                    if (_fillColumnIndex.HasValue)
                    {
                        LayoutColumns();
                    }
                    else
                    {
                        // Horizontale Bildlaufleiste ermöglichen
                        NativeMethods.ShowScrollBar(Handle, NativeMethods.SB_HORZ, 1);
                    }
                }
            }
        }

        /// <summary>
        /// Gibt an oder legt fest ob ein kleiner Delay vor kompletter Auswahl eines überfahrenen
        /// Items stattfinden soll wenn HoverSelection aktiviert ist.
        /// </summary>
        [Browsable(true)]
        [Category("Behavior")]
        [DefaultValue(false)]
        [Description("Determines if there should be a small delay before hovered items are fully "
            + "selected if HoverSelection is enabled.")]
        public bool HoverSelectionDelay
        {
            get
            {
                return _hoverSelectionDelay;
            }
            set
            {
                _hoverSelectionDelay = value;
            }
        }

        /// <summary>
        /// Gibt an oder legt fest ob diese ListView zur Darstellung visuelle Stile verwendet.
        /// </summary>
        [Browsable(true)]
        [Category("Appearance")]
        [DefaultValue(true)]
        [Description("Determines if the listview uses visual styles to display its content.")]
        public bool VisualStylesEnabled
        {
            get
            {
                return _visualStylesEnabled;
            }
            set
            {
                _visualStylesEnabled = value;
            }
        }

        #region ---- METHODEN (PUBLIC) --------------------------------------------------------------------
        #endregion

        /// <summary>
        /// Passt die Breiten der Spalten gemäß der Füllspalte an.
        /// </summary>
        public void LayoutColumns()
        {
            if (_fillColumnIndex.HasValue && Columns.Count > _fillColumnIndex)
            {
                // Benötigten Platz der restlichen Spalten herausfinden
                int usedSpace = 0;
                foreach (ColumnHeader column in Columns)
                {
                    if (column.Index != _fillColumnIndex.Value)
                    {
                        usedSpace += column.Width;
                    }
                }

                // Breite der Füllspalte anpassen
                _codeColumnWidthChange = true;
                Columns[_fillColumnIndex.Value].Width = ClientSize.Width - usedSpace;
                _codeColumnWidthChange = false;
            }
        }

        public void SetGroupCollapse(ListViewGroupState state)
        {
            for (int i = 0; i <= Groups.Count; i++)
            {
                NativeMethods.LVGROUP group = new NativeMethods.LVGROUP();
                group.cbSize = Marshal.SizeOf(group);
                group.state = (int)state;
                group.mask = NativeMethods.LVGF_STATE;
                group.iGroupId = i;

                IntPtr ip = IntPtr.Zero;
                ip = Marshal.AllocHGlobal(group.cbSize);
                Marshal.StructureToPtr(group, ip, false);
                NativeMethods.SendMessage(Handle, NativeMethods.LVM_SETGROUPINFO, i, ip);

                if (ip != null)
                {
                    Marshal.FreeHGlobal(ip);
                }
            }
        }

        #region ---- METHODEN (PROTECTED) -----------------------------------------------------------------
        #endregion

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case NativeMethods.WM_LBUTTONUP:
                    try
                    {
                        base.DefWndProc(ref m);
                    }
                    catch
                    {
                    }
                    break;
                default:
                    base.WndProc(ref m);
                    break;
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            // Windowsstyles anwenden und gepunktete Linien entfernen
            if (VisualStylesEnabled)
            {
                NativeMethods.SetWindowTheme(Handle, "explorer", null);
            }
            NativeMethods.MakeFocusInvisible(Handle);

            // Breiten der Spalten berechnen bezüglich Füllspalte
            LayoutColumns();

            base.OnHandleCreated(e);
        }

        protected override void OnColumnWidthChanged(ColumnWidthChangedEventArgs e)
        {
            if (_fillColumnIndex.HasValue)
            {
                // Horizontale Bildlaufleiste deaktivieren
                NativeMethods.ShowScrollBar(Handle, NativeMethods.SB_HORZ, 0);
            }

            base.OnColumnWidthChanged(e);
        }

        protected override void OnColumnWidthChanging(ColumnWidthChangingEventArgs e)
        {
            if (e != null && e.ColumnIndex.Equals(_fillColumnIndex) && !_codeColumnWidthChange)
            {
                // Ändern der Breite der Füllspalte verhindern
                e.Cancel = true;
                e.NewWidth = Columns[e.ColumnIndex].Width;
            }
            else
            {
                // Bei Größenänderungen die anderen Spaltenbreiten anpassen
                LayoutColumns();
            }

            base.OnColumnWidthChanging(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (HoverSelection && !HoverSelectionDelay && e != null)
            {
                ListViewItem hoveredItem = GetItemAt(e.X, e.Y);
                if (hoveredItem != null && !hoveredItem.Selected)
                {
                    foreach (ListViewItem item in Items)
                    {
                        item.Selected = false;
                    }
                    hoveredItem.Selected = true;
                }
                else if (hoveredItem == null && !MultiSelect)
                {
                    foreach (ListViewItem item in Items)
                    {
                        item.Selected = false;
                    }
                }
            }

            base.OnMouseMove(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            // Zusätzliche Tastenkombinationen
            if (_enableAdditionalHotKeys)
            {
                if (e != null)
                {
                    // Alle Items markieren
                    if (e.Modifiers == Keys.Control && e.KeyCode == Keys.A)
                    {
                        foreach (ListViewItem item in Items)
                        {
                            item.Selected = true;
                        }
                    }

                    // Item umbenennen
                    if (LabelEdit && SelectedItems.Count == 1
                        && e.Modifiers == Keys.None && e.KeyCode == Keys.F2)
                    {
                        SelectedItems[0].BeginEdit();
                    }
                }
            }

            base.OnKeyDown(e);
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            // Spaltenbreiten bezüglich Füllspalte berechnen
            LayoutColumns();

            base.OnSizeChanged(e);
        }

        #region ---- METHODEN (PRIVATE) -------------------------------------------------------------------
        #endregion

        private static int? GetGroupId(ListViewGroup group)
        {
            int? id = null;
            Type groupType = group.GetType();
            if (groupType != null)
            {
                PropertyInfo pi = groupType.GetProperty("ID", BindingFlags.NonPublic
                    | BindingFlags.Instance);
                if (pi != null)
                {
                    object temp = pi.GetValue(group, null);
                    if (temp != null)
                    {
                        id = temp as int?;
                    }
                }
            }
            return id;
        }

    } // #### ExtendedListView ####################################################################

    public enum ListViewGroupMask
    {
        None = 0x00000,
        Header = 0x00001,
        Footer = 0x00002,
        State = 0x00004,
        Align = 0x00008,
        GroupId = 0x00010,
        SubTitle = 0x00100,
        Task = 0x00200,
        DescriptionTop = 0x00400,
        DescriptionBottom = 0x00800,
        TitleImage = 0x01000,
        ExtendedImage = 0x02000,
        Items = 0x04000,
        Subset = 0x08000,
        SubsetItems = 0x10000
    }

    public enum ListViewGroupState
    {
        Expanded = 0,
        Collapsed = 1,
        Collapsible = 8
    }
}
