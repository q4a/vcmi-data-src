﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace WormsNET.ImgViewer
{
    #region #### NativeMethods ############################################################################
    #endregion
    /// <summary>
    /// Static method and structure collection for native / WinAPI stuff.
    /// </summary>
    internal class NativeMethods
    {
        #region ---- STRUCTURES ---------------------------------------------------------------------------
        #endregion

        [StructLayout(LayoutKind.Sequential)]
        public struct LVGROUP
        {
            public int cbSize;
            public int mask;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pszHeader;
            public int cchHeader;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pszFooter;
            public int cchFooter;
            public int iGroupId;
            public int stateMask;
            public int state;
            public int uAlign;
        } 

        #region ---- CONSTANTS ----------------------------------------------------------------------------
        #endregion

        internal const int LVM_FIRST        = 0x00001000;
        internal const int LVM_SETGROUPINFO = LVM_FIRST + 147;
        internal const int LVGF_STATE       = 0x00000004;

        internal const int SB_HORZ          = 0;
        internal const int SB_VERT          = 1;
        internal const int SB_CTL           = 2;
        internal const int SB_BOTH          = 3;
        
        internal const int UIS_HIDEFOCUS    = 0x00000001;
        internal const int UIS_SET          = 1;
        
        internal const int WM_CHANGEUISTATE = 0x00000127;
        internal const int WM_LBUTTONUP     = 0x00000202;

        #region ---- METHODS (INTERNAL) -------------------------------------------------------------------
        #endregion

        internal static void MakeFocusInvisible(IntPtr handle)
        {
            SendMessage(handle, WM_CHANGEUISTATE, MAKELONG(UIS_SET, UIS_HIDEFOCUS), 0);
        }

        [DllImport("user32.dll")]
        internal static extern int SendMessage(IntPtr hWnd, int message, int wParam, int lParam);
        [DllImport("user32.dll")]
        internal static extern int SendMessage(IntPtr hWnd, int message, int wParam, IntPtr lParam);

        [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)]
        internal static extern int SetWindowTheme(IntPtr hwnd,
            [MarshalAs(UnmanagedType.LPWStr)] string pszSubAppName, string pszSubIdList);

        [DllImport("user32.dll")]
        internal static extern int ShowScrollBar(IntPtr hWnd, int wBar, int bShow);

        #region ---- METHODS (PRIVATE) --------------------------------------------------------------------
        #endregion

        private static int MAKELONG(int wLow, int wHigh)
        {
            int low = (int)LOWORD(wLow);
            short high = LOWORD(wHigh);
            int product = 0x00010000 * (int)high;
            int makeLong = (int)(low | product);
            return makeLong;
        }

        private static short LOWORD(int dw)
        {
            short loWord = 0;
            ushort andResult = (ushort)(dw & 0x00007FFF);
            ushort mask = 0x8000;
            if ((dw & 0x8000) != 0)
            {
                loWord = (short)(mask | andResult);
            }
            else
            {
                loWord = (short)andResult;
            }
            return loWord;
        }
    }
}
