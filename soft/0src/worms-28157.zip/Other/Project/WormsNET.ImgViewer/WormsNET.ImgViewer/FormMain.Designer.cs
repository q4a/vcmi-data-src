﻿namespace WormsNET.ImgViewer
{
    partial class FormMain
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this._ofdOpen = new System.Windows.Forms.OpenFileDialog();
            this._pbImage = new System.Windows.Forms.PictureBox();
            this._pnImage = new System.Windows.Forms.Panel();
            this._lbError = new System.Windows.Forms.Label();
            this._msMain = new System.Windows.Forms.MenuStrip();
            this._tsmiFile = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiOpen = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiClose = new System.Windows.Forms.ToolStripMenuItem();
            this._tssFile1 = new System.Windows.Forms.ToolStripSeparator();
            this._tsmiExit = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiView = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiDetails = new System.Windows.Forms.ToolStripMenuItem();
            this._tssView1 = new System.Windows.Forms.ToolStripSeparator();
            this._tsmiBlack = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiFitToWindow = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiHelp = new System.Windows.Forms.ToolStripMenuItem();
            this._tsmiAbout = new System.Windows.Forms.ToolStripMenuItem();
            this._sfdSave = new System.Windows.Forms.SaveFileDialog();
            this._scDetailsPreview = new System.Windows.Forms.SplitContainer();
            this._pnDetails = new System.Windows.Forms.Panel();
            this._gbGeneral = new System.Windows.Forms.GroupBox();
            this._cbHeader = new System.Windows.Forms.CheckBox();
            this._cbCompressed = new System.Windows.Forms.CheckBox();
            this._lbLength = new System.Windows.Forms.Label();
            this._tbSizeBpp = new System.Windows.Forms.TextBox();
            this._lbDescription = new System.Windows.Forms.Label();
            this._lbSizeBpp = new System.Windows.Forms.Label();
            this._tbLength = new System.Windows.Forms.TextBox();
            this._tbDescription = new System.Windows.Forms.TextBox();
            this._gbPalette = new System.Windows.Forms.GroupBox();
            this._lvColors = new WormsNET.ImgViewer.ExtendedListView();
            this._colColors = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._cbPalette = new System.Windows.Forms.CheckBox();
            this._lbFilename = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this._pbImage)).BeginInit();
            this._pnImage.SuspendLayout();
            this._msMain.SuspendLayout();
            this._scDetailsPreview.Panel1.SuspendLayout();
            this._scDetailsPreview.Panel2.SuspendLayout();
            this._scDetailsPreview.SuspendLayout();
            this._pnDetails.SuspendLayout();
            this._gbGeneral.SuspendLayout();
            this._gbPalette.SuspendLayout();
            this.SuspendLayout();
            // 
            // _ofdOpen
            // 
            this._ofdOpen.Filter = "IMG files|*.img|All files|*.*";
            this._ofdOpen.Title = "Browse for IMG file";
            // 
            // _pbImage
            // 
            this._pbImage.BackColor = System.Drawing.Color.Black;
            this._pbImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this._pbImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this._pbImage.Location = new System.Drawing.Point(0, 0);
            this._pbImage.Margin = new System.Windows.Forms.Padding(0);
            this._pbImage.Name = "_pbImage";
            this._pbImage.Size = new System.Drawing.Size(578, 536);
            this._pbImage.TabIndex = 2;
            this._pbImage.TabStop = false;
            // 
            // _pnImage
            // 
            this._pnImage.AutoScroll = true;
            this._pnImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._pnImage.Controls.Add(this._lbError);
            this._pnImage.Controls.Add(this._pbImage);
            this._pnImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this._pnImage.Location = new System.Drawing.Point(0, 0);
            this._pnImage.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this._pnImage.Name = "_pnImage";
            this._pnImage.Size = new System.Drawing.Size(580, 538);
            this._pnImage.TabIndex = 1;
            // 
            // _lbError
            // 
            this._lbError.BackColor = System.Drawing.SystemColors.Control;
            this._lbError.Dock = System.Windows.Forms.DockStyle.Fill;
            this._lbError.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lbError.Location = new System.Drawing.Point(0, 0);
            this._lbError.Name = "_lbError";
            this._lbError.Size = new System.Drawing.Size(578, 536);
            this._lbError.TabIndex = 0;
            this._lbError.Text = "No image loaded.";
            this._lbError.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _msMain
            // 
            this._msMain.BackColor = System.Drawing.SystemColors.Control;
            this._msMain.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._msMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._tsmiFile,
            this._tsmiView,
            this._tsmiHelp});
            this._msMain.Location = new System.Drawing.Point(0, 0);
            this._msMain.Name = "_msMain";
            this._msMain.Padding = new System.Windows.Forms.Padding(2);
            this._msMain.Size = new System.Drawing.Size(784, 24);
            this._msMain.TabIndex = 0;
            // 
            // _tsmiFile
            // 
            this._tsmiFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._tsmiOpen,
            this._tsmiSaveAs,
            this._tsmiClose,
            this._tssFile1,
            this._tsmiExit});
            this._tsmiFile.Name = "_tsmiFile";
            this._tsmiFile.Size = new System.Drawing.Size(37, 20);
            this._tsmiFile.Text = "File";
            // 
            // _tsmiOpen
            // 
            this._tsmiOpen.Image = ((System.Drawing.Image)(resources.GetObject("_tsmiOpen.Image")));
            this._tsmiOpen.Name = "_tsmiOpen";
            this._tsmiOpen.Size = new System.Drawing.Size(121, 22);
            this._tsmiOpen.Text = "Open...";
            this._tsmiOpen.Click += new System.EventHandler(this._tsmiOpen_Click);
            // 
            // _tsmiSaveAs
            // 
            this._tsmiSaveAs.Enabled = false;
            this._tsmiSaveAs.Image = ((System.Drawing.Image)(resources.GetObject("_tsmiSaveAs.Image")));
            this._tsmiSaveAs.Name = "_tsmiSaveAs";
            this._tsmiSaveAs.Size = new System.Drawing.Size(121, 22);
            this._tsmiSaveAs.Text = "Save as...";
            this._tsmiSaveAs.Click += new System.EventHandler(this._tsmiSaveAs_Click);
            // 
            // _tsmiClose
            // 
            this._tsmiClose.Enabled = false;
            this._tsmiClose.Image = ((System.Drawing.Image)(resources.GetObject("_tsmiClose.Image")));
            this._tsmiClose.Name = "_tsmiClose";
            this._tsmiClose.Size = new System.Drawing.Size(121, 22);
            this._tsmiClose.Text = "Close";
            this._tsmiClose.Click += new System.EventHandler(this._tsmiClose_Click);
            // 
            // _tssFile1
            // 
            this._tssFile1.Name = "_tssFile1";
            this._tssFile1.Size = new System.Drawing.Size(118, 6);
            // 
            // _tsmiExit
            // 
            this._tsmiExit.Image = ((System.Drawing.Image)(resources.GetObject("_tsmiExit.Image")));
            this._tsmiExit.Name = "_tsmiExit";
            this._tsmiExit.Size = new System.Drawing.Size(121, 22);
            this._tsmiExit.Text = "Exit";
            this._tsmiExit.Click += new System.EventHandler(this._tsmiExit_Click);
            // 
            // _tsmiView
            // 
            this._tsmiView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._tsmiDetails,
            this._tssView1,
            this._tsmiBlack,
            this._tsmiFitToWindow});
            this._tsmiView.Name = "_tsmiView";
            this._tsmiView.Size = new System.Drawing.Size(44, 20);
            this._tsmiView.Text = "View";
            // 
            // _tsmiDetails
            // 
            this._tsmiDetails.Checked = true;
            this._tsmiDetails.CheckOnClick = true;
            this._tsmiDetails.CheckState = System.Windows.Forms.CheckState.Checked;
            this._tsmiDetails.Name = "_tsmiDetails";
            this._tsmiDetails.Size = new System.Drawing.Size(204, 22);
            this._tsmiDetails.Text = "Show details pane";
            this._tsmiDetails.Click += new System.EventHandler(this._tsmiDetails_Click);
            // 
            // _tssView1
            // 
            this._tssView1.Name = "_tssView1";
            this._tssView1.Size = new System.Drawing.Size(201, 6);
            // 
            // _tsmiBlack
            // 
            this._tsmiBlack.Checked = true;
            this._tsmiBlack.CheckOnClick = true;
            this._tsmiBlack.CheckState = System.Windows.Forms.CheckState.Checked;
            this._tsmiBlack.Name = "_tsmiBlack";
            this._tsmiBlack.Size = new System.Drawing.Size(204, 22);
            this._tsmiBlack.Text = "Show black pixels";
            this._tsmiBlack.Click += new System.EventHandler(this._tsmiBlack_Click);
            // 
            // _tsmiFitToWindow
            // 
            this._tsmiFitToWindow.Checked = true;
            this._tsmiFitToWindow.CheckOnClick = true;
            this._tsmiFitToWindow.CheckState = System.Windows.Forms.CheckState.Checked;
            this._tsmiFitToWindow.Name = "_tsmiFitToWindow";
            this._tsmiFitToWindow.Size = new System.Drawing.Size(204, 22);
            this._tsmiFitToWindow.Text = "Fit image to window size";
            this._tsmiFitToWindow.Click += new System.EventHandler(this._tsmiFitToWindow_Click);
            // 
            // _tsmiHelp
            // 
            this._tsmiHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._tsmiAbout});
            this._tsmiHelp.Name = "_tsmiHelp";
            this._tsmiHelp.Size = new System.Drawing.Size(44, 20);
            this._tsmiHelp.Text = "Help";
            // 
            // _tsmiAbout
            // 
            this._tsmiAbout.Image = ((System.Drawing.Image)(resources.GetObject("_tsmiAbout.Image")));
            this._tsmiAbout.Name = "_tsmiAbout";
            this._tsmiAbout.Size = new System.Drawing.Size(116, 22);
            this._tsmiAbout.Text = "About...";
            this._tsmiAbout.Click += new System.EventHandler(this._tsmiAbout_Click);
            // 
            // _sfdSave
            // 
            this._sfdSave.Filter = "Bitmap|*.bmp|PNG image|*.png|JPEG image|*.jpg";
            this._sfdSave.FilterIndex = 2;
            this._sfdSave.Title = "Save IMG file as...";
            // 
            // _scDetailsPreview
            // 
            this._scDetailsPreview.Dock = System.Windows.Forms.DockStyle.Fill;
            this._scDetailsPreview.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this._scDetailsPreview.IsSplitterFixed = true;
            this._scDetailsPreview.Location = new System.Drawing.Point(0, 24);
            this._scDetailsPreview.Name = "_scDetailsPreview";
            // 
            // _scDetailsPreview.Panel1
            // 
            this._scDetailsPreview.Panel1.Controls.Add(this._pnDetails);
            // 
            // _scDetailsPreview.Panel2
            // 
            this._scDetailsPreview.Panel2.Controls.Add(this._pnImage);
            this._scDetailsPreview.Size = new System.Drawing.Size(784, 538);
            this._scDetailsPreview.SplitterDistance = 200;
            this._scDetailsPreview.TabIndex = 2;
            // 
            // _pnDetails
            // 
            this._pnDetails.BackColor = System.Drawing.SystemColors.Control;
            this._pnDetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._pnDetails.Controls.Add(this._gbGeneral);
            this._pnDetails.Controls.Add(this._gbPalette);
            this._pnDetails.Controls.Add(this._lbFilename);
            this._pnDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this._pnDetails.Location = new System.Drawing.Point(0, 0);
            this._pnDetails.Name = "_pnDetails";
            this._pnDetails.Padding = new System.Windows.Forms.Padding(0, 8, 8, 0);
            this._pnDetails.Size = new System.Drawing.Size(200, 538);
            this._pnDetails.TabIndex = 0;
            // 
            // _gbGeneral
            // 
            this._gbGeneral.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._gbGeneral.Controls.Add(this._cbHeader);
            this._gbGeneral.Controls.Add(this._cbCompressed);
            this._gbGeneral.Controls.Add(this._lbLength);
            this._gbGeneral.Controls.Add(this._tbSizeBpp);
            this._gbGeneral.Controls.Add(this._lbDescription);
            this._gbGeneral.Controls.Add(this._lbSizeBpp);
            this._gbGeneral.Controls.Add(this._tbLength);
            this._gbGeneral.Controls.Add(this._tbDescription);
            this._gbGeneral.Location = new System.Drawing.Point(3, 32);
            this._gbGeneral.Name = "_gbGeneral";
            this._gbGeneral.Size = new System.Drawing.Size(193, 162);
            this._gbGeneral.TabIndex = 1;
            this._gbGeneral.TabStop = false;
            this._gbGeneral.Text = "General information";
            // 
            // _cbHeader
            // 
            this._cbHeader.AutoCheck = false;
            this._cbHeader.AutoSize = true;
            this._cbHeader.Location = new System.Drawing.Point(8, 22);
            this._cbHeader.Name = "_cbHeader";
            this._cbHeader.Size = new System.Drawing.Size(97, 17);
            this._cbHeader.TabIndex = 0;
            this._cbHeader.Text = "Header correct";
            this._cbHeader.UseVisualStyleBackColor = true;
            // 
            // _cbCompressed
            // 
            this._cbCompressed.AutoCheck = false;
            this._cbCompressed.AutoSize = true;
            this._cbCompressed.Location = new System.Drawing.Point(8, 47);
            this._cbCompressed.Name = "_cbCompressed";
            this._cbCompressed.Size = new System.Drawing.Size(84, 17);
            this._cbCompressed.TabIndex = 1;
            this._cbCompressed.Text = "Compressed";
            this._cbCompressed.ThreeState = true;
            this._cbCompressed.UseVisualStyleBackColor = true;
            // 
            // _lbLength
            // 
            this._lbLength.AutoSize = true;
            this._lbLength.Location = new System.Drawing.Point(5, 75);
            this._lbLength.Name = "_lbLength";
            this._lbLength.Size = new System.Drawing.Size(62, 15);
            this._lbLength.TabIndex = 2;
            this._lbLength.Text = "Length (b)";
            // 
            // _tbSizeBpp
            // 
            this._tbSizeBpp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._tbSizeBpp.Location = new System.Drawing.Point(78, 130);
            this._tbSizeBpp.Name = "_tbSizeBpp";
            this._tbSizeBpp.ReadOnly = true;
            this._tbSizeBpp.Size = new System.Drawing.Size(106, 23);
            this._tbSizeBpp.TabIndex = 7;
            this._tbSizeBpp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // _lbDescription
            // 
            this._lbDescription.AutoSize = true;
            this._lbDescription.Location = new System.Drawing.Point(5, 104);
            this._lbDescription.Name = "_lbDescription";
            this._lbDescription.Size = new System.Drawing.Size(67, 15);
            this._lbDescription.TabIndex = 4;
            this._lbDescription.Text = "Description";
            // 
            // _lbSizeBpp
            // 
            this._lbSizeBpp.AutoSize = true;
            this._lbSizeBpp.Location = new System.Drawing.Point(5, 133);
            this._lbSizeBpp.Name = "_lbSizeBpp";
            this._lbSizeBpp.Size = new System.Drawing.Size(64, 15);
            this._lbSizeBpp.TabIndex = 6;
            this._lbSizeBpp.Text = "Size && Bpp";
            // 
            // _tbLength
            // 
            this._tbLength.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._tbLength.Location = new System.Drawing.Point(78, 72);
            this._tbLength.Name = "_tbLength";
            this._tbLength.ReadOnly = true;
            this._tbLength.Size = new System.Drawing.Size(106, 23);
            this._tbLength.TabIndex = 3;
            this._tbLength.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // _tbDescription
            // 
            this._tbDescription.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._tbDescription.Location = new System.Drawing.Point(78, 101);
            this._tbDescription.Name = "_tbDescription";
            this._tbDescription.ReadOnly = true;
            this._tbDescription.Size = new System.Drawing.Size(106, 23);
            this._tbDescription.TabIndex = 5;
            // 
            // _gbPalette
            // 
            this._gbPalette.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._gbPalette.Controls.Add(this._lvColors);
            this._gbPalette.Controls.Add(this._cbPalette);
            this._gbPalette.Location = new System.Drawing.Point(3, 200);
            this._gbPalette.Name = "_gbPalette";
            this._gbPalette.Size = new System.Drawing.Size(193, 334);
            this._gbPalette.TabIndex = 2;
            this._gbPalette.TabStop = false;
            this._gbPalette.Text = " ";
            // 
            // _lvColors
            // 
            this._lvColors.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this._colColors});
            this._lvColors.Dock = System.Windows.Forms.DockStyle.Fill;
            this._lvColors.FillColumnIndex = 0;
            this._lvColors.FullRowSelect = true;
            this._lvColors.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this._lvColors.Location = new System.Drawing.Point(3, 16);
            this._lvColors.MultiSelect = false;
            this._lvColors.Name = "_lvColors";
            this._lvColors.Size = new System.Drawing.Size(187, 315);
            this._lvColors.TabIndex = 1;
            this._lvColors.UseCompatibleStateImageBehavior = false;
            this._lvColors.View = System.Windows.Forms.View.Details;
            this._lvColors.SelectedIndexChanged += new System.EventHandler(this._lvColors_SelectedIndexChanged);
            // 
            // _colColors
            // 
            this._colColors.Text = "Colors";
            this._colColors.Width = 183;
            // 
            // _cbPalette
            // 
            this._cbPalette.AutoCheck = false;
            this._cbPalette.AutoSize = true;
            this._cbPalette.Location = new System.Drawing.Point(14, -1);
            this._cbPalette.Name = "_cbPalette";
            this._cbPalette.Size = new System.Drawing.Size(59, 17);
            this._cbPalette.TabIndex = 0;
            this._cbPalette.Text = "Palette";
            this._cbPalette.ThreeState = true;
            this._cbPalette.UseVisualStyleBackColor = true;
            // 
            // _lbFilename
            // 
            this._lbFilename.AutoSize = true;
            this._lbFilename.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lbFilename.Location = new System.Drawing.Point(8, 11);
            this._lbFilename.Margin = new System.Windows.Forms.Padding(3);
            this._lbFilename.Name = "_lbFilename";
            this._lbFilename.Size = new System.Drawing.Size(103, 15);
            this._lbFilename.TabIndex = 0;
            this._lbFilename.Text = "No image loaded.";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this._scDetailsPreview);
            this.Controls.Add(this._msMain);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this._msMain;
            this.MinimumSize = new System.Drawing.Size(216, 261);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IMG Viewer";
            ((System.ComponentModel.ISupportInitialize)(this._pbImage)).EndInit();
            this._pnImage.ResumeLayout(false);
            this._msMain.ResumeLayout(false);
            this._msMain.PerformLayout();
            this._scDetailsPreview.Panel1.ResumeLayout(false);
            this._scDetailsPreview.Panel2.ResumeLayout(false);
            this._scDetailsPreview.ResumeLayout(false);
            this._pnDetails.ResumeLayout(false);
            this._pnDetails.PerformLayout();
            this._gbGeneral.ResumeLayout(false);
            this._gbGeneral.PerformLayout();
            this._gbPalette.ResumeLayout(false);
            this._gbPalette.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog _ofdOpen;
        private System.Windows.Forms.PictureBox _pbImage;
        private System.Windows.Forms.Panel _pnImage;
        private System.Windows.Forms.MenuStrip _msMain;
        private System.Windows.Forms.ToolStripMenuItem _tsmiFile;
        private System.Windows.Forms.ToolStripMenuItem _tsmiOpen;
        private System.Windows.Forms.ToolStripSeparator _tssFile1;
        private System.Windows.Forms.ToolStripMenuItem _tsmiExit;
        private System.Windows.Forms.ToolStripMenuItem _tsmiHelp;
        private System.Windows.Forms.ToolStripMenuItem _tsmiAbout;
        private System.Windows.Forms.ToolStripMenuItem _tsmiSaveAs;
        private System.Windows.Forms.ToolStripMenuItem _tsmiClose;
        private System.Windows.Forms.SaveFileDialog _sfdSave;
        private System.Windows.Forms.ToolStripMenuItem _tsmiView;
        private System.Windows.Forms.ToolStripMenuItem _tsmiFitToWindow;
        private System.Windows.Forms.SplitContainer _scDetailsPreview;
        private System.Windows.Forms.Panel _pnDetails;
        private System.Windows.Forms.Label _lbFilename;
        private System.Windows.Forms.CheckBox _cbHeader;
        private System.Windows.Forms.Label _lbLength;
        private System.Windows.Forms.TextBox _tbLength;
        private System.Windows.Forms.Label _lbDescription;
        private System.Windows.Forms.TextBox _tbDescription;
        private System.Windows.Forms.TextBox _tbSizeBpp;
        private System.Windows.Forms.Label _lbSizeBpp;
        private System.Windows.Forms.CheckBox _cbCompressed;
        private System.Windows.Forms.CheckBox _cbPalette;
        private System.Windows.Forms.GroupBox _gbGeneral;
        private System.Windows.Forms.GroupBox _gbPalette;
        private WormsNET.ImgViewer.ExtendedListView _lvColors;
        private System.Windows.Forms.ColumnHeader _colColors;
        private System.Windows.Forms.Label _lbError;
        private System.Windows.Forms.ToolStripMenuItem _tsmiDetails;
        private System.Windows.Forms.ToolStripSeparator _tssView1;
        private System.Windows.Forms.ToolStripMenuItem _tsmiBlack;
    }
}

